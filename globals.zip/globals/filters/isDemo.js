﻿filter("isDemo", [], function () {
    return function (anyValue) {
        return false;
    };
});
