﻿filter("iban", ["iban"], function(iban) {
	return iban.format;
});
