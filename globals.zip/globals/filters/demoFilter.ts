﻿window.filter("demoFilter", ["$filter"], function ($filter) {
    return function (data: any): string {
        return data;
        if (data == null) {
            return null;
        }
        if (typeof data == 'string') {
            // TODO: When we drop ie8, use new Date(<string>date);
            data = "XXXXX";
            return data;
        }
        return null;
    };
});
 