﻿filter('language', ['localize'], function (localize) {
    'use strict';

    var languageMappings = {
        'en' : localize('Αγγλικά'),
        'el' : localize('Ελληνικά'),
        'gr' : localize('Ελληνικά')
    };

    return function (text) {
        return languageMappings[String(text).toLowerCase()];
    };
});
