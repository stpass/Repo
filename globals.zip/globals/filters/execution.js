﻿filter('execution', ["localize"], function (localize) {
    "use strict";

    var executionMappings = {
        'instant': 'Άμεση',
        'scheduled': 'Μεταχρονολογημένη'
    };

    return function (text) {
        if (text) {
            return localize(executionMappings[String(text)]);
        } else {
            return text; // return what ever came in: null or undefined
        }
    };
});
