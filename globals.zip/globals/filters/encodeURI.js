﻿filter('encodeURI', ['$window'], function ($window) {
    return function (text) {
        return $window.encodeURIComponent(String(text));
    };
});
