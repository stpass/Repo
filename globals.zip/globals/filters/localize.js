﻿filter("localize", ["localize"], function(localize) {
	"use strict";

	return function(input, moduleName) {
	    var res = localize(input, moduleName);
	    return res;
	};
});
