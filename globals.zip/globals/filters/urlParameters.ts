window.filter("urlParameters", ["$filter", "localize"], function ($filter, localize: ILocalizeService) {
    return {

        getParameter: function (urlParams: string, paramName: string) {
            if (urlParams == null || paramName == null || urlParams.trim() == '' || paramName == '') {
                return null;
            }
            var pairs: string[] = urlParams.split('&');
            if (pairs != null && pairs.length > 0) {
                var l = paramName.length + 1; 
                var s = paramName + "=";
                var i = _.find(pairs, function (item:string) {
                    return item.slice(0, l ) == s;
                });
                if (i != null) {
                    return i.slice(l);
                }
            }
            return null;
        } 
    }
});