﻿filter('currencySymbol', function() {
	'use strict';

	var currencyMappings = {
	    'EUR': '€',
	    'GRD': 'Δρχ',
	    'USD': '$',
	    'ALL': 'L'
	};

	return function (currency) {
	    if (currency) {
	        var mapped = currencyMappings[String(currency)];
	        if (mapped) currency = mapped;
	    }
	    return currency;
	};
});
