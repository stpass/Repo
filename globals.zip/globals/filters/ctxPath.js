﻿filter('ctxPath', ['ctxPath'], function (ctxPath) {
    return function (text) {
        return ctxPath(String(text));
    };
});
