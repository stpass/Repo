﻿filter('lookupText', function () {
    // lookupTable should be an array of object (default containing value and text properties).
    // Filter retrieves the item with the specified value and returns the text property
    // e.g.
    // model.value | lookupText:lookups.cardType:'value':'text'
    return function (value, lookupTable, valueName, textName) {
        if (!valueName) valueName = "value";
        if (!textName) textName = "text";
        for (var i = 0; i < lookupTable.length; i++) {
            if (lookupTable[i][valueName] == value)
                return lookupTable[i][textName];
        }
        // TODO: Inform Not found!
        return "";
    };
});
