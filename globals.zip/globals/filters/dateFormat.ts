﻿window.filter("dateFormat", ["$filter", "localize"], function ($filter, localize: ILocalizeService) {
    var MMMM = localize('mmmm', '').split(','); // '\x00,Ιανουάριος,Φεβρουάριος,Μαρτιος,Απρίλιος,Μάϊος,Ιούνιος,Ιούλιος,Αύγουστος,Σεπτέμβριος,Οκτώβριος,Νοέμβριος,Δεκέμβριος',
    var MMMM2ND = localize('mmmm2nd', '').split(','); // '\x01,Ιανουαρίου,Φεβρουαρίου,Μαρτίου,Απριλίου,Μαϊου,Ιουνίου,Ιουλίου,Αυγούστου,Σεπτεμβρίου,Οκτωβρίου,Νοέμβρίου,Δεκεμβρίου',
    var MMM = localize('mmm', '').split(','); //'\x02,Ιαν,Φεβ,Μαρ,Απρ,Μάϊ,Ιούν,Ιούλ,Αύγ,Σεπ,Οκτ,Νοέ,Δεκ',
    var dddd = localize('dddd', '').split(','); //'\x03,Κυριακή,Δευτέρα,Τρίτη,Τετάρτη,Πέμπτη,Παρασκευή,Σάββατο',
    var ddd = localize('ddd', '').split(','); //'\x04,Κυρ,Δευτ,Τρ,Τετ,Πέμ,Παρ,Σάβ',

    // parse ISO format date like 2013-05-06T22:00:00.000Z
    // IE 8 returns NaN in case of string
    function dateFromISO(s) {
        s = s.split(/\D/);
        //Date.UTC()
        return new Date(s[0], --s[1] || 0, s[2] || 1, s[3] || 1, s[4] || 0, s[5] || 0, s[6] || 0);
    }

    return function (date: any, format: string): string {
        if (date == null) {
            return null;
        }
        if (typeof date == 'string') {
            // TODO: When we drop ie8, use new Date(<string>date);
            date = dateFromISO(<string>date);
        }
        if (format != null) {
            return formatDate(date, format, false);
        }
        return null;
    };


    function formatDate(date:Date, format:string, utc:boolean) {

        function ii(i, len) {
            var s = i + "";
            len = len || 2;
            while (s.length < len) s = "0" + s;
            return s;
        }

        var y = utc ? date.getUTCFullYear() : date.getFullYear();
        format = format.replace(/(^|[^\\])yyyy+/g, "$1" + y);
        format = format.replace(/(^|[^\\])yy/g, "$1" + y.toString().substr(2, 2));
        format = format.replace(/(^|[^\\])y/g, "$1" + y);

        var M = (utc ? date.getUTCMonth() : date.getMonth()) + 1;
        format = format.replace(/(^|[^\\])MMMMND+/g, "$1" + MMMM2ND[0]);
        format = format.replace(/(^|[^\\])MMMM+/g, "$1" + MMMM[0]);
        format = format.replace(/(^|[^\\])MMM/g, "$1" + MMM[0]);
        format = format.replace(/(^|[^\\])MM/g, "$1" + ii(M, null));
        format = format.replace(/(^|[^\\])M/g, "$1" + M);

        var d = utc ? date.getUTCDate() : date.getDate();
        format = format.replace(/(^|[^\\])dddd+/g, "$1" + dddd[0]);
        format = format.replace(/(^|[^\\])ddd/g, "$1" + ddd[0]);
        format = format.replace(/(^|[^\\])dd/g, "$1" + ii(d, null));
        format = format.replace(/(^|[^\\])d/g, "$1" + d);

        var H = utc ? date.getUTCHours() : date.getHours();
        format = format.replace(/(^|[^\\])HH+/g, "$1" + ii(H, null));
        format = format.replace(/(^|[^\\])H/g, "$1" + H);

        var h = H > 12 ? H - 12 : H == 0 ? 12 : H;
        format = format.replace(/(^|[^\\])hh+/g, "$1" + ii(h, null));
        format = format.replace(/(^|[^\\])h/g, "$1" + h);

        var m = utc ? date.getUTCMinutes() : date.getMinutes();
        format = format.replace(/(^|[^\\])mm+/g, "$1" + ii(m, null));
        format = format.replace(/(^|[^\\])m/g, "$1" + m);

        var s = utc ? date.getUTCSeconds() : date.getSeconds();
        format = format.replace(/(^|[^\\])ss+/g, "$1" + ii(s, null));
        format = format.replace(/(^|[^\\])s/g, "$1" + s);

        var f = utc ? date.getUTCMilliseconds() : date.getMilliseconds();
        format = format.replace(/(^|[^\\])fff+/g, "$1" + ii(f, 3));
        f = Math.round(f / 10);
        format = format.replace(/(^|[^\\])ff/g, "$1" + ii(f, null));
        f = Math.round(f / 10);
        format = format.replace(/(^|[^\\])f/g, "$1" + f);

        var T = H < 12 ? "AM" : "PM";
        format = format.replace(/(^|[^\\])TT+/g, "$1" + T);
        format = format.replace(/(^|[^\\])T/g, "$1" + T.charAt(0));

        var t = T.toLowerCase();
        format = format.replace(/(^|[^\\])tt+/g, "$1" + t);
        format = format.replace(/(^|[^\\])t/g, "$1" + t.charAt(0));

        var tz = -date.getTimezoneOffset();
        var K = utc || !tz ? "Z" : tz > 0 ? "+" : "-";
        if (!utc) {
            tz = Math.abs(tz);
            var tzHrs = Math.floor(tz / 60);
            var tzMin = tz % 60;
            K += ii(tzHrs, null) + ":" + ii(tzMin, null);
        }
        format = format.replace(/(^|[^\\])K/g, "$1" + K);

        var day = (utc ? date.getUTCDay() : date.getDay()) + 1;
        format = format.replace(new RegExp(dddd[0], "g"), dddd[day]);
        format = format.replace(new RegExp(ddd[0], "g"), ddd[day]);

        format = format.replace(new RegExp(MMMM2ND[0], "g"), MMMM2ND[M]);
        format = format.replace(new RegExp(MMMM[0], "g"), MMMM[M]);
        format = format.replace(new RegExp(MMM[0], "g"), MMM[M]);

        format = format.replace(/\\(.)/g, "$1");

        return format;
    };
});
