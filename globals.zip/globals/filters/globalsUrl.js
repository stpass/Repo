﻿filter('globalsUrl', ['globalsUrl', 'imb'], function (globalsUrl, imb) {
    return function (text) {
        return globalsUrl + imb.addSlash(String(text));
    };
});