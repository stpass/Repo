﻿filter('baseUrl', ['baseUrl', 'imb'], function (baseUrl, imb) {
    return function (text) {
        return baseUrl + imb.addSlash(String(text));
    };
});
