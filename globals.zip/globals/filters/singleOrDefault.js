﻿filter('singleOrDefault', ['singleOrDefault'], function (singleOrDefault) {
    'use strict';

    return singleOrDefault;
});