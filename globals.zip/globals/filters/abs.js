﻿filter('abs', function () {

    return function (amount) {
        if (amount != null && typeof amount != 'undefined') {
            return Number(amount) > 0 ? Number(amount) : Number(amount) * -1;
        } else {
            return amount;
        }
    };
})