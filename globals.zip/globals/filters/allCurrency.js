﻿filter('allCurrency', ['$filter'], function ($filter) {
    'use strict';

    return function (text) {
        return String(text) + ' ' + $filter('currencySymbol')('ALL');
    };
});
