﻿filter('toDate', ['moment'], function (moment) {
    'use strict';

    return function (text) {
        if (text) {
            return moment(text).toDate();
        } else {
            return '';
        }
    };
});