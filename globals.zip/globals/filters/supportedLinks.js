﻿filter('supportedLinks', ['_'], function (_) {

    return function (links, type) {
        return _.filter(links, function(link) {
            return _.contains(link.supportedTypes, type);
        });
    };
})