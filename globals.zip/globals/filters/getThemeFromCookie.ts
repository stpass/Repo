window.filter("getThemeFromCookie", ["_"], function (_) {
    return function (): string {
        var themeName = "ibankTheme=";
        var fontName = "ibankFont=";
        var classValue;
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i].trim();
            if (c.indexOf(themeName) == 0) classValue += " " + c.substring(themeName.length, c.length);
        }
        classValue = classValue || "normal";
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i].trim();
            if (c.indexOf(fontName) == 0) classValue += " " + c.substring(fontName.length, c.length);
        }
        return classValue;
    };
}); 
 