﻿//Ελέγχει αν η λίστα των ρόλων του userProfile περιέχει κάποιον από τους 
//προαπαιτούμενους ρόλους (requiredRoles) προκειμένου πχ να δείξει κάποιο
//user interface element.
//Αν το requiredRoles ή το profileRoles είναι null τότε επιστρέφει false
//έτσι ώστε να μην εμφανίζονται πράγματα εαν δεν έχει ολοκληρωθεί η ανάκτηση 
//των στοιχείων.
window.filter("containsAnyRole", ["_"], function (_) {
    return function (profileRoles: string[], requiredRoles: string[]): boolean {
        if (requiredRoles != null && requiredRoles.length == 0) {
            return true; 
        }
        if (profileRoles == null || profileRoles.length == 0 || requiredRoles == null) {
            return false; 
        }
        return _.intersection(profileRoles, requiredRoles).length > 0;
    };
}); 


window.filter("notInRoles", ["_"], function (_) {
    return function (profileRoles: string[], excludedRoles: string[]): boolean {
        if (excludedRoles == null || excludedRoles.length == 0) {
            return true;
        }
        return _.intersection(profileRoles, excludedRoles).length == 0;
    };
}); 