﻿filter('capitaliseFirstLetter', function () {

    return function (str) {
        str = str || '';
        return String(str).charAt(0).toUpperCase() + str.slice(1);
    };
});