window.filter("urlParameters", ["$filter", "localize"], function ($filter, localize) {
    return {
        getParameter: function (urlParams, paramName) {
            if (urlParams == null || paramName == null || urlParams.trim() == '' || paramName == '') {
                return null;
            }
            var pairs = urlParams.split('&');
            if (pairs != null && pairs.length > 0) {
                var l = paramName.length + 1;
                var s = paramName + "=";
                var i = _.find(pairs, function (item) {
                    return item.slice(0, l) == s;
                });
                if (i != null) {
                    return i.slice(l);
                }
            }
            return null;
        }
    };
});
//# sourceMappingURL=urlParameters.js.map
