﻿filter('localCurrency', ['$filter'], function ($filter) {
    'use strict';

    return function (text) {
        return String(text) + ' ' + $filter('currencySymbol')('EUR');
    };
});
