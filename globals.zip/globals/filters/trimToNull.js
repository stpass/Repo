﻿filter('trimToNull', ['jQuery'], function ($) {

    return function (str) {
        if (str) {
            var trimmed =  $.trim(str);
            if (trimmed.length > 0) {
                return trimmed;
            }
        }
        return null;
    };
})