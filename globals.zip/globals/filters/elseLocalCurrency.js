﻿filter('elseLocalCurrency', ['$filter'], function ($filter) {
    'use strict';

    return function (currency) {
        if (currency === null || typeof(currency) === 'undefined') {
            currency = $filter('localCurrency')('');
        }
        return currency;
    };
});
