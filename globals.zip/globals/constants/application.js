﻿constant("application",
    (function () {
        return {
            APPL: "598A4414-395A-43D6-A9C3-D53A15E6E9F6",
            BANK: "NBG",
            CHANNEL: "internet"
        }
    })()    
);