﻿interceptor(['$window'], function ($window) {
    function detectInvalidSessionAndLogoff(response) {
        if (response && response.data) {
            var exception = response.data.exception || response.data.$exception || null;
            if (exception && exception.code === 'InvalidSession') {
                $window.imb.logoff().always(function () {
                    $window.setTimeout(function () {
                        $window.imb.preventLogoff();
                        // Do a page refresh to display login screen
                        $window.location.replace($window.imb.contextPath);
                    }, 10500);
                });
            }
        }
    }

    return function (promise) {
        promise.then(detectInvalidSessionAndLogoff);
        return promise;
    };
});