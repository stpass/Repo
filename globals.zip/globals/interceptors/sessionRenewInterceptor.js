﻿interceptor(['$rootScope'], function ($rootScope) {
    function success(response) {
        if (typeof response.config !== 'undefined' && response.config.method == 'POST') {
            // Only reset on XHR post responses
            $rootScope.$emit("sessionReset");
        }
        return response;
    }

    return function (promise) {
        return promise.then(success);
    };

});