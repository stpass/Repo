﻿interceptor(['$rootScope', '$q', "imb", "messageSvc","localize"], function (scope, $q, imb, messageSvc,localize) {
    function success(response) {
        return response;
    }

    function error(response) {
        var status = response.status;
        if (status == 401 || status == 302 ) { // 401 are translated to 302. 
            // We will ignore the address and refresh the page to get the actual redirect address
            // Refresh window in root in order to avoid any state keeping
            window.imb.preventLogoff();
            location.href = imb.contextPath;
            //location.reload();
            // It used to be that we notified the UI that user is not logged in
            // $rootScope.loggedIn = false;
        }else if (status >= 400) { // All server related errors 
            // The error is visible in the server logs. Perhaps we can remove it 
            imb.reportError("Server error: " + JSON.stringify(response, null), "HttpInterceptor", "");
            response.$systemMessage = messageSvc.addError(localize("genericError"));
        }
        // Reject error response
        return $q.reject(response);
    }

    return function (promise) {
        return promise.then(success, error);
    };

});