﻿/*
interceptor(['angular'], function (angular) {
    return function (promise) {
        return promise.then(
            function (response) {
                if (response && typeof response.payload !== 'undefined') {
                    return response.payload;
                } else {
                    return response;
                }
            },
            angular.identity
        );
    }
})
*/;