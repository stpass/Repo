﻿service('faqs', ['_', 'localize', '$filter'], function (_, localize, $filter) {
    var faqs = [
        'connectDisconnectAccount',
        'accountFriendlyName'
    ];

    return _.map(faqs, function (faq) {
        return {
            title: localize(faq),
            template: $filter('globalsUrl')('faqs/templates/' + faq + '.html')
        };
    });
});