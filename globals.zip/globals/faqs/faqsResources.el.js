﻿resources({
    'connectDisconnectAccount': 'Πώς μπορώ να αποσυνδέσω και να επανασυνδέσω ένα λογαριασμό μου;',
    'accountFriendlyName': 'Πώς μπορώ να δώσω φιλική ονομασία σε ένα λογαριασμό μου;',


});
