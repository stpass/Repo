﻿resources({
    'connectDisconnectAccount': 'How can I disconnect and reconnect an account?',
    'accountFriendlyName': 'How can I assign a friendly name to an account?',


});
