﻿window.controller('shell', ['$rootScope', '$scope', '$window', '$location', '$q', 'uiBlocker', 'userProfile', 'privateBanking', 'localize', '$routeParams'], function ($rootScope, $scope, $window, $location, $q, uiBlocker, userProfile, privateBanking, localize, $routeParams) {
    'use strict';

    $scope.$on('ChangeTitle', function (e, title) {
        $scope.title = title;
    });

    $scope.logoff = function () {
        window.imb.logoff().always(function () {
            window.imb.preventLogoff();

            // Do a page refresh to display login screen
            $window.location.replace(window.imb.contextPath);
        });
    };

    $scope.extendTime = function () {
        $rootScope.$emit("sessionReset");
        window.imb.reportError("extend time", "", 0);
    };

    $scope.changeLang = function (lang, event) {
        var $curTarget = $(event.currentTarget), $form;
        if ($curTarget.hasClass("active"))
            return;
        $form = $curTarget.parents("form:eq(0)");
        $form.children(":input").each(function () {
            var $this = $(this);
            if ($this.attr("name") === "page")
                $this.val($location.$$path);
            else if ($this.attr("name") === "lang")
                $this.val(lang);
        });
        window.imb.preventLogoff();
        $form.submit();
    };

    // Hide the splash screen
    $('#splash').hide();

    // Load the main view after 800ms
    var deregister = $scope.$on('$viewContentLoaded', function () {
        $('#container').show({
            effect: 'fade',
            easing: 'easeOutExpo',
            duration: 800
        });
        deregister();
    });

    // Show ui blicker when navigating
    // TODO: Check in slow machines if the loader appears even when then
    // transition to page is very fast
    var deferred = null;
    $scope.$on('$routeChangeStart', function (scope, next, current) {
        if (deferred != null)
            deferred.resolve(); // Resolve that
        deferred = $q.defer(); // Add a new ui blocker
        uiBlocker.block(deferred.promise);
    });

    // Remove breadcrumbs
    function routeChangeEnded(scope, next, current) {
        deferred.resolve();
        deferred = null;
        //var locationStr = "";
        //var locationArr = [];
        //var locParams;
        //locationStr = $location.path();
        //locParams=$routeParams;
        //locationArr = locationStr.split("/");
        //var locStr = "", tempStr = "";
        //if ($.isEmptyObject(locParams)) {
        //    for (var i = 0; i < locationArr.length; i++) {
        //        if (locationArr[i] != "" && locationArr[i] != null) {
        //            tempStr = tempStr == "" ? locationArr[i] : tempStr + "_" + locationArr[i];
        //            var localStr = localize(tempStr);
        //            locStr += localStr != null ? localStr + ">" : tempStr + ">";
        //        }
        //    }
        //    if (locStr !== "") {
        //        locStr = locStr.substring(0, locStr.length - 1);
        //        $scope.locationFullPath = locStr;
        //    }
        //}
    }
    ;
    $scope.$on('$routeChangeSuccess', routeChangeEnded);
    $scope.$on('$routeChangeError', routeChangeEnded);

    $scope.userProfile = userProfile.profile();

    //// Temp scrolling header until we get to fluent design.
    //$scope.previousScrollLeft = angular.element(window).scrollLeft();
    ////$scope.previousScrollTimeout = null;
    //$("#fixedHeader").css("margin-left", "auto");
    //angular.element(window).on('scroll', function () {
    //    if ($scope.previousScrollLeft !== angular.element(window).scrollLeft()) {
    //        $scope.previousScrollLeft = angular.element(window).scrollLeft();
    //        // If there is no scroll set margin to auto to center
    //        if (angular.element(window).scrollLeft() == 0) {
    //            //if ($scope.previousScrollTimeout != null) {
    //            //    // Prevent reseting to 0
    //            //    clearTimeout($scope.previousScrollTimeout);
    //            //    $scope.previousScrollTimeout = null;
    //            //}
    //            $("#fixedHeader").css("margin-left", "auto");
    //        } else {//}if ($scope.previousScrollTimeout == null) {
    //            if ($("#fixedHeader").css("margin-left") == "0px") {
    //                $("#fixedHeader").css("margin-left", 0); // For the 1st animation
    //            }
    //            //$scope.previousScrollTimeout = setTimeout(function() {
    //            //    $scope.previousScrollTimeout = null;
    //                $("#fixedHeader").css("margin-left", -1 * angular.element(window).scrollLeft());
    //            //}, 500);
    //        }
    //    }
    //});
    $scope.privateBankingLogOn = function () {
        privateBanking.privateBankingLogOn().$then(function (result) {
            if (result.data.succeeded) {
                document.cookie = result.data.tokenName + " = " + result.data.tokenValue + "; path=/;domain=.nbg.gr";

                //window.open(result.data.redirectUrl);
                window.location.href = result.data.redirectUrl;
            }
        });
    };
});
//# sourceMappingURL=shell.js.map
