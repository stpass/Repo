﻿controller('noop', [], function () {


});