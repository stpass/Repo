﻿controller("messages", ["$scope", "messageSvc", "jQuery"], function($scope, messageSvc, $) {
	"use strict";

	$.extend($scope, {
		messages: messageSvc.messages,
		closeMsg: closeMsg
	});

	function closeMsg(index) {
		$scope.messages[index].remove();
	}
});
