window.directive("onOffSwitch", ["$location", "$filter", "$parse"], function ($location, $filter, $parse) {
    "use strict";
    return {
        restrict: "AE",
        replace: false,
        templateUrl: $filter("globalsUrl")("/directives/onOffSwitch.html"),
        scope: {
            isNarrow: '@',
            leftSideLabel: '@',
            rightSideLabel: '@',
            onLeft: '&',
            onRight: '&',
            onChange: '&'
        },
        link: function (scope, element, attrs) {
            var getter = $parse(attrs.isChecked || 'true');
            scope.$parent.$watch(getter, function (value) {
                if (value === true) {
                    scope.isChecked = true;
                } else if (value === false) {
                    scope.isChecked = false;
                }
            });
            scope.$watch('isChecked', function (value) {
                if (getter.assign) {
                    getter.assign(scope.$parent, value);
                }

                if (value === true) {
                    scope.onLeft();
                } else if (value === false) {
                    scope.onRight();
                }

                if (typeof (value) !== 'undefined') {
                    scope.onChange({ isChecked: scope.isChecked });
                }
            });

            scope.toggleSwitch = function () {
                scope.isChecked = !scope.isChecked;
            };
        }
    };
});
//# sourceMappingURL=onOffSwitch.js.map
