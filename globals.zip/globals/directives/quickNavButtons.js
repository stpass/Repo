﻿window.directive("quickNavButtons", ["angular", "$filter", "$location", "quickNav", "$route"], function (angular, $filter, $location, quickNav, $route) {
    'use strict';

    return {
        restrict: 'A',
        templateUrl: $filter("globalsUrl")("/directives/quickNavButtons.html"),
        controller: [
            "$scope", function ($scope) {
                $scope.links = _.sortBy(quickNav.getLinks(), function (item) {
                    return -1 * item.sortOrder;
                });

                $scope.goToLink = function (link) {
                    var url = "/" + link.moduleName + link.linkUrl;
                    if (url == $route.current.prefixedRoute) {
                        $route.reload();
                    } else {
                        $location.url(url);
                    }
                };
                $scope.setHovered = function (link) {
                    $scope.hovered = link;
                };
                $scope.clearHovered = function (link) {
                    if ($scope.hovered == link) {
                        $scope.hovered = null;
                    }
                };
            }]
    };
});
//# sourceMappingURL=quickNavButtons.js.map
