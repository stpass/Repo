﻿window.directive('chkText', [], function () {
        return {
        require: ['ngModel', '^?form', '?invalidMessage'],
            link: function (scope: ng.IScope, elm, attrs: ng.IAttributes, ctrls: any[]) {
            var greekLower = 'αβγδεζηθικλμνξοπρστυφχψωάέήίόύώϊϋς'.split("");
            var greekUpper = 'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ'.split("");

            var ctrl = <ng.INgModelController>ctrls[0];
            var validChars = [];
            var toUpper = false;
            var toLower = false;
            var max = undefined;
            var min = undefined;
            var restoreValue: boolean = false; 
            var formCtrl = <ng.IFormController>ctrls[1];
            var messageHandler = ctrls[2];

            if (attrs != null) {
                if (attrs["max"] != null && parseInt(attrs["max"]) != null) {
                    max = parseInt(attrs["max"]);
                } 
                if (attrs["min"] != null && parseInt(attrs["min"]) != null) {
                    min = parseInt(attrs["min"]);
                } 
                if (attrs["greek"] != null) {
                    validChars = _.uniq(_.union(validChars, 'αβγδεζηθικλμνξοπρστυφχψωάέήίόύώϊϋς'.split(""), 'ΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩ'.split("")));
                }
                if (attrs["latin"] != null) {
                    validChars = _.uniq(_.union(validChars, 'abcdefghijklmnopqrstuvwxyz'.split(""), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split("")));
                }
                if (attrs["digits"] != null) {
                    validChars = _.uniq(_.union(validChars, '0123456789'.split("")));
                }
                if (attrs["toUpperCase"] != null) {
                    toUpper = true;
                }
                if (attrs["toLowerCase"] != null) {
                    toLower = true;
                }
                if (attrs["spaceChar"] != null) {
                    validChars = _.uniq(_.union(validChars, [" "]));
                }
                if (attrs["restoreValue"] != null) {
                    restoreValue = true;
                }
                attrs.$observe("chars", function (chars?: any) {
                    if (chars != null) {
                        validChars = _.uniq(_.union(validChars, chars.split("")));
                    }
                });
            }

            ctrl.$parsers.unshift(function (viewValue: string) {
                var currentValue = ctrl.$modelValue;
                if (max && viewValue!=null && viewValue.length > max) {
                    ctrl.$setValidity('chkText', false);                    
                    var message = "The maximum number of characters allowed is " + max;
                    (<any>ctrl).validationError = message;
                    if (messageHandler != null) {
                        messageHandler.setMessage(message);
                    }
                    if (restoreValue) {
                        ctrl.$setViewValue(currentValue);
                        ctrl.$render();
                        return currentValue;
                    }
                    else {
                        return undefined;
                    }
                }
                if (min && viewValue != null && viewValue.length < min) {
                    ctrl.$setValidity('chkText', false);
                    var message = "The minimum number of characters allowed is " + min;
                    (<any>ctrl).validationError = message;
                    if (messageHandler != null) {
                        messageHandler.setMessage(message);
                    }
                    if (restoreValue) {
                        ctrl.$setViewValue(currentValue);
                        ctrl.$render();
                        return currentValue;
                    }
                    else {
                        return undefined;
                    }
                }
                if (viewValue != null && _.difference(_.uniq(viewValue.split("")), validChars).length == 0) {
                    // it is valid
                    ctrl.$setValidity('chkText', true);
                    if (toUpper) {
                        var capitalized = viewValue.toUpperCase();
                        if (viewValue != capitalized) {
                            ctrl.$setViewValue(capitalized);
                            ctrl.$render();
                        }
                        return capitalized;
                    }
                    if (toLower) {
                        var lower = viewValue.toLowerCase();
                        if (viewValue != lower) {
                            ctrl.$setViewValue(lower);
                            ctrl.$render();
                        }
                        return lower;
                    }
                    return viewValue;
                } else if ( viewValue != null) {
                    // it is invalid, return undefined (no model update)
                    ctrl.$setValidity('chkText', false);
                    //(<any>ctrl).$setValidity('chkTextError', "invalid charactes: " + _.difference(_.uniq(viewValue.split("")), validChars).join);
                    var message = "Μη επιτρεπτοί χαρακτήρες: " + _.difference(_.uniq(viewValue.split("")), validChars).join("");
                    (<any>ctrl).validationError = message;
                    if (messageHandler != null) {
                        messageHandler.setMessage(message);
                    }
                    if (restoreValue) {
                        ctrl.$setViewValue(currentValue);
                        ctrl.$render();
                        return currentValue;
                    }
                    else {
                        return undefined;
                    }
                }
            });
        }
    }
    });
