﻿(function (window:Window) {
    var directiveName = 'animShow';

    window.directive(directiveName, [], function () {

        'use strict';

        return function (scope, elm, attrs) {
            scope.$watch(attrs[directiveName], function (value) {
                var show = Boolean(value);
                if (show) {
                    var effect = attrs[directiveName + 'Effect'];
                    var easing = attrs[directiveName + 'Easing'];
                    var duration = attrs[directiveName + 'Duration'];
                    if (duration != undefined) {
                        duration = parseInt(duration);
                    }
                    var completeExpr = attrs[directiveName + 'Complete'];
                    var complete;
                    if (completeExpr != undefined) {
                        complete = function () {
                            scope.$apply(completeExpr);
                        };
                    }
                    var options = {
                        effect: effect || 'fade',
                        easing: easing || 'easeInExpo',
                        duration: duration || 250,
                        complete: complete || undefined
                    };
                    elm.show(options);
                } else {
                    elm.css('display', 'none');
                }
            });
        };
    });
})(window);