﻿window.directive("quickNavButtons", ["angular", "$filter", "$location", "quickNav", "$route"],
    function (angular, $filter: ng.IFilterService, $location: ng.ILocationService, quickNav, $route) {

    'use strict';

    return {
        restrict: 'A',
        templateUrl: $filter("globalsUrl")("/directives/quickNavButtons.html"),
        controller: ["$scope", function ($scope) {
            $scope.links = _.sortBy(quickNav.getLinks(), (item:ILinkInfo) => { return -1 * item.sortOrder; });

            $scope.goToLink = function (link: ILinkInfo) {
                var url: string = "/" + link.moduleName + link.linkUrl;
                if (url == $route.current.prefixedRoute) {
                    $route.reload();
                } else {
                    $location.url(url);
                }
            };
            $scope.setHovered = function (link: ILinkInfo) {
                $scope.hovered = link;
            };
            $scope.clearHovered = function (link: ILinkInfo) {
                if ($scope.hovered == link) {
                    $scope.hovered = null;
                }
            };
        }]
    };
});