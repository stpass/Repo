﻿directive(
    'mainView',
    ['$', '$http', '$templateCache', '$route', '$anchorScroll', '$compile', '$controller', '$timeout'],
    function ($, $http, $templateCache, $route, $anchorScroll, $compile, $controller, $timeout) {
        'use strict';

        //var usersVoiceTemplate = "<div journal-preview.user-voice-link visible='{{visible}}' />";
        var uiBlocker = "<div class='main-view-ui-blocker-marker ui-blocker' style='display:none;'></div>";

        return {
            restrict: 'A',
            terminal: true,
            link: function (scope, element, attr) {
                var lastScope,
                    onloadExp = attr.onload || '';

                scope.$on('$routeChangeSuccess', update);
                update();

                function hideElement(complete) {
                    var options = {
                        effect: 'fade',
                        easing: 'easeInExpo',
                        duration: 500
                    };
                    if (complete) {
                        options.complete = complete;
                    }
                    $('.main-view-ui-blocker-marker', element).show();
                    element.hide(options);
                }

                function showElement(complete) {
                    var options = {
                        effect: 'fade',
                        easing: 'easeOutExpo',
                        duration: 500
                    };
                    if (complete) {
                        options.complete = complete;
                    }
                    element.show(options);
                }


                function destroyLastScope() {
                    if (lastScope) {
                        lastScope.$destroy();
                        lastScope = null;
                    }
                }

                function clearContent() {
                    hideElement();
                    destroyLastScope();
                }

                function update() {
                    var locals = $route.current && $route.current.locals,
                        template = locals && locals.$template,
                        body = angular.element('body'),
                        module = body.attr('module');

                    if (template) {
                        template = template + uiBlocker;
                        //usersVoiceTemplate +

                        hideElement(function () {
                            destroyLastScope();

                            element.html(template);

                            if (module) {
                                body.removeClass(module);
                                body.removeAttr('module');
                            }

                            var link = $compile(element.contents()),
                                current = $route.current,
                                controller;

                            lastScope = current.scope = scope.$new();

                            if (current.controller) {
                                locals.$scope = lastScope;
                                controller = $controller(current.controller, locals);
                                element.children().data('$ngControllerController', controller);
                            }

                            link(lastScope);

                            $timeout(function () {
                                if (lastScope) {
                                    showElement(function () {
                                        if (lastScope) {
                                            lastScope.$emit('$viewContentLoaded');
                                            lastScope.$eval(onloadExp);
                                        }
                                        // $anchorScroll might listen on event...
                                        $anchorScroll();
                                    });
                                }
                            }, 0);
                        });
                    } else {
                        clearContent();
                    }
                }
            }
        };
    }
);