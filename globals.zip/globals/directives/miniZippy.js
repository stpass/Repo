﻿directive('miniZippy', ['$', '$filter', '$parse'], function ($, $filter, $parse) {
    return {
        restrict: 'A',
        replace: false,
        transclude: true,
        scope: {
            title: '@zippyTitle',
            enabled: '@zippyEnabled'
            // zippyOpened (default -> true) can also be set like zippy-opened="false" (initially false, non-binded)
            // or zippy-opened="someScopeVariable" (bi-directionally binded)
        },
        templateUrl: $filter("globalsUrl")("/directives/miniZippy.html"),
        link: function (scope, element, attrs) {
            if (scope.enabled && scope.enabled === 'true') {
                scope.expandEnabled = true;
                var getter = $parse(attrs.zippyOpened || 'true');
                scope.$parent.$watch(getter, function (value) {
                    scope.opened = !!value;
                });
                scope.$watch('opened', function (value) {
                    if (getter.assign) {
                        getter.assign(scope.$parent, value);
                    }
                });
            } else {
                scope.opened = true
            }
        }
    };
});