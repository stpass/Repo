﻿directive("renderOnBlur", ["jQuery", "angular"], function ($, angular) {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            if (!ctrl) return;
            if (attrs.type === 'radio' || attrs.type === 'checkbox') return;
            elm.unbind('input').unbind('keydown').unbind('change');
            //How UI should be updated(Αναγκαστικά για να πάρω formatters)                        
            ctrl.$render = function () {
                var viewValue = ctrl.$modelValue;
                for (var i in ctrl.$formatters) {
                    viewValue = ctrl.$formatters[i](viewValue);
                }
                ctrl.$viewValue = viewValue;
                elm.val(viewValue);
            };            
            //Listen for change events only on blur
            elm.bind('blur', function () {                
                if (elm.val()) {
                    scope.$apply(function () {                        
                        ctrl.$setViewValue(elm.val()); /* reads the value from the view -> writes data to the model */                        
                        ctrl.$render();                        
                    });
                }
                else {
                    scope.$apply(function () {
                        ctrl.$setViewValue(''); /* reads the value from the view -> writes data to the model */
                        ctrl.$render();
                    });
                }
            });            
        }
    };
});