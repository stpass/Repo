﻿directive("valyear", ["jQuery", "angular"], function ($, angular) {

    var
        errMessage = "Λάθος Τιμή",
        format = function (value) {
            return value;
        },
		parse = function (value) {
		    if (value === null || !value) return true;
		    if (parseInt(value) != value) {
		        return false;
		    }
		    if (value.length != 4 || parseInt(value) < 1800) {
		        return false;
		    }
		    return true;
		};
    return {
        restrict: "A",
        require: ["validate", "ngModel"],
        link: function (scope, element, attrs, controllers) {
            var validateCtrl = controllers[0], ngModel = controllers[1];
            var fieldFormat = {
                name: "valyear",
                formatter: function (value, formatErrorCb) {
                    return format(value);
                },
                parser: function (value, formatErrorCb, element) {
                    var valid;
                    valid=parse(value);
                    formatErrorCb(valid, errMessage);
                    return value;
                }
            };
            validateCtrl.setFieldFormat(fieldFormat);
            element.addClass("text-right");
            errMessage = "Λάθος τιμή στο πεδίο " + $('label[for="' + attrs["id"] + '"]').html();
            element.on("change", function () {
                if (ngModel.$invalid) return;
                var formattedModel = format(ngModel.$modelValue);
                if (formattedModel !== ngModel.$viewValue) {
                    element.val(formattedModel);
                }
            });
        }
    };
});