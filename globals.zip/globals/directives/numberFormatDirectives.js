﻿(function(directive) {
	"use strict";

	function makeFieldFormat(name, format, parse, localize) {
		var fieldFormat = {
			name: name,
			formatter: function(value, formatErrorCb) {
				if( value == null || typeof(value) === "number" ) formatErrorCb(true, "");
				return format(value);
			},
			parser: function(value, formatErrorCb, element) {
				var num = null, valid, msg, parseErrorMsg;
				try {
					num = parse(value);
					valid = true;
				}
				catch(e) {
					if( e.message.indexOf("parse error") >= 0 ) {
						valid = false;
						parseErrorMsg = e.message;
					}
					else throw e;
				}
				if( valid ) {
					// format & reparse to match screen format and model (e.g. decimal points in amounts)
					num = format(num);
					num = parse(num);
				}
				if( parseErrorMsg != null ) msg = localize(parseErrorMsg);
				if( msg == null || msg === parseErrorMsg ) {
					msg = localize("valid_" + name);
					if( msg == null ) {
						localize.reportMissingResource("valid_" + name);
						msg = "!!!valid_" + name + "!!!";
					}
				}
				formatErrorCb(valid, msg);
				return num;
			}
		};
		return fieldFormat;
	}

	function makeNumberFormatterDirective(name, formatName, parseName) {
		directive(name, ["numberFormat", "localize"], function(numberFormat, localize) {
			var format = numberFormat[formatName](),
				parse = numberFormat[parseName](),
				fieldFormat = makeFieldFormat(name, format, parse, localize);

			return {
				restrict: "A",
				require: ["validate", "ngModel"],
				link: function(scope, element, attrs, controllers) {
					var validateCtrl = controllers[0], ngModel = controllers[1];
					validateCtrl.setFieldFormat(fieldFormat);
					var numberFormatDefaultStyles = attrs.numberFormatDefaultStyles || 'true';
					if (numberFormatDefaultStyles === 'true') {
					    element.addClass("text-right");
					}
					element.on("change", function () {			    
						if( ngModel.$invalid ) return;
						var formattedModel = format(ngModel.$modelValue);
						if( formattedModel !== ngModel.$viewValue ) {
							element.val(formattedModel);
						}
					});
				}
			};
		});
	}

	makeNumberFormatterDirective("amount", "makeTextFieldAmountFormatter", "makeTextFieldAmountParser");
	makeNumberFormatterDirective("stockAmount", "makeTextFieldStockAmountFormatter", "makeTextFieldStockAmountParser");
	makeNumberFormatterDirective("integer", "makeTextFieldIntFormatter", "makeTextFieldIntParser");
})(window.directive);
