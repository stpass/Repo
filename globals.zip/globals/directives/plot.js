﻿directive(
    'plot',
    ['jQuery', '$q', '$timeout', '$window'],
    function ($, $q, $timeout, $window) {
        'use strict';

        return {
            restrict: 'A',
            scope: {
                source: '=',
                factory: '='
            },
            terminal: true,
            link: function (scope, elm, attrs) {
                function plotContext() {
                    return { source: scope.source, factory: scope.factory };
                }

                function updatePlot(plotContext) {
                    if (plotContext.source) {
                        var plotContext = scope.factory(plotContext.source);
                        elm.plot(plotContext.data, plotContext.options);
                    }
                }

                // do it inside a timeout so that elm has been rendered
                // and has width and height.
                $timeout(function () {
                    scope.$watch(plotContext, updatePlot, true);
                }, 0);
            
                scope.$on('$destroy', function () {
                    if (elm.unbind) elm.unbind();
                });
            }
        };
    }
);