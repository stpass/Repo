window.directive("onOffSwitch", ["$location", "$filter", "$parse"],
    function ($location: ng.ILocationService, $filter: ng.IFilterService, $parse: ng.IParseService) {
        "use strict";
        return {
            restrict: "AE",
            replace: false,
            templateUrl: $filter("globalsUrl")("/directives/onOffSwitch.html"),
            scope: {
                isNarrow: '@',
                leftSideLabel: '@',
                rightSideLabel: '@',
                onLeft: '&',
                onRight: '&',
                onChange: '&'
                // isChecked (default -> true) can also be set like is-checked="false" (initially false, non-binded)
                // or is-checked="someScopeVariable" (bi-directionally binded)
            },
            link: function (scope, element, attrs) {
                var getter = $parse(attrs.isChecked || 'true');
                scope.$parent.$watch(getter, function (value) {
                    if (value === true) {
                        scope.isChecked = true;
                    } else if (value === false) {
                        scope.isChecked = false;
                    }
                });
                scope.$watch('isChecked', function (value) {
                    if (getter.assign) {
                        getter.assign(scope.$parent, value);
                    }

                    if (value === true) {
                        scope.onLeft();
                    } else if (value === false) {
                        scope.onRight();
                    }

                    if (typeof(value) !== 'undefined') {
                        scope.onChange({ isChecked: scope.isChecked });
                    }
                });

                scope.toggleSwitch = function () {
                    scope.isChecked = !scope.isChecked;
                }
            }
        };
    });
