﻿/**
 * Attach the "busy" behaviour to a block element.
 *
 * It depends on a boolean expression. When true, the content of the given block
 * element will be hidden and its background will change to a spinner.
 *
 * If the element is visible when the transition (busy <--> not busy) happens,
 * a height change animation will be performed.
 *
 * The default busy class is `busy48`. It can be overriden by specifying the
 * `busy-class` attribute.
 *
 * ALL BUSY CLASSES MUST END TO A NUMBER MATCHING THEIR HEIGHT, I.E. busy48
 * WILL BE 48 PIXELS HIGH. It *is* possible to measure the height of an element
 * having a given CSS class, but it would complicate the code. Revise if necessary.
 *
 * Example usage:
 * <div busy="ownAccounts == null">
 *   <div ng-repeat="ownAccount in ownAccounts">
 *     ...
 */
(function(setTimeout) {
	"use strict";

	function determineBusyClass(element, attrs) {
		return attrs.busyClass || "busy48";
	}

	function determineBusyHeight(busyClass) {
		return parseInt(busyClass.substring("busy".length));
	}

	function doBusyTransition(wrapper, element, oldBusy, newBusy, busyClass, busyHeight) {
	    var visible = wrapper.is(":visible");
	    if (newBusy) {
	        wrapper.addClass("busy-busy " + busyClass);
	        wrapper.css("overflow", "hidden");
	        if (visible) {
	            wrapper.animate({ height: busyHeight }, function () {
	                wrapper.css("height", busyHeight); // safety: even if the height calculation was wrong, show it
	            });
	        }
	        else wrapper.css("height", busyHeight);
	    }
	    else {
	        wrapper.removeClass("busy-busy " + busyClass);
	        if (visible) {
	            setTimeout(function () {
	                // height would not be calculated correctly for floats, this is a workaround
	                wrapper.animate({ height: element.height() }, function () {
	                    wrapper.css("height", ""); // safety: even if the height calculation was wrong, show it
	                    wrapper.css("overflow", "");
	                });
	            }, 100);
	        }
	        else {
	            wrapper.css("height", "");
	            wrapper.css("overflow", "");
	        }
	    }
	}


	directive("busy", ["jQuery"],
		function($) {

			return {
				restrict: "A",

				link: function(scope, element, attrs) {
					var
						wrapper,
						busyClass = determineBusyClass(element, attrs),
						busyHeight = determineBusyHeight(busyClass);

					element.removeClass(busyClass).addClass("busy-content");
					wrapper = element.wrap("<div class='busy-container'></div>").parent();
					scope.$watch(attrs.busy, function(newval, oldval) {
						doBusyTransition(wrapper, element, oldval, newval, busyClass, busyHeight);
					});
				}
			};
		}
	);

})(window.setTimeout);
