﻿/**
 * The side-popup.
 */
directive("sidePopup", ["jQuery", "$rootScope", "sidePopupSvc"], function($, $rootScope, sidePopupSvc) {

	var HIDDEN="HIDDEN", SHOWING="SHOWING", SHOWN="SHOWN", HIDING="HIDING";

	function SidePopup(element, scope, sidePop) {
		this.element = element;
		this.scope = scope;
		this.sidePop = sidePop;
		this.popupContainer = element.parent();
		this.state = HIDDEN;
		this.docClickHandler = null;
		this.anchorElement = null;
		SidePopup.instances.push(this);
	}

	SidePopup.instances = [];

	SidePopup.prototype.show = function (anchorElement) {
		if( this.state === SHOWING || this.state === SHOWN ) return;

		var i, self = this, select2OffscreenFlag = false;

		for( i=0; i < SidePopup.instances.length; i++ ) {
			SidePopup.instances[i].forceHide();
		}

		self.isShowingNormal() ? this.animationType = 'slideInLeft' : this.animationType = 'slideInDown';
	
		this.anchorElement = anchorElement;
		this.state = SHOWING;
        
		self.showPopupOverlay()
		$(this.popupContainer).addClass("opened");  // Opened class is added for inline display in small screens
	    $(this.element).removeClass('fadeOutUp').addClass(this.animationType)
            .one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function () {  // Callback called on Css animation finish.
                self.state = SHOWN;
                // Prevent Error $apply in progress
                if (self.scope.$root.$$phase != '$apply' && self.scope.$root.$$phase != '$digest') {
                    self.scope.$apply();
                }
                self.element.removeAttr('style');

                //})
                //.position({
                //	my: "left top",
                //	at: "right top",
                //	of: anchorElement,
                //	collision: "flip",
                //	using: function (position, feedback) {
                //	    //self.element.removeAttr('style');
                //		self.element.css({
                //			//position: "absolute",
                //			left: position.left,
                //			top: 0
                //		});
                //	}
            });

		this.docClickHandler = docClickHandler;
		$(document).on("click", docClickHandler);

		function docClickHandler(event) {
			if( event.which !== 1 ) return; // only take into account left button events
			if( sidePopupSvc.getIgnoreDocumentClicks() ) return; // document clicks actively ignored

			var $t = $(event.target);
			if( (self.sidePop.currentEvent == null
					&& !select2OffscreenFlag)
				// XXX  Hack: When clicking the select2 button, IE generates a click on the <body>.
				// XXX  We need to ignore this. No other browser seems to generate a <body> click...
				&& !$t.is("body")
			) {
				$(document).off("click", docClickHandler);
				self.forceHide();
				self.docClickHandler = null;
				self.hidePopupOverlay();
			}

			// XXX  Hack: When a select2 option is clicked, we receive 2 events, one from
			// XXX  the .select2-offscreen input and one from the document. The second one
			// XXX  fires the hide and we do not want this, so we keep the currentEvent.
			select2OffscreenFlag = $t.hasClass("select2-offscreen");
			// XXX  ...but IE does not fire the second event, so if we select an option
			// XXX  in select2 and then click outside the popup, the event will be silenced.
			// XXX  Hopefully there will be no 2nd click _from the user_ within 20ms.
			// XXX  (Unless user === Flash)
			setTimeout(function() {
				select2OffscreenFlag = false;
			},20);

			self.sidePop.currentEvent = null;

			$rootScope.$apply();
		}
	};

	SidePopup.prototype.hide = function () {
		if( this.state === HIDING || this.state === HIDDEN ) return;
		var self = this, el;
		this.state = HIDING;
		if( this.docClickHandler ) $(document).off("click", this.docClickHandler);
		this.docClickHandler = null;

	    // Animation class is removed 
		$(this.element).removeClass(this.animationType);
	    // Opened class is removed for inline display in small screens
		$(this.popupContainer).removeClass('opened');

	    //function () {
		//    // Remove attribute to return to original state 
		//    $(self.element).removeAttr("style");
		//    // Prevent Error $apply in progress
		//    self.state = HIDDEN;
		//    if (self.scope.$root.$$phase != '$apply' && self.scope.$root.$$phase != '$digest') {
		//        self.scope.$apply();
		//    }
		//});
		self.state = HIDDEN;
		el = $(this.anchorElement).parent().parent().parent();
		if( !el.is(".form-group") ) el = this.anchorElement;
		if( !$.isInView(el) ) $.scrollTo(el,1200,{ easing:"easeOutExpo", axis:"y" });
		this.anchorElement = null;

		self.hidePopupOverlay();
	};

	SidePopup.prototype.forceHide = function () {
	    if (this.state !== HIDDEN) {

	        // Animation class is removed  
	        $(this.element).removeClass(this.animationType);
	        // Opened class is removed for inline display in small screens
	        $(this.popupContainer).removeClass('opened');

			this.state = HIDDEN;
			if( this.docClickHandler ) $(document).off("click", this.docClickHandler);
			this.docClickHandler = null;
			this.anchorElement = null;
		}
	};

	SidePopup.prototype.isShownOrShowing = function() {
		return this.state === SHOWN || this.state === SHOWING;
	};

	SidePopup.prototype.cleanUp = function() {
		this.forceHide();
		if( this.docClickHandler ) $(document).off("click", this.docClickHandler);
		this.docClickHandler = null;
	};

	SidePopup.prototype.isShowingNormal = function () {
	    // Screen larger  than 900px
	    return this.popupContainer.css('position') === 'absolute';
	};

	SidePopup.prototype.showPopupOverlay = function () {
	    sidePopupSvc.setOpened(true);
	};

	SidePopup.prototype.hidePopupOverlay = function () {
	    sidePopupSvc.setOpened(false);
	};

	var nullFormCtrl = {
		$addControl: $.noop,
		$removeControl: $.noop,
		$setValidity: $.noop,
		$setDirty: $.noop,
		$setPristine: $.noop
	};


	return {
		restrict: "A",
		replace: true,
		transclude: true,
		template: "<div class='side-popup-container'><div class='side-popup animated with-shadow'><div ng-transclude></div></div></div>",

		require: "^sidePop",

		compile: function(element, attrs, transclude) {
			return {
				pre: function(scope, element, attrs, sidePop) {
					// XXX  A nested form notifies its parent about its valid status; so if a nested
					// XXX  form is invalid, its parent is invalid too. In our case there may be forms
					// XXX  inside the side-popup that mey be structurally (DOM) nested but are conceptually
					// XXX  independent. Therefore we (hackishly) apply a dummy-nop form controller to
					// XXX  this element to insulate any structurally child forms from any parent form.
					// XXX  The hack here is that angular.element.controller() is getter only - if it was
					// XXX  setter we would do element.controller("form",nullFormCtrl). So we recreate
					// XXX  the name that Angular gives to the controller. If they change it, we are screwed.
					//
					// XXX  Why set the data here? In some occasion (I haven't figured it out) a nested
					// XXX form controller would get applied _before_ this, and the validation would escape.
					element.data("$formController", nullFormCtrl);
				},
				post: function(scope, element, attrs, sidePop) {
				    scope.sidePopup = new SidePopup(element.find('.side-popup'), scope, sidePop);
					sidePop.registerPopup(scope.sidePopup);
					scope.$on("$destroy", function() {
						for( var i=0; i < SidePopup.instances.length; i++ ) {
							if( SidePopup.instances[i] === scope.sidePopup ) {
								SidePopup.instances.splice(i,1);
								return;
							}
						}
						scope.sidePopup.cleanUp();
					});
				}
			};
		}
	};
});

directive("sidePopupOverlay", ["sidePopupSvc"], function (sidePopupSvc) {
    return {
        restrict: "A",
        scope: true,
        link: function (scope, element, attr) {
            var overlay = angular.element("<div class='side-popup-overlay fade'></div>");

            element.css('position', 'relative');
            element.append(overlay);

            scope.$watch(sidePopupSvc.getOpened, function (newVal, oldVal) {
                if (newVal !== oldVal) {
                    overlay.fadeToggle();
                }
            });
        }
    };
});
