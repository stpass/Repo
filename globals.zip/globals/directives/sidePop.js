﻿/**
 * Directive-wrapper to activate the side popup functionality, e.g. in the accounts selection box.
 */
directive("sidePop", [], function() {
	"use strict";

	function SidePopCtrl($scope) {
		this.popup = null;
		this.currentEvent = null;
		this.anchorElement = null;
		
		var self = this;

		$scope.$watch(
			function() {
				if( self.popup == null ) return false;
				return self.popup.isShownOrShowing();
			},
			function(newval) {
				$scope.active = newval;
			}
		);

		$scope.$watch(
			function() {
				if( self.popup == null ) return null;
				return $scope.active;
			},
			function(newval) {
			    if (self.popup != null) newval ? self.popup.show(self.anchorElement) : self.popup.hide();
			}
		);
	}

	SidePopCtrl.prototype.clicked = function() {
		if( this.popup != null ) this.popup.show(this.anchorElement);
	};

	SidePopCtrl.prototype.registerPopup = function(popup) {
		if( this.popup != null ) throw new Error("called registerPopup more than once");
		if( popup == null ) throw new Error("tried to register non-existing popup");
		this.popup = popup;
	};

	SidePopCtrl.prototype.registerAnchorElement = function(element) {
		if( this.anchorElement != null ) throw new Error("called registerAnchorElement more than once");
		if( element == null ) throw new Error("tried to register non-existing element");
		this.anchorElement = element;
	};


	return {
		restrict: "A",

		transclude: true,
		template: "<div><div ng-transclude></div></div>",

		require: "sidePop",
		scope: {
			active: "=?"
		},

		link: function(scope, element, attrs, sidePop) {
			element.addClass("clearfix side-pop");
			element.on("click", function(event) {
				sidePop.currentEvent = event;
			});
		},

		controller: ["$scope", SidePopCtrl]
	};
});
