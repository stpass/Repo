﻿directive('scopePrettyPrint', ['$parse'], function ($parse) {
    // syntax highlight taken from here: http://stackoverflow.com/a/7220510/2942409
    function syntaxHighlight(json) {
        if (typeof json === "string") {
            try{
                var json = JSON.parse(json);
            }
            catch(err){
                return '<span class="syntaxHighlight">' + json + '</span>';
            }
        }

        json = JSON.stringify(json, undefined, 2);
        json = json.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        return json.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, function (match) {
            var cls = 'number';
            if (/^"/.test(match)) {
                if (/:$/.test(match)) {
                    cls = 'key';
                } else {
                    cls = 'string';
                }
            } else if (/true|false/.test(match)) {
                cls = 'boolean';
            } else if (/null/.test(match)) {
                cls = 'null';
            }
            return '<span class="' + cls + '">' + match + '</span>';
        });
    }

    return {
        restrict: 'AE',
        terminal: true,
        replace: true,
        template: '<pre class="syntaxHighlight"></pre>',
        link: function (scope, elem, attrs) {
            var object = null;

            if (attrs.path) {
                // path was defined, deep-watch it's getter and on every update -> update local object
                scope.$watch($parse(attrs.path), function (newVal) { object = newVal; }, true);
            } else {
                // path was not defined, on every digest -> clean scope from angular stuff and update local object
                scope.$watch(function () {
                    var json = {}, prop;
                    for (prop in scope) {
                        if (prop.indexOf('$') !== 0 && prop !== 'this') {
                            json[prop] = scope[prop];
                        }
                    }
                    object = json;
                });
            }

            // if our local object somehow gets updated internally, re-render        
            scope.$watch(
              function () {
                  return object;
              },
              function reRender() {
                  if (typeof (object) !== 'undefined') {
                      elem.html(syntaxHighlight(object));
                  } else {
                      elem.html('<em>"' + attrs.path + '" is undefined</em>');
                  }
              },
              true
            );
        }
    };
});
