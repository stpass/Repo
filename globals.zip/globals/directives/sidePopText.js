﻿/**
 * Does the side-popup text formatting and listens for the click event
 * to notify the sidePop and display the popup.
 */
directive("sidePopText", [], function() {
	"use strict";

	return {
		restrict: "A",
		replace: true,
		transclude: true,
		template:
			'<div class="side-pop-input">' +
				'<div class="side-pop-input-text clearfix" ng-transclude></div>' +
				//'<div class="side-pop-input-btn">' +
				//	'<i class="glyphicon glyphicon-chevron-right"></i>' +
				//'</div>' +
			'</div>',

		require: "^sidePop",

		link: function(scope, element, attrs, sidePop) {
			sidePop.registerAnchorElement(element);
			element.bind("click", function(event) {
				sidePop.clicked();
			});
		}
	};
});
