﻿directive("responsiveMenufy", [], function () {
    return {
        restrict: 'A',
        transclude: false,
        link: function (scope, element, attrs, accordionCtrl) {
            // Initialize element styles
            element.addClass("menufy").addClass("closed");
            var buttonContainer = angular.element('<span class="toggle-menufy"><div class="toggle-btn">' +
                //'<a class="glyphicon glyphicon-align-justify">&nbsp;</a>' +
                    '<div class="menu-stripe"></div>' +
                    '<div class="menu-stripe"></div>' +
                    '<div class="menu-stripe"></div>' +
                    '<div class="menu-stripe"></div>' +
                '</div><div class="dimmer"/></span>');
            element.parent().append(buttonContainer);
            var toggleVisibility = function (e) {
                element.toggleClass("closed");
                buttonContainer.toggleClass("opened"); 
            };
            buttonContainer.children(".toggle-btn").click(toggleVisibility);
            buttonContainer.children(".dimmer").click(toggleVisibility);
        }
    };
});