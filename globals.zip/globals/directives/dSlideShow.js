﻿directive("dSlideShow", [], function () {
    return ({
        link: link,
        restrict: 'A',
        scope: {
            show: '=isVisible',
            duration: '=slideShowDuration'
        }
    });
    function link($scope, element, attributes) {
        $scope.$watch('isVisible', function (newValue, oldValue) {
            if (newValue === oldValue)
            {                
                return;
            }
            if (newValue)
            {             
                //element.stop(true, true).slideDown($scope.duration);
                element.stop(true, true).fadeIn($scope.duration);
                
            }
            else
            {
                //element.stop(true, true).slideUp($scope.duration);
                element.stop(true, true).fadeOut($scope.duration);
            }
        })
    }
});