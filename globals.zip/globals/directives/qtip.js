﻿(function() {
	"use strict";


	/**
	 * Define the qtip directive for integrating QTip with angular.
	 *
	 * Defines its own, isolated scope. The scope is extended with the data returned
	 * by the qtip expression.
	 *
	 * Attributes:
	 * - qtip: The data to display in the qtip. It is evaluated as angular
	 *   expression with possible return types:
	 *   - string: It will be shown as is
	 *   - object: It will be used to feed the template, see qtip-view attribute
	 *   - promise returning any of the above: It will be handled when it is resolved
	 *   If any result (immediate or promise) is "falsey", the qtip will not be shown.
	 * - qtip-view: If this attribute exists, it is an angular expression
	 *   to locate a view template. If it exists, the qtip must return object which
	 *   will extend the scope of the qtip.
	 * - qtip-position: (optional) Position the qtip relative to the element.
	 *   Default value is "rc@lc". Formats:
	 *   - "xx@yy": where "xx" is the "my" property and "yy" the "at" property.
	 *     Example: "tl@c" stands for { my: "top left", at: "center" }.
	 *   - "xx@yy(selector)": The selector is a jQuery selector to identify the
	 *     position.target property, xx, yy as above.
	 *   - "xx@yy(selector,this)": As above, but the selector runs relative to
	 *     this element. Selector is optional, the comma is not, e.g. "tl@c(,this)"
	 *     is valid and equivalent to "tl@c".
	 *   - "xx@yy(selector,parent)": As above, but the selector runs relative to
	 *     the parent of this element. Selector is optional, the comma is not,
	 *     e.g. "tl@c(,parent)" will position the qtip relative to the center of the
	 *     parent of the element the directive is applied.
	 *   - "xx(o1,o2,o3)@yyyy": This format specifies offset, both for the tooltip itself and
	 *     for the arrow. The "xx" and "yyyy" may be anything valid, as described above.
	 *     The parentheses after "xx" contain the x-offset (`adjust.x`), y-offset (`adjust.y`)
	 *     and arrow offset (`style.tip.offset`). Any one of o1, o2, o3 may be ommitted, but
	 *     the comma must remain. Examples: "tl(-4,,7)@bc", "tr(5,5,10)@bl(,parent)".
	 * - qtip-title: (optional) The title, may be promise. Evaluated in the external scope.
	 * - qtip-title-inner: (optional) The title, may NOT be promise. Evaluated in the
	 *   isolated scope of the component and is only valid if qtip-view is also specified.
	 *   IF BOTH qtip-title AND qtip-title-inner ARE SPECIFIED, qtip-title TAKES PRECEDENCE.
	 *   If the title expression returns falsey value, the title is hidden.
	 * - qtip-opts: (optional) Extra qtip options to be mixed in the qtip configuration
	 *   object. Must be JS literal, i.e. not promise.
	 *   See: http://craigsworks.com/projects/qtip2/docs/position/
	 */
	var
		QTIP_COMMON_OPTIONS = {
			show: {
				solo: true,
				delay: 350   // WATCH OUT: http://craigsworks.com/projects/forums/thread-solved-ipad-show-delay-breaks-qtip-display
			},
			content: {
				title: {
					text: false,
					button: false
				},
				text: "<p class='loading busy48'>Loading</p>"
			},
			position: {
				my: "right center",
				at: "left center",
				effect: false,
				viewport: true,
				adjust: {
					method: "flipinvert flipinvert"
				}
			},
			hide: {
// usefull for styling - disabled hiding the tooltip when the mouse moves out
//				event: false,
				fixed: true
			}
		},
		
		QTIP_POSITION_KEYS = {
			"t": "top",
			"b": "bottom",
			"c": "center",
			"l": "left",
			"r": "right"
		},
		
		allPositionKeys = "", x, positionRegExp;
	
	for( x in QTIP_POSITION_KEYS ) {
		if( !QTIP_POSITION_KEYS.hasOwnProperty(x) ) continue;
		allPositionKeys += x;
	}
	positionRegExp = new RegExp("([" + allPositionKeys + "]{1,2})(?:\\(([+-]?[0-9]+)?,([+-]?[0-9]+)?,([+-]?[0-9]+)?\\))?@([" + allPositionKeys + "]{1,2})(?:\\(([^,]+)?(?:,(this|parent))?\\))?");
	
	function parsePosition(p,element) {
		var match, my, at, target, context, ret, adjust_x, adjust_y, tip_offset,
			INDEX_MY = 1, INDEX_ADJX = 2, INDEX_ADJY = 3, INDEX_TIPOFFSET = 4,
			INDEX_AT = 5, INDEX_TARGET = 6, INDEX_CONTEXT = 7, MATCH_LENGTH = 8;
		
		if( typeof(p) !== "string" ) return {};
		
		match = positionRegExp.exec(p);
		if( match == null || match.length !== MATCH_LENGTH ) return {};
		
		my = parsePositionExpression(match[INDEX_MY]);
		at = parsePositionExpression(match[INDEX_AT]);
		// When an optional group does not exist in IE8, the corresponding place in
		// match[] gets an empty string instead of undefined, thus the "|| null".
		target = match[INDEX_TARGET] || null;
		context = match[INDEX_CONTEXT] || null;
		adjust_x = match[INDEX_ADJX] || null;
		adjust_y = match[INDEX_ADJY] || null;
		tip_offset = match[INDEX_TIPOFFSET] || null;
		
		if( my == null || at == null ) return {};
		
		ret = {
			position: {
				my: my,
				at: at
			}
		};
		if( adjust_x !== null ) {
			ret.position.adjust = ret.position.adjust || {};
			ret.position.adjust.x = parseInt(adjust_x);
		}
		if( adjust_y !== null ) {
			ret.position.adjust = ret.position.adjust || {};
			ret.position.adjust.y = parseInt(adjust_y);
		}

		if( tip_offset !== null ) ret.style = { tip: { offset: parseInt(tip_offset) } };
		
		if( target != null || context != null ) {
			if( context === "this" ) context = element;
			else if( context === "parent" ) context = element.parent();
			if( target == null ) ret.position.target = context;
			else if (context != null) ret.position.target = $(target, context);
			else ret.position.target = $(target);
		}
		
		return ret;
	}
	
	function parsePositionExpression(e) {
		var i, val, res = "";
		
		for( i=0; i < e.length; i++ ) {
			val = QTIP_POSITION_KEYS[e.charAt(i)];
			if( typeof(val) !== "string" ) return null;
			if( i > 0 ) res += " ";
			res += val;
		}
		
		return res;
	}
	
	directive("qtip", ["$http", "$compile", "$templateCache", "$timeout", "$q", "angular"], function ($http, $compile, $templateCache, $timeout, $q, angular) {
		return {
			link: function(scope, element, attrs) {
				var
					viewUrl = attrs.qtipView && scope.$eval(attrs.qtipView),
					opts = (attrs.qtipOpts && scope.$eval(attrs.qtipOpts)) || {},
					hidden = true,
					newScope;
				
				function onShow(event, api) {
				    // TODO: Bug if qtip is text, I get Lexar exception
					// NO BUG: Read the docs (top), it is evaluated as Angular expression; if it is a plain string use
					// <xxx qtip="'The tooltip'"> (just as ng-include @src - http://docs.angularjs.org/api/ng.directive:ngInclude )
					var
						result = scope.$eval(attrs.qtip),
						title = (attrs.qtipTitle != null ? scope.$eval(attrs.qtipTitle) : false),
						templateResponse = viewUrl && $http.get(viewUrl, {cache: $templateCache});
					
					hidden = false;
					
					if( !result ) {
						// immediate "falsey" response, do not even bother to show (it will only flicker annoyingly)
						event.preventDefault();
					}
					else {
						$timeout(function() { // we need to $apply() in the case [result=string, templateResponse=undefined]
							$q.all([result, templateResponse, title]).then(function(array) {
								if( hidden ) return;
								
								var data = array[0], template = array[1] && array[1].data, titleData = array[2],
									linkFn, content;
								
								if( viewUrl ) {
									linkFn = $compile(angular.element(template));
									newScope = scope.$new(true);
									content = linkFn(angular.extend(newScope, data));
									if( !titleData && attrs.qtipTitleInner ) {
										titleData = newScope.$eval(attrs.qtipTitleInner) || false;
									}
								}
								else content = data;
								
								if( data ) {
									if( api.get("hide.event") !== "mouseleave" && titleData !== false && titleData !== "" ) {
										api.set("content.title.text", titleData);
										api.set("content.title.button", true);
									}
									else {
										api.set("content.title.text", titleData);
										api.set("content.title.button", false);
									}
									api.set("content.text", content);
									$timeout(function() { api.reposition(); },0);
								}
								else {
									// "falsey" result, hide it (we are in a timeout, so event.preventDefault() would not work)
									api.hide();
								}
							},
							function error() {
								api.set("content.text", "ERROR");
//								api.reposition();
							});
						}, 0);
					}
				}
				
				function onHide(event, api) {
					hidden = true;
				}
				
				function onHidden(event, api) {
					api.set("content.title", QTIP_COMMON_OPTIONS.content.title);
					api.set("content.text", QTIP_COMMON_OPTIONS.content.text);
					if (newScope) {
					    newScope.$destroy();
					    newScope = null;
					}
				}
				
				element
					.qtip($.extend(true, {}, QTIP_COMMON_OPTIONS, parsePosition(attrs.qtipPosition,element), opts, {
						events: {
							show: onShow,
							hide: onHide,
							hidden: onHidden
						}
					}));
			}
		};
	});


})();
