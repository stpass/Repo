window.directive('onBlur', ['$parse'], function ($parse) {
    "use strict";

    return {
        restrict: "A",
        link: function (scope: ng.IScope, elem: ng.IAugmentedJQuery, attrs: any) {
            var expr = $parse(attrs.onBlur);
            elem.bind('blur', function (event) {
                scope.$apply(function () {
                    expr(scope, { $event: event });
                });
            });
        }
    };
});
