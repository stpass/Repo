﻿window.directive('mainMenu', ['$compile', "$filter", '$location', 'localize' ], function ($compile, $filter:ng.IFilterService, $location:ng.ILocationService, localize:ILocalizeService ) {
    'use strict';

    return {
        restrict: 'AE',
        replace: true,
        templateUrl: $filter("globalsUrl")("/directives/mainMenu.html"),
        scope: {
            position: "@",
            contentArea: "@", 
            userProfile: "="
        },
        controller: ["$scope", "$route", "localize", Controller]

    };

    function Controller($scope, $route, localize: ILocalizeService) {

        $scope.viewState = {
            isUserVoiceVisible: false

        };

        $scope.toggleVisibility = function () {
            $scope.isMainMenuVisible = !$scope.isMainMenuVisible;
            if ($scope.position == 'leftSide' && $scope.contentArea != null) {
                var classInfo = $('#' + $scope.contentArea).hasClass('side-menu-visible');
                if ($scope.isMainMenuVisible) {
                    $('#' + $scope.contentArea).removeClass('side-menu-hidden');
                    $('#' + $scope.contentArea).addClass('side-menu-visible');
                }
                else {
                    $('#' + $scope.contentArea).removeClass('side-menu-visible');
                    $('#' + $scope.contentArea).addClass('side-menu-hidden');
                }
                classInfo = $('#' + $scope.contentArea).hasClass('side-menu-visible');
            }
        }
        $scope.routes = [
            { title: "home", route: "/home/index", roles: []  },
            {
                title: "καταθέσεις",
                routes: [   
                    { title: "οι λογαριασμοί μου σε ΕΥΡΩ", route: "/deposits/info", roles: [] },
                    { title: "οι λογαριασμοί μου σε ξένο νόμισμα", route: "/exchange/accounts", roles: [] },
                    { title: "πληροφορίες ΕΘΝΟdeposit", route: "/deposits/ethnodeposits", roles: [] },
                    { title: "πληροφορίες συναλλαγών Σ.Ε.Τ.", route: "/deposits/thirdpartyservice", roles: [] },                    
                    { title: "κινήσεις καρτών", route: "/deposits/cardsactivity", roles: [] }                    
                ], roles: [] 
            },
            {
                title: "κάρτες",
                routes: [
                    { title: "οι κάρτες μου", route: "/creditCards/myCards", roles: [] },
                    { title: "πληρωμή πιστωτικής κάρτας", route: "/creditCards/payCard", roles: [] },
                    { title: "έκδοση νέας virtual prepaid mastercard", route: "/creditCards/issueVirtualCard", roles: [] },
                    { title: "φόρτιση FBBank prepaid κάρτας", route: "/creditCards/loadFbbPrepaid", roles: [] },
                    { title: "έκδοση πιστωτικής κάρτας", route: "/applicationform/cards", roles: [] },
                    { title: "έκδοση χρεωστικής κάρτας", route: "/creditCards/issueDebitCard", roles: [] }
                ], roles: [] 
            },
            {
                title: "μεταφορές",
                routes: [
                    { title: "θέλω να μεταφέρω χρήματα", route: "/deposits/transfers", roles: [] },
                    { title: "μαζικές πιστώσεις λογαριασμών ΕΤΕ", route: "deposits/masscredit", roles: [] },                    
                    { title: "μαζικά εμβάσματα σε τράπεζες εσωτερικού", route: "deposits/masscredit", roles: [] },
                    { title: "μαζικά εμβάσματα σε τράπεζες εξωτερικού", route: "deposits/masscredit", roles: [] },
                    { title: "αρχεία Ι.Κ.Υ.", route: "/ssf", roles: ['ibadmin', 'ibsupport', 'ssfUser'] },
                    { title: "κατάσταση χρεούμενων λογαριασμών", route: "/deposits/debitaccounts", roles: [] },
                    { title: "μαζικές χρεώσεις", route: "/deposits/massdebit", roles: [] },
                    { title: "μισθοδοσίες σε λογαριασμούς ΕΤΕ", route: "/deposits/payroll", roles: [] }
                ], roles: [] 
            },
            {
                title: "πληρωμές",
                routes: [
                    { title: "θέλω να πληρώσω", route: "/payments/payment", roles: [] },
                    { title: "μαζικές πληρωμές υπέρ δημοσίου", route: "/payments/massTaxPayment", roles: [] }                    

                ], roles: [] 
            },
            {
                title: "επενδύσεις",
                routes: [
                    { title: "προθεσμιακές καταθέσεις", route: "/timeDeposits/accounts", roles: [] },
                    { title: "χρεόγραφα / μετοχές", route: "/stocks/myStocks/*investorCode", roles: [] },
                    { title: "αμοιβαία κεφάλαια", route: "/stocks/mutualFunds/*investorCode", roles: [] },
                    { title: "άνοιγμα προθεσμιακής κατάθεσης", route: "/timeDeposits/openTimeDeposit", roles: [] },
                    { title: "προεγγραφές", route: "/stocks/underwriting/*investorCode", roles: [] }
                ], roles: [] 
            },
            {
                title: "δάνεια",
                routes: [
                    { title: "τα δάνεια μου", route: "/loans/myLoans", roles: [] }
                ], roles: [] 
            },
            {
                title: "αιτήσεις",
                routes: [
                    { title: "έκδοση πιστωτικής κάρτας", route: "/applicationform/cards", roles: [] },
                    { title: "έκδοση χρεωστικής κάρτας", route: "/creditCards/issueDebitCard", roles: [] },
                    { title: "αίτηση αντικατάστασης i-Code", route: "/applicationform/ecode", roles: [] },
                    { title: "αίτηση κωδικού (UserID) Phone Banking", route: "/applicationform/phonebanking", roles: [] },
                    { title: "συμμετοχή στο μαραθώνιο", route: "/applicationform/segas", roles: ["nbgEmployee"] },
                ], roles: [] 
            },
            {
                title: "statements",
                routes: [
                    { title: "statement λογαριασμού", route: "/istatements/account/", roles: [ ] },
                    { title: "μισθοδοσία προσωπικού ΕΤΕ", route: "/istatements/payroll/", roles: ["nbgEmployee"] },
                    { title: "ετήσια βεβαίωση προσωπικού ΕΤΕ", route: "/istatements/yearcertify/", roles: ["nbgEmployee"] }
                    //, "nbgEmployee"
                ], roles: [] 
            },
            {
                title: "ημερολόγιο / προφίλ",
                routes: [
                    { title: "ημερολόγιο χρήστη", route: "/journal/web/*mode/*year/*month/*day", roles: []  },
                    { title: "διαχείριση χρηστών", route: "/journal/userMaintenance", roles: ["ibadmin", "ibsupport"] },
                    { title: "διαχείριση εταιρικών χρηστών", route: "/journal/companyUserMaintenance", roles: [] },
                    { title: "στατιστικά χρήσης", route: "/journal/statistics", roles: ["ibadmin", "ibsupport"] },
                    { title: "ημερολόγιο άλλων καναλιών", route: "/journal/otherChannels", roles: []  },
                    { title: "μεταχρονολογημένες συναλλαγές", route: "/deferred/deferredTransactions/active", roles: [] },
                    { title: "αλλαγή μυστικού κωδικού", route: "/utils/account", roles: [] },
                    { title: "απενεργοποίηση συσκευής i-code", route: "/utils/deactivateOTP", roles: []  },
                    { title: "κλείδωμα μυστικού κωδικού (password)", route: "/utils/blockPassword", roles: [] },
                    { title: "ημερολόγιο εγκρίσεων", route: "/deferred/journal/month/" + new Date().getFullYear() + "/" + (new Date().getMonth() + 1) + "/" + new Date().getDate(), roles: [] }, //roles: []
                    { title: "λίστα εγκρίσεων", route: "/deferred/simpleList/", roles: [] }, //roles: []
                    { title: "resources", route: "/resources", roles: ["ibadmin", "ibsupport"] },
                    { title: "ethnoFiles", route: "/ethnoFiles/upload", roles: [] }
                ], roles: [] 
            },
            {
                title: "B2B",
                routes: [
                    { title: "Αγοραστές - Διαχείριση κωδικών", route: "/b2b/buyerCodesAdmin", roles: [] },
                    { title: "Αγοραστές - Πληροφορίες", route: "/b2b/buyerInfo", roles: [] },
                    { title: "Αγοραστές - Ο λογαριασμός μου", route: "/b2b/buyerAccountInfo", roles: [] },
                    { title: "Αγοραστές - Αίτηση πιστοποιητικών", route: "/b2b/certificatesRequest", roles: [] },
                    { title: "Αγοραστές - Ακύρωση αίτησης πιστοποιητικών", route: "/b2b/certificatesRequestReversal", roles: [] },
                    { title: "Αγοραστές - Λήψη αρχείου αιτούμενων πιστοποιητικών", route: "/b2b/pendingCertificatesRequest", roles: [] },
                    { title: "Προμηθευτές - Καταχώρηση τιμολογίων", route: "/b2b/invoiceInsertion", roles: [] },
                    { title: "Τιμολόγια - Εισαγωγή από αρχείο", route: "/b2b/invoicesFile/FileUpload", roles: [] },
                    { title: "Τιμολόγια - Επισκόπηση αρχείου", route: "/b2b/invoicesFile/FileSearch", roles: [] }
                ], roles: []
            },
            {
                title: "ΕΘΝΟfiles",
                routes: [
                    { title: "αποστολή αρχείου", route: "/ethnoFiles/upload", roles: [] },
                    { title: "λήψη αρχείου", route: "/ethnoFiles/download", roles: [] },
                    { title: "ιστορικό κινήσεων", route: "/ethnoFiles/history", roles: [] }
                ], roles: []
            },
            {
                title: "alma",
                routes: [
                    { title: "συνολική εικόνα των εκκρεμοτήτων μου", route: "/almaweb/home", roles: [] },
                    { title: "οι υποθέσεις μου", route: "/almaweb/cases", roles: [] },
                    { title: "οι ειδοποιήσεις μου", route: "/almaweb/alerts", roles: [] },
                    { title: "ηλεκτρονική βιβλιοθήκη ενημερώσεων", route: "/almaweb/libraryposts", roles: [] },
                    { title: "διαθέσιμες αναφορές", route: "/almaweb/reports", roles: [] }
                ], roles: []
            }
        ];

        $scope.activeData = { activeNav: null, activeInner: null };

        $scope.goTo = function (url) {
            if (url == $route.current.prefixedRoute) {
                $route.reload();
            } else {
                $location.url(url);
            }
        };
        $scope.showUsersVoice = function () {
            $scope.viewState.isUserVoiceVisible = true; 
        }

        $scope.$on('$routeChangeSuccess', function () {
            $scope.activeData.activeNav = null;
            $scope.activeData.activeInner = null;

            _.each($scope.routes, function(item: any) {
                if (item.route == $route.current.prefixedRoute) {
                    $scope.activeData.activeNav = item; 
                    $scope.activeData.activeInner = null;
                }
                else {
                    if (item.routes != null) {
                        _.each(item.routes, function (inner: any) {
                            if (inner.route == $route.current.prefixedRoute) {
                                $scope.activeData.activeNav = item;
                                $scope.activeData.activeInner = inner;
                            }
                        })
                    }
                }
            }
                );
            //$scope.activeNav = routeIndex[$route.current.prefixedRoute];
        });

    }

});