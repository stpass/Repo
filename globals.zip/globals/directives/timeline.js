﻿service('Timeline', ['_', '$q', 'moment'], function (_, $q, moment) {
    'use strict';

    var DEFAULT_PAGE_SIZE = 10;

    var PagedItems = function (items, ps) {
        ps = ps || DEFAULT_PAGE_SIZE;

        this.init = function (pageSize) {
            this.pageSize = pageSize;
            this.start = 0;
            this.end = items.length > this.pageSize ? this.pageSize : items.length;
            this.page = items.slice(this.start, this.end);
        };

        this.hasPaging = function () {
            return items.length > DEFAULT_PAGE_SIZE;
        };

        this.expandable = function () {
            return this.hasPrev() || this.hasNext();
        };

        this.hasPrev = function () {
            return !!this.start;
        };

        this.hasNext = function () {
            return this.end !== items.length;
        };

        this.prev = function () {
            this.page.pop();
            this.end--;
            this.page.unshift(items[--this.start]);
        };

        this.prevPage = function () {
            var i = 0;
            while (i++ < this.pageSize && this.hasPrev()) {
                this.prev();
            }
        };

        this.next = function () {
            this.page.shift();
            this.start++;
            this.page.push(items[this.end++]);
        };

        this.nextPage = function () {
            var i = 0;
            while (i++ < this.pageSize && this.hasNext()) {
                this.next();
            }
        };

        this.showAll = function () {
            this.init(items.length);
        };

        this.togglePaging = function () {
            if (this.expandable()) {
                this.showAll();
            } else {
                this.init(ps);
            }
        };

        this.init(ps);
    };

    var Period = function (from, to, loadPeriod, exportPeriod, exportPdfPeriod, ps) {
        this.active = false;
        this.from = from;
        this.to = to;
        this.items = null;
        this.load = function () {
            if (this.items === null) {
                var defer = $q.defer();
                this.items = defer.promise;
                loadPeriod(this.from, this.to).then(function (items) {
                    defer.resolve(new PagedItems(items, ps));
                }, function (reason) {
                    defer.reject(reason);
                });
            }
        };
        this.export = function () {
            if (exportPeriod) {
                exportPeriod(this.from, this.to);
            }
        };
        this.exportPdf = function () {
            if (exportPdfPeriod) {
                exportPdfPeriod(this.from, this.to);
            }
        };
        this.clear = function () {
            this.items = null;
        };
    };

    var Timeline = function ($scope, maxMonthsBack, loadPeriod, exportPeriod, exportPdfPeriod, ps) {
        this.$scope = $scope;
        this.periods = [];
        this.hasActivePeriods = false;

        var monthBack = 1;
        var firstPeriodFromMoment = moment().startOf('month');
        if (moment().diff(firstPeriodFromMoment, 'days') < 10) {
            firstPeriodFromMoment = moment().subtract(1, 'month').startOf('month');
            monthBack++;
        }
        this.addPeriod(new Period(
            firstPeriodFromMoment.toDate(),
            moment().toDate(),
            loadPeriod,
            exportPeriod,
            exportPdfPeriod,
            ps
        ));
        while (monthBack <= maxMonthsBack) {
            this.addPeriod(new Period(
                moment().subtract(monthBack, 'month').startOf('month').toDate(),
                moment().subtract(monthBack, 'month').endOf('month').toDate(),
                loadPeriod,
                exportPeriod,
                exportPdfPeriod,
                ps
            ));
            monthBack++;
        }

        var self = this;
        this.$scope.$watch(
			function () {
			    return _.some(self.periods, function(period) {
			        return period.active === true;
			    });
			},
			function (value) {
			    self.hasActivePeriods = value;
			}
		);
    };

    Timeline.prototype.ensureFirstPeriod = function () {
        this.firstPeriod();
        this.periods[0].load();
    };

    Timeline.prototype.firstPeriod = function () {
        _.each(this.periods, function (p) { p.active = false; });
        this.periods[0].active = true;
    };

    Timeline.prototype.clearFirst = function () {
        this.periods[0].clear();
        this.periods[0].active = false;
    };

    Timeline.prototype.addPeriod = function (period) {
        var lastPeriod = this.periods[this.periods.length - 1];
        if (lastPeriod) {
            lastPeriod.next = period;
        }
        this.periods.push(period);
        var self = this;
        this.$scope.$watch(function () { return period.active; }, function (active) {
            if (active) {
                var periodToActivate = period;
                if (self.isBeforeActive(period)) {
                    periodToActivate = period.next;
                    periodToActivate.active = true;
                }
                _.each(self.periods, function (p) {
                    if (p !== periodToActivate) {
                        p.active = false;
                    }
                });
                periodToActivate.load();
            }
        });
    };

    Timeline.prototype.isBeforeActive = function (period) {
        var newActiveIndex, oldActiveIndex = -1;
        _.each(this.periods, function (p, i) {
            if (p == period) {
                newActiveIndex = i;
            }
            if (p !== period && p.active) {
                oldActiveIndex = i;
            }
        });
        return newActiveIndex < oldActiveIndex;
    };

    Timeline.Period = Period;

    return Timeline;
});


directive(
    'timeline',
    ['angular', '$filter', '$compile', '$http', '$templateCache', 'Timeline'],
    function (angular, $filter, $compile, $http, $templateCache, Timeline) {
        'use strict';

        return {
            restrict: 'A',
            scope: {
                timeline: '=',
                maxMonthsBack: '=', 
                loadPeriod: '=',
                exportPeriod: '=',
                exportPdfPeriod: '=',
                timestampExpression: '@',
                itemHeight: '@',
				helpText: '@',
				helpTextClass: '@'
            },
            compile: function (tElement, tAttrs) {
                var iterationTemplate = tElement.html();
                tElement.html('');
                return function (scope, iElement, iAttrs) {
                    scope.iterationTemplate = iterationTemplate;
                    if (iAttrs.context) {
                        var context = scope.$parent.$eval(iAttrs.context);
                        angular.extend(scope, context);
                    }
                    scope.timeline = new Timeline(scope, scope.maxMonthsBack, scope.loadPeriod, scope.exportPeriod, scope.exportPdfPeriod);
                    var view = $filter("globalsUrl")('/directives/timeline.html');
                    $http.get(view, { cache: $templateCache }).success(function (response) {
                        iElement.html(response);
                        $compile(iElement.contents())(scope);
                    }).error(function () {
                        iElement.html('');
                    });
                };
            }
        };
    }
);

directive('timelineTranscludeTimestamp', [], function () {
    return {
        terminal: true,
        restrict: 'A',
        link: function (scope, element) {
            var html = scope.$eval(scope.timestampExpression);
            element.html(html);
        }
    };
});

directive('timelineTranscludeItemTemplate', ['$compile'], function ($compile) {
    return {
        terminal: true,
        restrict: 'A',
        link: function (scope, element) {
            element.html(scope.iterationTemplate);
            $compile(element.contents())(scope);
        }
    };
});

directive('timelinePaging', ['$filter'], function ($filter) {
    return {
        terminal: true,
        templateUrl: $filter("globalsUrl")("/directives/timelinePaging.html"),
        restrict: 'A',
        scope: {
            period: '=',
            positioned: '@'
        }
    };
});

animation("timelineListItem-enter", ['angular', 'jQuery'], function (angular, $) {
    return {
        setup: function (element) {
            element.hide();
        },
        start: function (element, done, memo) {
            var height = Number(element.scope().itemHeight);
            element.show().animate({ height: height + 10 }, {
                duration: 200,
                complete: function () {
                    var detailsWrapper = $('.timelineListItemDetailsWrapper', element);
                    // The following is done using css
                    //$('.timelineListItemDetails', detailsWrapper).css({ top: (height / 2) - 13 });
                    detailsWrapper.css({ height: height }).fadeIn({ duration: 200, complete: done });
                }
            });
        }
    };
});

animation("timelineListItem-leave", function () {
    return {
        start: function (element, done, memo) {
            element.animate({ height: 0 }, {
                duration: 200,
                complete: function () {
                    element.hide();
                    done();
                }
            });
        }
    };
});

animation("noItems-enter", ['jQuery'], function ($) {
    return {
        setup: function (element) {
            element.hide();
        },
        start: function (element, done, memo) {
            element.slideDown(function () {
                done();
            });
        }
    };
});

animation("noItems-leave", function () {
    return {
        start: function (element, done, memo) {
            element.slideUp(function () {
                done();
            });
        }
    };
});