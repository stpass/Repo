﻿directive('zippy', ['$', '$filter'], function ($, $filter) {
    return {
        restrict: 'A',
        replace: false,
        transclude: true,
        scope: {
            title: '@zippyTitle',
            largeTitle: '@zippyLargeTitle',
            opened: '=zippyOpened',
            icon: '@zippyIconName',
            iconAction: '&zippyIconAction'
        },
        templateUrl: $filter("globalsUrl")("/directives/zippy.html"),
        link: function (scope, element, attrs) {

            var buttonImage = $('.title > .expand-collapse', element);
            var body = $('.body', element);

            $('.title', element).on('click', function () {
                scope.opened = !scope.opened;
                scope.$apply();
            });

            $('.nbgIcon', element).on('click', function (event) {
                event.stopPropagation();
                scope.iconAction();
                scope.$apply();
            });

            scope.$watch('opened', function (opened) {
                applyStyles(opened);
            })

            function applyStyles(show) {
                buttonImage.removeClass(show ? 'arrow-down' : 'arrow-up');
                buttonImage.addClass(show ? 'arrow-up' : 'arrow-down');
                if (show) {
                    body.slideDown();
                } else {
                    body.slideUp();
                }
            }

            // initialize the zippy
            applyStyles(scope.opened);
        }
    };
});