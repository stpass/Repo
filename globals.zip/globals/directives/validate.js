﻿directive("validate", ["validationCommon", "$timeout", "$parse", "jQuery"], function(vc, $timeout, $parse, $) {
	"use strict";


	function extractGroups(validateAttr) {
		if( validateAttr === "" ) return vc.DEFAULT_GROUPS;
		var groups = validateAttr.split(","), i, result = [];
		for( i=0; i < groups.length; i++ ) {
			if( $.trim(groups[i]) !== "" ) result.push(groups[i]);
		}
		return result;
	}

	function ValidateController(scope, element, attrs) {
		this.scope = scope;
		this.element = element;
		this.validationExpressions = vc.extractValidationExpressions(attrs.ngModel);
		this.groups = extractGroups(attrs.validate);
	}

	ValidateController.prototype = {
		fieldFormat: null,
		validationExpressions: null,
		scope: null,
		element: null,
		ngModel: null,
		queuedMessages: null,
		messageDisplayTimeout: null,
		requiredFromModel: false,
		groups: null,

		setFieldFormat: function(f) {
			if( this.fieldFormat !== null ) throw new Error("trying to set multiple field format for " + this.element);
			if( typeof(f.formatter) !== "function" ) throw new Error("missing formatter function for " + this.element);
			if( typeof(f.parser) !== "function" ) throw new Error("missing parser function for " + this.element);
			if( typeof(f.name) !== "string" ) throw new Error("fieldFormat should be named for " + this.element);
			this.fieldFormat = f;
		},

		validatorFn: function(value) {
			var x, r, validationResult, validationContext = vc.produceValidationResult(this.scope, this.validationExpressions, value, this.groups);
			if( validationContext !== null ) {
				validationResult = validationContext.results || {};
				for( x in validationResult ) {
					if( !validationResult.hasOwnProperty(x) ) continue;
					r = validationResult[x];
					this.ngModel.$setValidity(x, r.flag);
					if( x !== "required" ) this.handleMessage(x, r.message, r.flag);
				}
			}
			return value;
		},

		formatterFn: function(value, formatErrorCb) {
			if( this.fieldFormat !== null ) {
				value = this.fieldFormat.formatter(value, formatErrorCb);
			}
			return value;
		},

		parserFn: function(value, formatErrorCb) {
			if( this.fieldFormat !== null ) {
				value = this.fieldFormat.parser(value, formatErrorCb, this.element);
			}
			return value;
		},

		attachToNgModel: function(ngModel) {
			if( this.ngModel !== null ) throw new Error("attachToNgModel called again");
			var
				self = this,
				formatErrorCb = function(valid, message) {
					self.ngModel.$setValidity(self.fieldFormat.name, valid);
					self.handleMessage(self.fieldFormat.name, message, valid);
				},
				formatter = function(value) {
					value = self.validatorFn(value);
					value = self.formatterFn(value, formatErrorCb);
					vc.adjustStyles(self.element, self.ngModel, true);
					return value;
				},
				parser = function(value) {
					value = self.parserFn(value, formatErrorCb);
					value = self.validatorFn(value);
					vc.adjustStyles(self.element, self.ngModel, true);
					return value;
				},
				requiredCondition,
				getCtxObject;

			this.ngModel = ngModel;
			ngModel.$formatters.push(formatter);
			ngModel.$parsers.unshift(parser);

			requiredCondition = vc.extractCondition(this.scope, this.validationExpressions, "required");
			if( typeof(requiredCondition) === "function" ) {
				getCtxObject = $parse(this.validationExpressions.ctx);
				this.scope.$watch(
					function(scope) {
						var ctxObject = getCtxObject(scope),
							ret = !!requiredCondition.call(ctxObject);
						return ret;
					},
					function(newval, oldval, scope) {
						var value = ngModel.$modelValue, valid = true;
						if( newval ) {
							if( value == null ) valid = false;
							else if( typeof(value) === "string" && $.trim(value) === "" ) valid = false;
						}
						ngModel.$setValidity("required", valid);
						self.setRequired(newval);
					}
				);
			}
			else if( typeof(requiredCondition) === "boolean" ) {
				this.setRequired(requiredCondition);
			}
			this.requiredFromModel = (requiredCondition != null);

			// force the validation to take place on every digest so that
			// changes to the model are reflected immediately to the UI
			this.scope.$watch(
				function() {
					var isValid = true, x, validationResult,
						validationContext = vc.produceValidationResult(self.scope, self.validationExpressions, self.ngModel.$modelValue, self.groups);
					if( validationContext !== null ) {
						validationResult = validationContext.results || {};
						for( x in validationResult ) {
							if( !validationResult.hasOwnProperty(x) ) continue;
							if( validationResult[x].flag === false ) {
								isValid = false;
								break;
							}
						}
					}
					return isValid;
				},
				function(newval) {
					self.validatorFn(self.ngModel.$modelValue);
					vc.adjustStyles(self.element, self.ngModel, false);
				}
			);
		},

		handleMessage: function(key, message, valid) {
			if( valid ) {
				this.removeQueuedMessage(key);
				vc.standardHandleMessage(this.element, key, message, valid);
			}
			else {
				this.addQueuedMessage(key, message);
			}
		},

		removeQueuedMessage: function(key) {
			if( this.queuedMessages !== null ) {
				for( var i=0; i < this.queuedMessages.length; i++ ) {
					if( this.queuedMessages[i].key === key ) {
						this.queuedMessages.splice(i,1);
						break;
					}
				}
				if( this.queuedMessages.length === 0 && this.messageDisplayTimeout !== null ) {
					$timeout.cancel(this.messageDisplayTimeout);
				}
			}
		},

		addQueuedMessage: function(key, message) {
			var i, self = this, found = false;
			if( this.queuedMessages === null ) this.queuedMessages = [];
			for( i=0; i < this.queuedMessages.length; i++ ) {
				if( this.queuedMessages[i].key === key ) {
					this.queuedMessages[i].message = message;
					found = true;
					break;
				}
			}
			if( !found ) this.queuedMessages.push({ key: key, message: message });
			if( this.messageDisplayTimeout !== null ) $timeout.cancel(this.messageDisplayTimeout);
			this.messageDisplayTimeout = $timeout(function() {
				self.flushQueuedMessages();
			}, 600, false);
		},

		flushQueuedMessages: function() {
			$timeout.cancel(this.messageDisplayTimeout);
			this.messageDisplayTimeout = null;
			if( this.queuedMessages === null || this.queuedMessages.length === 0 ) return;
			var i, qm;
			for( i=0; i < this.queuedMessages.length; i++ ) {
				qm = this.queuedMessages[i];
				vc.standardHandleMessage(this.element, qm.key, qm.message, false);
			}
			vc.adjustStyles(this.element, this.ngModel, false);
		},

		setRequired: function(required) {
			this.element.parents(".form-group:eq(0)").toggleClass("required", required === true);
		}
	};


	return {
		restrict: "A",
		require: ["ngModel","validate"],
		controller: ["$scope", "$element", "$attrs", ValidateController],
		link: function(scope, element, attrs, controllers) {
			var ngModel = controllers[0], validateCtrl = controllers[1];
			validateCtrl.attachToNgModel(ngModel);
			element.on("change", function() {
				validateCtrl.flushQueuedMessages();
			});
			if( !validateCtrl.requiredFromModel ) {
				attrs.$observe("required", function(newval) {
					validateCtrl.setRequired(newval);
				});
			}
		}
	};
});
