interface IUsersContestData {
    accept: string;
}
interface IContestConfirmationScope extends ng.IScope {
    terms: IUsersContestData;
    isVisible: boolean;
    isUserVisible: boolean;
    continue: () => void;
    cancel: () => void;
}
window.directive("contestConfirmation", ["_", "angular", "$filter", "$modal", "customApplDao"],
    function (_, angular, $filter: ng.IFilterService, $modal: any,
        customApplDao: ibank.customAppl.ICustomApplDao) {
        return {
            restrict: "AE",

            scope: {
                isVisible: "="
            },
            controller: ["$scope", Controller]
        };
        function Controller($outerScope: IContestConfirmationScope) {

            var applName, subapplName, fromDate, toDate: string;
            applName = "MARKET02";
            subapplName = "CONT01";
            fromDate = "2014-10-01";
            toDate = "2014-12-31";

            $outerScope.$watch("isVisible", function (newValue: boolean) {
                if (newValue) {
                    chkVisibility();
                }
            });

            function chkVisibility() {
                var modalInstance = $modal.open({
                    templateUrl: $filter("globalsUrl")("/directives/contest/contestConfirmation.html"),
                    size: "lg",
                    controller: ["$scope", "$modalInstance", modalInstanceCtrl]
                });
            }

            function modalInstanceCtrl($privatescope: IContestConfirmationScope, $modalInstance) {
                $privatescope.terms = { accept: "1" };
                $privatescope.cancel = function () {
                    $outerScope.isVisible = false;
                    $modalInstance.dismiss('cancel');
                };
                $privatescope.continue = function () {
                    if ($privatescope.terms.accept == "1") {
                        var insert = customApplDao.insert({ appl: applName, subappl: 'ACCEPT', applData: { accept: $privatescope.terms.accept } });
                        insert.$then(function () {
                            $outerScope.isVisible = false;
                            $modalInstance.dismiss('cancel');
                        });
                    }
                    else if ($privatescope.terms.accept == "3") {
                        var insert = customApplDao.insert({ appl: applName, subappl: 'REFUSE', applData: { accept: $privatescope.terms.accept } });
                        insert.$then(function () {
                            $outerScope.isVisible = false;
                            $modalInstance.dismiss('cancel');
                        });
                    }
                    else {
                        $outerScope.isVisible = false;
                        $modalInstance.dismiss('cancel');
                    }
                };
            }
        }
    });   