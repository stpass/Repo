﻿
interface IContestWidgetScope extends ng.IScope {
    showForm: boolean;
    isAlreadyRegistered: boolean;
    cancelRegistration: () => void;
}

window.directive("contestWidget", ["_", "angular", "$filter", "customApplDao"],
    function (_, angular, $filter: ng.IFilterService, customApplDao: ibank.customAppl.ICustomApplDao) {
        return {
            restrict: "AE",

            scope: {
            },
            templateUrl: $filter("globalsUrl")("/directives/contest/contestWidget.html"),

            controller: ["$scope", Controller]
        };
        function Controller($scope: IContestWidgetScope) {
            $scope.showForm = false; 
            $scope.isAlreadyRegistered = false; 

            var applName, subapplName, fromDate, toDate: string;
            applName = "MARKET02";
            subapplName = "CONT01";
            fromDate = "2014-10-01";
            toDate = "2014-12-31";

            function chksRegistration() {
                customApplDao.selectCount({ appl: applName }).$then(function (response: ibank.customAppl.ICustomApplCountResponse) {
                    $scope.isAlreadyRegistered = response.totals !== 0 && response.subAppl[0].name == 'ACCEPT';
                });
            }

            $scope.cancelRegistration = function () {
                var inserted = customApplDao.insert({ appl: applName, subappl: 'REFUSE', applData: { accept: 2 } });
            }

            $scope.$watch(function () {
                return customApplDao.changeCounter;
            }, function (newValue) {
                chksRegistration();
                });
            //chksRegistration();
        }
    });  