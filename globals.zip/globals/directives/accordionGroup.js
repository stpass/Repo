﻿// Extend the accordionGroup directive in ui-bootstap-tpls-0.2.0 js to 
// add a class when group is open
directive("accordionGroup", [], function () {
    return {
        restrict: 'EA',
        priority: -100, // Be the last to run
        link: function (scope, element, attrs, accordionCtrl) {
            scope.$watch('isOpen', function (value) {
                if (value) {
                    element.addClass("opened");
                } else {
                    element.removeClass("opened");
                }
            });
        }
    };
});