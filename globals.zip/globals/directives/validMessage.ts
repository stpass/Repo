window.directive('validMessage', [], function () {
        return {
        require: 'ngModel',
        link: function (scope: ng.IScope, elm, attrs, ctrl: ng.INgModelController) {
            if (attrs != null) {
                attrs.$observe("validMessage", function (message?: any) {
                    if (message != null) {
                        var newElm = $('<div class="small green-text">' + message + '</div>');
                        elm.after(newElm);
                        scope.$watch(function () { return ctrl.$valid && (ctrl.$viewValue != null) && (ctrl.$viewValue != ""); }, function (value) {
                            if (value) {
                                newElm.show();
                            }
                            else {
                                newElm.hide();
                            }
                        });
                    }
                });
            }
        }
    }
});
  