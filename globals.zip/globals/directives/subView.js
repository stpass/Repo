﻿(function () {
    var html = '<div ng-controller="{ctx}.controllerFactory" ng-include src="{ctx}.templateUrl"></div>';

    directive('subView', ['$compile', 'angular'], function ($compile, angular) {
        'use strict';

        return {
            restrict: 'A',
            replace: true,
            link: function (scope, elm, attrs) {
                var replaced = html.replace(/{ctx}/g, attrs.definition);
                var template = angular.element(replaced);
                elm.html(template);
                $compile(elm.contents())(scope);
            }
        };
    });
})();