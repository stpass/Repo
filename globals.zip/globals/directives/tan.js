﻿directive("tan", ["jQuery", "$filter", "validationCommon", "$window", "localize"], function ($, $filter, vc, $window, localize) {
	"use strict";

	return {
		restrict: "A",
		replace:true,		
		templateUrl: $filter("globalsUrl")("/directives/tan.html"),

		scope: {
			tanNumber: "=tan",
			isFocused:"@",
			message: "=",
            icodeMessage:"="
		},

		controller: ["$scope", "$element", "$attrs", Ctrl]
	};

	function Ctrl($scope, element, attrs) {
		//  XXX In order for a field to be validated with our validate directive, the
		//  XXX ng-model must be in the form xxx.yyy or xxx[yyy]. Therefore we cannot
		//  XXX simply pass ng-model="tanNumber" to the input, so we split the
		//  XXX expression given to us into ctx+prop and use ng-model="ctx[prop]".
		var valexpr = vc.extractValidationExpressions(attrs.tan);

		$scope.processedMessage = $scope.message;
		$scope.processedMessageicode = $scope.icodeMessage;
		if ($scope.processedMessageicode === null || typeof ($scope.processedMessageicode) === "undefined") {
		    $scope.processedMessageicode = localize('icode_icode');
		}
		if( $scope.processedMessage === null || typeof($scope.processedMessage) === "undefined" ) $scope.processedMessage = localize("icode_confirmation");

		$scope.ctx = $scope.$parent.$eval(valexpr.ctx);
		$scope.prop = valexpr.prop.substring(1, valexpr.prop.length - 1);
		if ($scope.isFocused) {
		    var inpt = element.find("input");
		    if (inpt) {
		        $window.setTimeout(function () {
		            inpt.focus();
		        }, 5);		        
		    }		    
		}
	}
});
