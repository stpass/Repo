﻿directive("toUpper", ["jQuery", "$filter", "validationCommon", "$window"], function ($, $filter, vc, $window) {
	"use strict";
	
	function setFieldFormat(validateCtrl, ngModel, element) {
		validateCtrl.setFieldFormat({
			name: "toUpper",
			formatter: function(value, formatErrorCb) {
				return value;
			},
			parser: function(value, formatErrorCb, element) {
				if( typeof(value) === "string" ) value = value.toUpperCase();
				if( value !== ngModel.$viewValue ) {
					element.val(value);
				}
				return value;
			}
		});
	}

	return {
		restrict: "A",
		require: ["validate", "ngModel"],
		link: function(scope, elem, attrs, controllers) {
			var validateCtrl = controllers[0], ngModel = controllers[1];
			setFieldFormat(validateCtrl, ngModel, elem);
		}
	};
});
