﻿(function (angular, undefined) {
    directive(
        'template',
        ['$http', '$templateCache', '$anchorScroll', '$compile', '$timeout'],
        function ($http, $templateCache, $anchorScroll, $compile, $timeout) {
            'use strict';

            return {
                restrict: 'ECA',
                terminal: true,
                priority: -500,
                compile: function (element, attr) {
                    var srcExp = attr.template || attr.src,
                        onDataExp = attr.data || null,
                        watchObjectEquality = (attr.watchObjectEquality ? attr.watchObjectEquality === 'true' : false),
                        autoScrollExp = attr.autoscroll;

                    return function (scope, element) {
                        var changeCounter = 0,
                            childScope;

                        var clearContent = function () {
                            if (childScope) {
                                childScope.$destroy();
                                childScope = null;
                            }

                            element.html('');
                        };

                        if (onDataExp != null) {
                            scope.$watch(onDataExp, function (data) {
                                if (childScope) {
                                    angular.extend(childScope, data);
                                }
                            }, watchObjectEquality);
                        }

                        scope.$watch(srcExp, function (src) {
                            var thisChangeId = ++changeCounter;

                            if (src) {
                                $http.get(src, { cache: $templateCache }).success(function (response) {
                                    if (thisChangeId !== changeCounter) return;

                                    element.html(response);

                                    if (childScope) childScope.$destroy();

                                    if (onDataExp != null) {
                                        childScope = scope.$new(true);
                                        var data = scope.$eval(onDataExp);
                                        angular.extend(childScope, data);
                                    } else {
                                        childScope = scope.$new();
                                    }
                                    
                                    $compile(element.contents())(childScope);

                                    if (autoScrollExp != undefined && (!autoScrollExp || scope.$eval(autoScrollExp))) {
                                        $anchorScroll();
                                    }
                                }).error(function () {
                                    if (thisChangeId === changeCounter) clearContent();
                                });
                            } else clearContent();
                        });
                    };
                }
            };
        }
    );
})(angular);