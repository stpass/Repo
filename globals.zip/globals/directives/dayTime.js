﻿directive("dayTime", ["$filter"], function($filter) {
	return {
		restrict: "C",
		template:
			"<span class='date-name'></span><span> </span><span class='date-time'></span>",
		//"<span class='date-no'></span><span class='date-name'></span><span class='date-time'></span>",
		link: function(scope, elem, attrs) {
			var setTime;
			setTime = makeTimeSetter(elem);
			setTime(new Date());
			startTimer(setTime);
		}
	};

	function makeTimeSetter(elem) {
		var dateNo, dateName, dateTime;
		dateNo = elem.find(".date-no");
		dateName = elem.find(".date-name");
		dateTime = elem.find(".date-time");
		return function(date) {
			//dateNo.html($filter("date")(date, "d"));
		    //dateName.html($filter("date")(date, "EEEE<br/>MMMM<br/>yyyy"));
			dateName.html($filter("date")(date, "EEEE, d MMMM yyyy"));
			dateTime.html($filter("date")(date, "HH:mm"));
		};
	}
	
	function startTimer(setTime) {
		function timer() {
			setTime(new Date());
		}

		setTimeout(
			function() {
				timer();
				setInterval(timer, 60000);
			}, (60 - (new Date()).getSeconds())*1000
		);
	}
});
