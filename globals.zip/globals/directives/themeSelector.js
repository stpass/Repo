window.directive('themeSelector', ["$filter", "$location", "localize"], function ($filter, $location, localize) {
    'use strict';

    return {
        restrict: 'AE',
        replace: true,
        templateUrl: $filter("globalsUrl")("/directives/themeSelector.html"),
        controller: ["$scope", "$route", "localize", Controller]
    };

    function Controller($scope, $route, localize) {
        function setCookie(cvalue) {
            var d = new Date();
            d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toGMTString();
            document.cookie = "ibankTheme=" + cvalue + "; " + expires + "; path=/";
        }
        function setWeightCookie(cvalue) {
            var d = new Date();
            d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toGMTString();
            document.cookie = "ibankFont=" + cvalue + "; " + expires + "; path=/";
        }
        $scope.selectTheme = function (themeValue) {
            setCookie(themeValue);
            $("body.ibank").removeClass("normal");
            $("body.ibank").removeClass("white");
            $("body.ibank").addClass(themeValue);
        };

        $scope.selectFontWeight = function (weightValue) {
            setWeightCookie(weightValue);
            $("body.ibank").removeClass("heavy");
            $("body.ibank").removeClass("heavier");
            $("body.ibank").addClass(weightValue);
        };
    }
});
//# sourceMappingURL=themeSelector.js.map
