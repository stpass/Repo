interface IUsersVoiceScope extends ng.IScope {
    visible: boolean;
    executing: boolean;
    messageSent: boolean;
    externalVisible: boolean;
    userComment: ibank.usersVoice.IAuditIssue;
    show: () => void;
    hide: ($event) => void;
    clear: () => void;
    isSubmitDisabled: () => boolean;
    submit: () => void;
    faqs: any[];
    expandAll: () => void;
    collapseAll: () => void;
    goTo: (url) => void;
}
window.directive("usersVoice", ["_", "angular", "$filter", "$rootScope", "faqs", "$location", "usersVoiceDao"],
    function (_, angular, $filter: ng.IFilterService, $rootScope: ng.IRootScopeService, faqs, $location, usersVoiceDao: ibank.usersVoice.IUsersVoiceDao) {
        return {
            restrict: "AE",
            templateUrl: $filter("globalsUrl")("/directives/usersVoice.html"),
            scope: {
                visible: "="
            },
            controller: ["$scope", Controller]
        };
        function Controller($scope: IUsersVoiceScope) {

            $scope.messageSent = false;
            $scope.executing = false;

            $scope.faqs = _.map(faqs, function (faq) {
                return _.extend({ opened: false }, faq);
            });

            $scope.goTo = function (url) {
                $location.url(url);
                $scope.hide(null);
            };

            $scope.expandAll = function () {
                _.each($scope.faqs, function (faq) {
                    faq.opened = true;
                });
            };

            $scope.collapseAll = function () {
                _.each($scope.faqs, function (faq) {
                    faq.opened = false;
                });
            };

            $scope.show = function () {
                $scope.visible = true;
            };

            $scope.hide = function ($event) {
                if ($event && !angular.element($event.target).attr('data-dimmer')) return;

                $scope.visible = false;
                $scope.messageSent = false;
            };

            $scope.isSubmitDisabled = function () {
                return !$scope.userComment.title || $scope.executing === true;
            }

            $scope.submit = function () {
                var result = usersVoiceDao.auditIssue($scope.userComment);
                $scope.executing = true;
                result.$then(function (resp) {
                    $scope.clear();
                    $scope.executing = false;
                    $scope.messageSent = true;
                }, function (info) {
                    $scope.executing = false;
                });
            };

            $scope.clear = function () {
                $scope.userComment = { title: null, details: null, email: null };
            };

            $scope.clear();
        }
    });  