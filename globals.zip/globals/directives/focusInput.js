﻿directive("focusInput", ["jQuery", "$timeout"], function ($, $timeout) {
    "use strict";
    return {
        link: function (scope, element, attrs) {
            scope.$watch(attrs["focusInput"], function (value) {
                if (value !== null) {
                    $timeout(function () {
                        element[0].focus();
                    }, 5);
                }
            });
        }
    }
});

