window.directive('themeSelector', ["$filter", "$location", "localize"], function ($filter:ng.IFilterService, $location:ng.ILocationService, localize:ILocalizeService) {
    'use strict';

    return {
        restrict: 'AE',
        replace: true,
        templateUrl: $filter("globalsUrl")("/directives/themeSelector.html"),
        controller: ["$scope", "$route", "localize", Controller]

    };

    function Controller($scope, $route, localize: ILocalizeService ) {

        function setCookie(cvalue) {
            var d:any = new Date();
            d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toGMTString();
            document.cookie = "ibankTheme=" + cvalue + "; " + expires + "; path=/";
        }
        function setWeightCookie(cvalue) {
            var d: any = new Date();
            d.setTime(d.getTime() + (365 * 24 * 60 * 60 * 1000));
            var expires = "expires=" + d.toGMTString();
            document.cookie = "ibankFont=" + cvalue + "; " + expires + "; path=/";
        }
        $scope.selectTheme = function (themeValue: string) {
            setCookie(themeValue);
            $("body.ibank").removeClass("normal");
            $("body.ibank").removeClass("white");
            $("body.ibank").addClass(themeValue);
        };

        $scope.selectFontWeight = function (weightValue: string) {
            setWeightCookie(weightValue);
            $("body.ibank").removeClass("heavy");
            $("body.ibank").removeClass("heavier");
            $("body.ibank").addClass(weightValue);
        };
    }

}); 