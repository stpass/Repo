﻿//<span class="col-xs-6">Αυτόματη αποσύνδεση σε </span><span class="col-xs-6"><span class="progress"><span class="bar" style="width: 60%"></span></span></span>
directive("sessionTimer", ['$rootScope', 'messageSvc', 'localize'], function ($rootScope, messageSvc, localize) {
    return {
        restrict: "A",
        scope: true,
        controller: ["$scope", "$element", "$window", function ($scope, $element, $window) {
            
            $scope.remainingSessionData = [{
                data: 0, color: '#FFFFFF'
            }, {
                data: 0, color: '#ff9900'
            }, {
                data: 100, color: '#ffc40d'
            }];
            $scope.remainingSessionDataFactory = function (source) {
                return {
                    data: source,
                    options: {
                        series: { pie: { show: true, stroke: { width: 0, color: "#ffc40d" } } },
                        grid: { hoverable: false }
                    }
                };
            };
            var currentWidth = 100;
            var sessionTTL = window.imb.sessionLifespan;
            var intervalHandle = $window.setInterval(function () {
                window.imb.tokenTTL--;
                sessionTTL--;
                if (window.imb.tokenTTL < sessionTTL)
                    sessionTTL = window.imb.tokenTTL;
                if (sessionTTL < 0) {
                    $window.clearInterval(intervalHandle);
                    $(".timeout", $element).html("00:00");
                    $scope.remainingSessionData[0].data = 100;
                    $scope.remainingSessionData[1].data = 0;
                    $scope.remainingSessionData[2].data = 0;
                    $scope.$digest();
                    messageSvc.addWarn(localize("session_timeout"), { isPersistent: true });
                    $window.imb.logoff();
                    setTimeout(function () { location.reload(); }, 3000);
                } else {
                    var secsLeft = sessionTTL % 60;
                    var minsLeft = (sessionTTL - secsLeft) / 60;
                    var remainingTime = (minsLeft < 10 ? '0' + minsLeft : minsLeft) + ':' + (secsLeft < 10 ? '0' + secsLeft : secsLeft);
                    $(".timeout", $element).html(remainingTime);
                    var newWidth = sessionTTL * 100 / window.imb.tokenLifespan;
                    var remainWidth = 100 * (window.imb.tokenTTL - sessionTTL) / window.imb.tokenLifespan;
                    if (Math.abs(currentWidth - newWidth) > 1) { // If there is at least 1 point of difference
                        currentWidth = newWidth;
                        $scope.remainingSessionData[0].data = 100 - (currentWidth + remainWidth);
                        $scope.remainingSessionData[1].data = currentWidth;
                        $scope.remainingSessionData[2].data = remainWidth;
                        $scope.$digest();
                    }
                }
            }, 1000);
            $rootScope.$on("sessionReset", function () {
                sessionTTL = window.imb.sessionLifespan;
            });
        }],
        link: function () { }
    };
});