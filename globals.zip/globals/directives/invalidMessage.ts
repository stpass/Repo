window.directive('invalidMessage', [], function () {
        return {
            require: ['ngModel', 'invalidMessage'],
            controller: ["$scope", function ($scope) {
                var messageHandler = this; 
                messageHandler.setMessage = function (message: string) {
                    messageHandler.message = message; 
                };

            }],
        link: function (scope: ng.IScope, elm, attrs, ctrls: any[]) {
            var newElm = $('<div class="small red-text"></div>');
            elm.after(newElm);
            var ctrl: ng.INgModelController = ctrls[0];
            var messageHandler = ctrls[1];
            scope.$watch(function () { return ctrl.$invalid && (ctrl.$viewValue != null) && (ctrl.$viewValue != ""); }, function (value) {
                if (value) {
                    newElm.html(messageHandler.message);
                    newElm.show();
                }
                else {
                    newElm.hide();
                }
            });
            scope.$watch(function () {
                return messageHandler.message;
            }, function (newValue: string) {
                newElm.html(newValue);
            });
            if (attrs != null) {
                attrs.$observe("invalidMessage", function (message?: any) {
                    if (message != null) {
                        newElm.html(message);
                    }
                });
            }
        }
    }
});
 