interface IInputValue {
    inputValue: string; 
}
interface IInputWithSaveScope extends ng.IScope {
    inputValue: string;
    inputValuePristine: string;
    inputSaveSuccess: boolean;
    isStoreEnabled: () => boolean;
    storeEnabled: boolean;
    onStoreInput: () => IResourceLite<any>;
    storeInput: () => void;
    reset: () => void;
    internalChange: () => void;
}
window.directive("inputWithSave", ["$filter", "$timeout"],
    function ($filter: ng.IFilterService, $timeout: ng.ITimeoutService) {
        "use strict";

        return {
            restrict: "AE",
            templateUrl: $filter("globalsUrl")('/directives/inputWithSave.html'),
            scope: {
                isStoreEnabled: "&",
                onStoreInput: "&",
                inputValue: "="
            },
            controller: ["$scope", Controller],
        };
        function Controller($scope: IInputWithSaveScope) {

            var internalChange = false;

            $scope.inputSaveSuccess = null; 
            $scope.inputValuePristine = null;

            $scope.$watch('inputValue', function (value) {
                $scope.storeEnabled = $scope.isStoreEnabled() !== false;
                $scope.inputSaveSuccess = null; 
                if (typeof (value) !== 'undefined' && !internalChange) {
                    $scope.inputValuePristine = value;
                    internalChange = false;
                }
            });

            $scope.internalChange = function () {
                internalChange = true;
            }

            $scope.reset = function () {
                $scope.inputValue = $scope.inputValuePristine;
            };

            $scope.storeInput = function () {
                if ($scope.storeEnabled) {
                    $scope.inputSaveSuccess = null;
                    var operation = $scope.onStoreInput();
                    if (operation) {
                        operation.$then(setSuccess, setFailure);
                    } else {
                        setSuccess();
                    }
                }
            };

            function setSuccess() {
                $scope.inputSaveSuccess = true;
                $scope.inputValuePristine = $scope.inputValue;
                $timeout(function () {
                    $scope.inputSaveSuccess = null; 
                }, 2000);
            }
            function setFailure() {
                $scope.inputSaveSuccess = false;
                $scope.inputValuePristine = $scope.inputValue;
            }
        }
    });
 