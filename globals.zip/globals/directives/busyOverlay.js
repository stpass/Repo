﻿/**
 * Attach a "busy" overlay (normally semi-transparent with spinner, but can be styled) to a block element.
 *
 * It depends on a boolean expression. When true, the overlay is visible.
 */
directive("busyOverlay", ["jQuery"],
function($) {
	"use strict";

	return {
		restrict: "A",

		link: function(scope, element, attrs) {
			var
				overlay, position,
				busyClass = attrs.busyClass || "busy-overlay";

			element.removeClass(busyClass);
			position = element.css("position");
			if( position == null || position === "static" )  element.css("position","relative");
			overlay = $("<div class='" + busyClass + "'><div class='content'></div></div>").appendTo(element);
			scope.$watch(attrs.busyOverlay, function(newval, oldval) {
				element.toggleClass("busy-overlay-busy", !!newval);
			});
		}
	};
});
