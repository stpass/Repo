﻿service("tabify", ["$location", "$routeParams"], function ($location, $routeParams) {
	"use strict";

	return function ($scope, paneKeys, paramName) {
	    var i, t = {}, paramName = paramName || "t";

	    for (i = 0; i < paneKeys.length; i++) {
	        t[paneKeys[i]] = {active: i === 0};
		}

		var unwatchRouteParam = $scope.$watch(function () { return $routeParams[paramName]; }, function (activeTab) {
		    if (activeTab) {
		        t.activate(activeTab);
		    }
		});

		var unwatchInternalState = $scope.$watch(function () { return t; }, function () {
			var i, activeTab = null;
			for( i=0; i < paneKeys.length; i++ ) {
				if( t[paneKeys[i]].active ) {
					activeTab = paneKeys[i];
					break;
				}
			}
			$location.replace();
			$location.search(paramName, activeTab);
		}, true);

		$scope.$on('$destroy', function () {
		    unwatchRouteParam();
		    unwatchInternalState();
		    $location.search(paramName, null).replace();
		});

		t.init = function () {
		    t.activate(paneKeys[0]);
		};

		t.clear = function () {
		    t.activate();
		};

		t.activate = function (viewToActivate) {
		    var i;
		    for (i = 0; i < paneKeys.length; i++) {
		        if (paneKeys[i] === viewToActivate) {
		            t[paneKeys[i]].active = true;
		        } else {
		            t[paneKeys[i]].active = false;
		        }
		    }
		};

		if ($routeParams[paramName]) {
		    t.activate($routeParams[paramName]);
		}

		return t;
    };



	//return function ($scope, paneKeys, defaultToFirst, paramName) {
	//    var i,
    //        t = {},
    //        paramName = paramName || "t",
    //        defaultToFirst = (typeof defaultToFirst === 'undefined' ? true : defaultToFirst),
	//        defaultPane = $routeParams[paramName] || (defaultToFirst ? paneKeys[0] : null);
	    
	//    for (i = 0; i < paneKeys.length; i++) {
	//        t[paneKeys[i]] = { active: (paneKeys[i] === defaultPane) };
	//    }

	//    $scope.$watch(function () { return t; }, function () {
	//        var i, activeTab = null;
	//        for (i = 0; i < paneKeys.length; i++) {
	//            if (t[paneKeys[i]].active) {
	//                t.activate(paneKeys[i]);
	//                break;
	//            }
	//        }
	//    }, true);

	//    $scope.$watch(function () { return $routeParams[paramName]; }, function (activeTab) {
	//        if (activeTab) {
	//            for (i = 0; i < paneKeys.length; i++) {
	//                if (paneKeys[i] === activeTab) {
	//                    t[paneKeys[i]].active = true;
	//                } else {
	//                    t[paneKeys[i]].active = false;
	//                }
	//            }
	//        }
	//    });

	//    t.init = function () {
    //        t.activate(paneKeys[0]);
	//    };

	//    t.clear = function () {
	//        t.activate(null);
	//    };

	//    t.activate = function (activeTab, replaceHistory) {
	//        replaceHistory = (typeof replaceHistory === 'undefined' ? true : replaceHistory);
	//        if (replaceHistory) {
	//            $location.replace();
	//        }
	//        $location.search(paramName, activeTab);
	//    };

	//    return t;
	//};
});
