﻿//:IResourceUtils<IResourceBase>
window.service("resourceUtils", ["messageSvc", "$q"], function (messageSvc, $q) {
    "use strict";

    var transformResponse = transformResponseFactory(false), transformArrayResponse = transformResponseFactory(true), getPayloadAction = {
        method: "GET",
        isArray: null,
        transformResponse: transformResponse
    }, getPayloadAsArrayAction = {
        method: "GET",
        isArray: true,
        transformResponse: transformArrayResponse
    }, postPayloadAction = {
        method: "POST",
        isArray: null,
        transformResponse: transformResponse
    }, postPayloadAsArrayAction = {
        method: "POST",
        isArray: true,
        transformResponse: transformArrayResponse
    };

    function transformResponseFactory(isArray) {
        return function (data, headersGetter) {
            var tData = null;
            try  {
                if (data != null && data != "")
                    tData = JSON.parse(data);
                else
                    tData = null;
            } catch (e) {
                return { $error: e, $rc: "FAILURE" };
            }
            if (tData != null && typeof (tData.payload) !== "undefined") {
                var ret;

                // handle the case where data.payload is null or non-object,
                // in which case its value will not be processed by $resource
                if (isArray) {
                    if (tData.payload === null) {
                        ret = [];
                        ret.$value = null;
                    } else if (!$.isArray(tData.payload))
                        throw new Error("expected array, got " + typeof (tData.payload));
                    else
                        ret = tData.payload;
                } else {
                    if (tData.payload === null)
                        ret = { $value: null };
                    else if (typeof (tData.payload) !== "object")
                        ret = { $value: tData.payload };
                    else
                        ret = tData.payload;
                }

                if ($.isArray(tData.messages))
                    ret.$messages = tData.messages;
                if (typeof (tData.hasMore) === "boolean")
                    ret.$hasMore = tData.hasMore;
                if (tData.exception == null) {
                    ret.$rc = "SUCCESS";
                } else {
                    ret.$rc = "FAILURE";
                    ret.$exception = tData.exception;
                    ret.$systemMessage = messageSvc.addError(ret.$exception.desc);
                }
                return ret;
            } else
                return $.extend(tData, { $error: null, $rc: "FAILURE" });
        };
    }

    /**
    * Wrap an object returned by a call to an Angular $resource (i.e. an
    * object or array having at least the `$resolved` and `$then` properties)
    * with another object whose `$then` promise gets rejected both when system
    * errors occur (HTTP status >= 400) and when business errors occur (HTTP
    * status < 400 but either `$rc` is `FAILURE` or `$exception` is non-null).
    */
    function wrapResource(r) {
        //var ret: IResource<T> = $.isArray(r) ? <IResource<T>>[] : <IResource<T>> {};
        var ret = $.isArray(r) ? [] : {};
        copyResourceProperties(r, ret);
        ret.$then = r.$then(function (response) {
            var res = response.resource;
            copyResourceProperties(r, ret);

            // This is the condition signifying true business success
            // TODO May need to be revised (e.g. $exception != null and $rc == 'FAILURE' are identical cases)
            if (res != null && res.$exception == null && res.$rc === "SUCCESS")
                return response;
            else
                return $q.reject(response);
        }, function (response) {
            copyResourceProperties(r, ret);
            return $q.reject(response);
        }).then;
        return ret;
    }

    function copyResourceProperties(src, dst) {
        dst.$resolved = src.$resolved;
        if (src.$error)
            dst.$error = src.$error;
        if (src.$rc)
            dst.$rc = src.$rc;
        if (src.$value)
            dst.$value = src.$value;
        if (src.$messages)
            dst.$messages = src.$messages;
        if (src.$hasMore)
            dst.$hasMore = src.$hasMore;
        if (src.$exception)
            dst.$exception = src.$exception;
        if (src.$systemMessage)
            dst.$systemMessage = messageSvc.findMessage(src.$systemMessage);
    }

    //:IResourceUtils<IResourceBase>
    var utility = {
        transformResponse: transformResponse,
        transformArrayResponse: transformArrayResponse,
        getPayloadAction: getPayloadAction,
        getPayloadAsArrayAction: getPayloadAsArrayAction,
        postPayloadAction: postPayloadAction,
        postPayloadAsArrayAction: postPayloadAsArrayAction,
        wrapResource: wrapResource
    };
    return utility;
});
//# sourceMappingURL=resourceUtils.js.map
