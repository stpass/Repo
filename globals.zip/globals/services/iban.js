﻿service("iban", ["jQuery"], function($) {
	"use strict";

	var IBAN_RE = /^([a-z]{2}[0-9]{2})([a-z0-9]{1,30})$/i,
		IBAN_NBG_RE = /^GR\d\d011\d\d\d\d00000\d{11}$/,
		CHARCODE_A="A".charCodeAt(0);

	function lmap(c,i,all) {
		if( i == null ) i=0;
		if( typeof(all) === "string" ) c = all;
		return ""+(c.charCodeAt(i)-CHARCODE_A+10);
	}

	// from http://www.tbg5-finance.org/  -->  http://www.tbg5-finance.org/ibandocs.shtml
	function ISO7064Mod97_10(s) {
		var parts = Math.ceil(s.length/7);
		var remainder = "";
		for (var i = 1; i <= parts; i++) {
			remainder = String(parseFloat(remainder+s.substr((i-1)*7, 7))%97);
		}
		return remainder;
	}

	/**
	 * IBAN according to rules here: http://en.wikipedia.org/wiki/International_Bank_Account_Number
	 * ***WARNING*** The modulo algorithm in Wikipedia is wrong for some reason!
	 *               See ISO7064Mod97_10() for the correct implementation.
	 * It accepts arbitrary spaces in the value.
	 */
	function isValid(value) {
		var r;
		if( value == null ) return true;
		if( typeof(value) !== "string" ) return false;
		value = value.replace(/\s/g,"");
		value = value.toUpperCase();
		r = IBAN_RE.exec(value);
		if( !r || r.length !== 3 ) return false;
		value = r[2] + r[1];
		value = value.replace(/[A-Z]/g, lmap);
		return parseInt(ISO7064Mod97_10(value)) === 1;
	}

	function makeCheckDigits(iban) {
		var r, value = iban;
		r = IBAN_RE.exec(value);
		value = r[2] + r[1].substring(0,2) + "00";
		value = value.replace(/[A-Z]/g, lmap);
		value = ISO7064Mod97_10(value);
		value = 98 - parseInt(value);
		return (value > 9 ? "" : "0") + value;
	}

	function fromNbgAccount(account) {
		if( account == null || !account.length || account.length != 11 ) throw new Error(account + " is not valid NBG account");
		var ret = "GR000110", checkDigits;
		ret += account.substr(0,3);
		ret += "00000";
		ret += account;
		checkDigits = makeCheckDigits(ret);
		ret = "GR" + checkDigits + ret.substr(4);
		return ret;
	}

	function format(text) {
		var i, res, counter, c;
		text = $.trim(text);
		for( counter=i=0, res=""; i < text.length; i++ ) {
			c = text.charAt(i);
			if( c !== " " ) { // handle preformatted data
				res += c;
				counter++;
				if( counter === 4 ) {
					res += " ";
					counter = 0;
				}
			}
		}
		return res;
	}

	return {
		IBAN_RE: IBAN_RE,
		IBAN_NBG_RE: IBAN_NBG_RE,
		lmap: lmap,
		ISO7064Mod97_10: ISO7064Mod97_10,
		makeCheckDigits: makeCheckDigits,
		fromNbgAccount: fromNbgAccount,
		isValid: isValid,
		format: format
	};
});
