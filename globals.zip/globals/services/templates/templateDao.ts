module ibank.templates {
    export interface ITemplateInfo {
        id: any;
        application: any;
        type: string;
        name: string;
        createdOn: Date;
        lastUpdatedOn: Date;
        lastUsedOn: Date;
    }
    export interface ITxTemplate extends ITemplateInfo{
        content: string;
    }
    export interface ITemplateDao {
        fetch: (types: string[]) => IResourceLite<ITemplateInfo[]>;
        fetchDetails: (id: string) => IResourceLite<ITxTemplate>;
        remove: (id: string) => IResourceLite<boolean>;
    }
    window.service("templateDao", ["httpPost", 'application'],
        function (httpPost: IHttpPost, application): ITemplateDao {
            "use strict";
            return {
                fetch: function ( types:string[]) {
                    var data = httpPost.forArray<ITemplateInfo>("api/template/meta", { templateTypes: types, application: application.APPL });
                    return data;
                },
                fetchDetails: function (id: string) {
                    var data = httpPost.forObject<ITxTemplate>("api/template/full", { templateID: id});
                    return data;
                },
                remove: function (id: string) {
                    var data = httpPost.forObject<boolean>("api/template/delete", { templateID: id, application: application.APPL });
                    return data;
                }

            };
        });
}