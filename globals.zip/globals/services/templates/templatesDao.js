﻿service(
    'templatesDao',
    ['$http', 'ctxPath', '$resource', 'UrlBuilder', 'resourceUtils', 'jQuery', 'wrapHttpRequest','application'],
    function ($http, ctxPath, $resource, UrlBuilder, ru, $, wrap, application) {
        'use strict';
        var
		    rc = $resource(ctxPath("api/template/"), {}, {
		        store: $.extend({ url: ctxPath("api/template/store") }, ru.postPayloadAction),
		        fetch: $.extend({ url: ctxPath("api/template/meta") }, ru.postPayloadAsArrayAction),
		        fetchDetails: $.extend({ url: ctxPath("api/template/full") }, ru.postPayloadAction),
		        remove: $.extend({ url: ctxPath("api/template/delete") }, ru.postPayloadAction)
		    });
        return {
            store: function (type, name, content) {
                var uuidStr = uuid.v4();
                return rc.store(
                    wrap({
                        Application: application.APPL,
                        Template: {
                            id: uuidStr,                            
                            type: type,
                            name: name,
                            application: application.APPL,
                            content: JSON.stringify(content, null)
                        }
                    })
                );
            },
            fetch: function(type, Application){
                return rc.fetch(
                    wrap({
                        templateTypes: type,
                        application: application.APPL
                    })
                 );
            },
            fetchDetails: function (TemplateID) {
                return rc.fetchDetails(
                    wrap({
                        templateID: TemplateID
                    })
                );
            },
            remove: function (TemplateID) {
                return rc.remove(
                    wrap({
                        templateID: TemplateID,
                        application: application.APPL
                    })
                );
            }
        };
    }
);