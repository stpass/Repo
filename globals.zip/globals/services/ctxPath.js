﻿service('ctxPath', ['imb'], function (imb) {
    'use strict';

    return function (path) {
        return imb.contextPath + imb.removeSlash(path);
    };
});
