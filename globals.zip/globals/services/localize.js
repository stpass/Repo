﻿window.service("localize", ["preprocess", "ctxPath", "$injector", "imb", "jQuery", 'wrapHttpRequest'], function (preprocess, ctxPath, $injector, imb, $, wrap) {
    var rootResource = {}, perModuleRcMap = {}, reportedKeys = {};

    function ResourceBundle() {
    }
    ;
    ResourceBundle.prototype = rootResource;

    function getResourceFor(moduleName) {
        var resource;
        if (typeof (moduleName) === "string")
            resource = perModuleRcMap[moduleName];
        if (resource == null)
            resource = rootResource;
        return resource;
    }

    var localize = function (key, moduleName) {
        if (typeof (key) !== "string")
            throw new Error("invalid type for key: " + typeof (key));
        var resource = getResourceFor(moduleName);
        return resource[key];
    };

    localize.addResources = function (moduleName, rc) {
        var resource;
        if (typeof (moduleName) === "string") {
            resource = perModuleRcMap[moduleName];
            if (resource == null) {
                resource = new ResourceBundle();
                perModuleRcMap[moduleName] = resource;
            }
        } else
            resource = rootResource;
        $.extend(resource, rc);
    };

    localize.reportMissingResource = function (key, defaultValue, moduleName) {
        if (imb.debugMode && !reportedKeys[key]) {
            reportedKeys[key] = true;
            if (moduleName == null)
                moduleName = "-";
            if (typeof (defaultValue) !== "string")
                defaultValue = "";
            $injector.get("$http").post(ctxPath("api/resources/missing"), wrap({ userID: null, moduleName: moduleName, key: key, defaultVal: defaultValue }));
            console.log("MISSING RESOURCE FROM MODULE " + moduleName + ": " + key);
        }
    };

    localize.localizeTemplate = function (templateStr, moduleName) {
        var result, resource = getResourceFor(moduleName);
        result = preprocess(templateStr, resource, function (key, defaultValue) {
            localize.reportMissingResource(key, defaultValue, moduleName);
        });
        return result;
    };

    return localize;
});
//# sourceMappingURL=localize.js.map
