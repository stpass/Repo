/**
 * A helper to construct URLs, possibly with query parameters.
 *
 * Initialize either using the constructor `new UrlBuilder()` or using the `local()`
 * factory `UrlBuilder.ctxRel()`. The `ctxRel()` factory will construct URLs relative
 * to the context path (using the `ctxPath` service). Both the constructor and the
 * factory take an optional initial path argument, e.g. `new UrlBuilder("api/foo")`.
 *
 * Append path elements using the `appendPath()` method. It will correctly append
 * slashes. This method takes varargs, i.e. `appendPath("foo","bar")` works as expected.
 *
 * Add query parameters using `addParams()`. It uses the `ParamsBuilder` service.
 * Calls to `appendPath()` and `addParams()` can be interleaved.
 *
 * Retrieve the URL string using `toUrl()`.
 *
 * The static utility method `UrlBuilder.addParams(pathNow, path)` appends `path`
 * to `pathNow` and returns the new value.
 *
 * Example:
 * var url = new UrlBuilder("/myapplication/api").appendPath("foo").addParams("search","bar").toUrl();
 * --> "/myapplication/api/foo?search=bar
 * var url = UrlBuilder.ctxRel("api").appendPath("foo").addParams("search","bar").toUrl();
 * --> same as above for contextPath=/myapplication
 */
service("UrlBuilder", ["ctxPath", "ParamsBuilder"], function (ctxPath, ParamsBuilder) {
	"use strict";
	
	function UrlBuilder(path) {
		this.path = path || "";
		this.params = null;
	}
	
	UrlBuilder.ctxRel = function(path) {
		return new UrlBuilder(ctxPath(path || ""));
	}
	
	UrlBuilder.appendPath = function(pathNow, path) {
		if( path != null ) {
			path = ""+path;
			var
				nowEndsWithSlash = (pathNow.length > 0 && pathNow.charAt(pathNow.length-1) === "/"),
				pathStartsWithSlash = (path.length > 0 && path.charAt(0) === "/");
			if( nowEndsWithSlash && pathStartsWithSlash ) {
				pathNow += path.substring(1);
			}
			else if( (nowEndsWithSlash && !pathStartsWithSlash) || (!nowEndsWithSlash && pathStartsWithSlash) ) {
				pathNow += path;
			}
			else {
				pathNow += "/" + path;
			}
		}
		return pathNow;
	}

	UrlBuilder.prototype.appendPath = function() {
		for(var i = 0; i < arguments.length; i++) {
			this.path = UrlBuilder.appendPath(this.path, arguments[i]);
		}
		return this;
	}
	
	UrlBuilder.prototype.addParams = function(name, values) {
		if( this.params === null ) this.params = new ParamsBuilder();
		this.params.addParams(name, values);
		return this;
	}
	
	UrlBuilder.prototype.toUrl = function() {
		var querystr = null, ret = this.path;
		if( this.params !== null ) querystr = this.params.build();
		if( querystr !== null && querystr.length > 0 ) ret += "?" + querystr;
		return ret;
	}
	
	return UrlBuilder;
});
