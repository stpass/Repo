﻿service(
    'auditDao',
    ['$http', 'ctxPath', '$resource', 'UrlBuilder', 'resourceUtils', 'jQuery', 'wrapHttpRequest', 'application'],
    function ($http, ctxPath, $resource, UrlBuilder, ru, $, wrap, application) {
        'use strict';
        var
		    rc = $resource(ctxPath("api/template/"), {}, {
		        fetch: $.extend({ url: ctxPath("api/audit/auditlatesttransaction") }, ru.postPayloadAsArrayAction),
		        details: $.extend({ url: ctxPath("api/audit/getaudititem") }, ru.postPayloadAction)
		    });
        return {            
            fetch: function (category, maxItems) {
                return rc.fetch(
                    wrap({
                        transactionCategory: category,
                        maxItems:maxItems
                    })
                 );
            },
            fetchDetails: function (id) {
                return rc.details( wrap({ auditItemID: id }));
            }
        };
    }
);