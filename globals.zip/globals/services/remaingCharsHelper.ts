interface IRemaingCharsCtx {
    setMaxChars: (maxChars: number, resetViewValue?: boolean) => void;
}

interface IRemaingCharsHelper {
    applyTo: (elem: ng.IAugmentedJQuery, ngModelCtrl: ng.INgModelController, initialMaxChars: number, position?: any) => IRemaingCharsCtx;
}

window.service("remaingCharsHelper", ["angular"], function (angular: ng.IAngularStatic): IRemaingCharsHelper {
    return {
        applyTo: function (elem: ng.IAugmentedJQuery, ngModelCtrl: ng.INgModelController, initialMaxChars: number, position?: any) {

            var counterElem = angular.element('<span class="badge"></span>');
            elem.before(counterElem);
            elem.css({ 'margin-bottom': '8px' }); // add some margin so that invalidMessage and badge don't overlap
            counterElem.parent().css({ position: 'relative' }); // set relative position to parent so that we can apply absolute position to counterElem
            var pos = angular.extend({ 'position': 'absolute', 'right': '5px', 'top': '19px' }, position);
            counterElem.css(pos);

            var maxChars = initialMaxChars;

            function countRemaining(value: string) {
                var valueLength = value && value.length ? value.length : 0;
                var remaining = maxChars - valueLength;
                if (remaining < 0) {
                    remaining = 0;
                }
                counterElem.text(remaining);
                return value;
            }

            ngModelCtrl.$formatters.push(countRemaining);
            ngModelCtrl.$parsers.unshift(countRemaining);

            return {
                setMaxChars: function (max: number, resetViewValue?: boolean) {
                    maxChars = max;
                    if (resetViewValue) {
                        ngModelCtrl.$setViewValue(ngModelCtrl.$viewValue);
                    }
                }
            };
        }
    };
}); 