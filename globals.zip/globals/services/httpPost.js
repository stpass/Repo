﻿window.service("httpPost", ["angular", "$q", "$http", "UrlBuilder", "wrapHttpRequest"], function (angular, $q, $http, UrlBuilder, wrap) {
    function resolve(resource, response) {
        resource.$resolved = true;
        if (response.data != null && response.data.messages != null) {
            resource.$messages = response.data.messages;
        }
    }

    function rejector(resource, response) {
        resource.$error = true;
        if (response.data != null && response.data.exception != null) {
            resource.$exception = response.data.exception;
        } else {
            resource.$exception = { 'code': 'SYSTEM', 'desc': 'System error', 'sev': 'Error', 'cat': 'System' };
        }
        return $q.reject(resource.$exception);
    }

    function httpPost(isArray, actionUrl, postData, unwrapPayloadFn) {
        var url = UrlBuilder.ctxRel(actionUrl).toUrl();
        var wrapped = wrap(postData);
        var resource = (isArray ? [] : {});
        var promise = $http.post(url, wrapped).then(function systemSuccess(response) {
            resolve(resource, response);
            if (response.data != null && response.data.exception == null) {
                unwrapPayloadFn = unwrapPayloadFn || angular.identity;
                var businessEntity = unwrapPayloadFn(response.data.payload);
                if (isArray && angular.isArray(businessEntity)) {
                    Array.prototype.push.apply(resource, businessEntity);
                } else {
                    angular.extend(resource, businessEntity);
                }
                return businessEntity;
            } else {
                return rejector(resource, response);
            }
        }, function systemError(response) {
            resolve(resource, response);
            return rejector(resource, response);
        });
        resource.$then = promise.then;
        resource.$resolved = false;
        resource.$error = false;
        resource.$requestId = wrapped.header.ID;
        resource.$exception = null;
        resource.$messages = null;
        resource.$promise = promise;
        return resource;
    }

    return {
        forObject: function httpPostForObject(actionUrl, postData, unwrapPayloadFn) {
            return httpPost(false, actionUrl, postData, unwrapPayloadFn);
        },
        forArray: function httpPostForArray(actionUrl, postData, unwrapPayloadFn) {
            return httpPost(true, actionUrl, postData, unwrapPayloadFn);
        }
    };
});
//# sourceMappingURL=httpPost.js.map
