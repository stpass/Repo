var ibank;
(function (ibank) {
    (function (usersVoice) {
        window.service("usersVoiceDao", ["httpPost"], function (httpPost) {
            "use strict";
            return {
                auditIssue: function (params) {
                    var data = httpPost.forObject("api/audit/auditIssue", params);
                    return data;
                }
            };
        });
    })(ibank.usersVoice || (ibank.usersVoice = {}));
    var usersVoice = ibank.usersVoice;
})(ibank || (ibank = {}));
//# sourceMappingURL=usersVoiceDao.js.map
