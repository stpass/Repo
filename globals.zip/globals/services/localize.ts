﻿interface StrToStr {
	[name: string]: string;
}

interface ILocalizeService {
	(key: string, moduleName?: string): string;
	reportMissingResource(key: string, defaultValue: string, moduleName: string): void;
	localizeTemplate(templateStr: string, moduleName: string): string;
	addResources(moduleName: string, rc: StrToStr): void;
}

window.service("localize", ["preprocess", "ctxPath", "$injector", "imb", "jQuery", 'wrapHttpRequest'],
function(
	preprocess: IFnPreprocess,
	ctxPath   : (path: string) => string,
	$injector : ng.auto.IInjectorService,
	imb       : IMB,
	$         : JQueryStatic,
	wrap      : (payload: any) => any
): ILocalizeService {

    var rootResource: StrToStr = {}, perModuleRcMap: { [name: string]: StrToStr; } = {}, reportedKeys: { [name: string]: boolean; } = {};

	function ResourceBundle() {};
	ResourceBundle.prototype = rootResource;

	function getResourceFor(moduleName?: string): StrToStr {
		var resource: StrToStr;
		if( typeof(moduleName) === "string" ) resource = perModuleRcMap[moduleName];
		if( resource == null ) resource = rootResource;
		return resource;
	}

	var localize: any = function(key: string, moduleName?: string): string {
		if( typeof(key) !== "string" ) throw new Error("invalid type for key: " + typeof(key));
		var resource: StrToStr = getResourceFor(moduleName);
		return resource[key];
	};

	localize.addResources = function(moduleName: string, rc: StrToStr): void {
		var resource: StrToStr;
		if( typeof(moduleName) === "string" ) {
			resource = perModuleRcMap[moduleName];
			if( resource == null ) {
				resource = new ResourceBundle();
				perModuleRcMap[moduleName] = resource;
			}
		}
		else resource = rootResource;
		$.extend(resource,rc);
	};

	localize.reportMissingResource = function(key: string, defaultValue: string, moduleName: string): void {
		if( imb.debugMode && !reportedKeys[key] ) {
			reportedKeys[key] = true;
			if( moduleName == null ) moduleName = "-";
			if( typeof(defaultValue) !== "string" ) defaultValue = "";
			$injector.get("$http").post(
				ctxPath("api/resources/missing"),
				wrap({userID:null,moduleName:moduleName,key:key,defaultVal:defaultValue})
			);
			console.log("MISSING RESOURCE FROM MODULE " + moduleName + ": " + key);
		}
	}

	localize.localizeTemplate = function(templateStr: string, moduleName: string): string {
		var result: string, resource: StrToStr = getResourceFor(moduleName);
		result = preprocess(templateStr,resource, function(key, defaultValue) {
			localize.reportMissingResource(key, defaultValue, moduleName);
		});
		return result;
	};

	return localize;
});
