﻿service("messageSvc", ["$timeout", "jQuery"], function($timeout, $) {
	"use strict";

	var messages = [], DEFAULT_TIMEOUT = 10000;


	function Message(text, type, isPersistent, timeout) {
		this.msg = text;
		this.type = type || "info";
		if( typeof(isPersistent) === "number" ) {
			timeout = isPersistent;
			isPersistent = timeout <= 0;
		}
		if( typeof(timeout) !== "number" ) timeout = DEFAULT_TIMEOUT;
		if( typeof(isPersistent) === "undefined" && timeout > 0 ) isPersistent = false;
		this.isPersistent = typeof(isPersistent) === "boolean" ? isPersistent : true;
		this.timeout = isPersistent ? 0 : timeout;
		if( !this.isPersistent ) makeMessageTimeout(this);
	}

	Message.prototype.remove = function() {
		if( typeof(this.pin) === "function" ) this.pin();
		removeMessage(this);
	};


	function addMessage(text, type, opts) {
		var isPersistent, timeout, scrollToView = true;
		if( opts != null ) {
			isPersistent = opts.isPersistent;
			timeout = opts.timeout;
			if( typeof(opts.scrollToView) === "boolean" ) scrollToView = opts.scrollToView;
		}
		var m = new Message(text, type, isPersistent, timeout);
		messages.push(m);
		if( scrollToView ) scrollToViewFn();
		return m;
	}

	function addError(text, opts) {
		return addMessage(text, "error", opts);
	}
	function addWarn(text, opts) {
		return addMessage(text, "warning", opts);
	}
	function addInfo(text, opts) {
		return addMessage(text, "info", opts);
	}
	function addSuccess(text, opts) {
		return addMessage(text, "success", opts);
	}

	function removeMessage(m) {
		// XXX  When the resourceUtils.transformResponse method adds a message, it gets copied
		// XXX  to the resulting resource from Angular as a hash, not as a proper Message object.
		var index = m instanceof Message ? messages.indexOf(m) : messageIndexOf(m);
		m.removed = true;
		if( index >= 0 ) {
			messages.splice(index,1);
			return true;
		}
		else return false;
	}

	function messageIndexOf(m) {
		var i;
		for( i=0; i < messages.length; i++ ) {
			if( m.msg === messages[i].msg && m.type === messages[i].type ) return i;
		}
		return -1;
	}

	function makeMessageTimeout(m) {
		var timeout = $timeout(function() {
			removeMessage(m);
		}, m.timeout);
		m.pin = function() {
			$timeout.cancel(timeout);
		};
	}

	function scrollToViewFn(callback) {
		var opts = { easing:"easeOutExpo", axis:"y" };
		if( typeof(callback) === "function" ) opts.onAfter = callback;
		if( !$.isInView("#messageContainer") ) $.scrollTo("#messageContainer",1200,opts);
	}

	function findMessage(m) {
		var index = m instanceof Message ? messages.indexOf(m) : messageIndexOf(m);
		if( index >= 0 ) return messages[index];
		else return null;
	}

	return {
		messages: messages,
		addMessage: addMessage,
		removeMessage: removeMessage,
		addError: addError,
		addWarn: addWarn,
		addInfo: addInfo,
		addSuccess: addSuccess,
		scrollToView: scrollToViewFn,
		findMessage: findMessage
	};
});
