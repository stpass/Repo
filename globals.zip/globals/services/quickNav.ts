﻿interface ILinkInfo {
    moduleName: string; 
    linkUrl: string;
    linkImage: string;
    linkTitle: string;
    linkName: string;
    sortOrder: number;
}

interface ILinkService {
    getLinks: () => ILinkInfo[];
    registerLink: (linkInfo: ILinkInfo) => void; 
}

window.service(
    "quickNav", ['imb'], function (imb: IMB) {
        var initialized: boolean = false;
        var links = [];

        return {
            getLinks: function getLinks(): ILinkInfo[]{
                if (!initialized) {
                    _.each(imb.applicationModules, function (mod) {
                        if (mod.quickLinks != null) {
                            _.each(mod.quickLinks, function (link: ILinkInfo) {
                                link.moduleName = mod.name; 
                                links.push(link);
                            });
                        }
                        //registerRoutes('/' + mod.name, null, mod.routes);

                        //function registerRoutes(prefix, rootNav, routes) {
                        //    function registerRoute(r) {
                        //        var nav = { route: prefix + ((r.route !== '/') ? r.route : ''), label: r.label, routes: r.routes };
                        //        if (rootNav === null && (r.isMainMenu || false)) {
                        //            $scope.navigation.push(nav);
                        //        }
                        //        routeIndex[nav.route] = rootNav || nav;
                        //        return nav;
                        //    }

                        //    _.each(routes, function (r) {
                        //        var nav = registerRoute(r);
                        //        if (r.routes && r.routes.length > 0) {
                        //            registerRoutes(nav.route, rootNav || nav, r.routes);
                        //        }
                        //    });
                        //}
                    });
                    initialized = true; 
                }
                return links;
            },
            registerLink: function registerLink(linkInfo: ILinkInfo): void {
                links.push(linkInfo);
            }
        }
    });
