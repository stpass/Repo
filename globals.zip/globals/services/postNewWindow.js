﻿service("postNewWindow", ["application", "jQuery", "wrapHttpRequest", "$window", "ctxPath"], function (application, $, wrap, $window, ctxPath) {
    return function (payload, apiCall, useIframe) {
        var content = wrap(payload);
        
        var htmlContent = "<html><body>";
        htmlContent += "<form method='POST' ";
        // We don't pass token in url but rather in form
        // CSRF tokens in GET requests are potentially leaked at several locations: 
        // browser history, HTTP log files, network appliances that make a point to 
        // log the first line of an HTTP request, and Referrer headers if the protected 
        // site links to an external site. 
        htmlContent += "action='" + $window.location.protocol + "//" + $window.location.host + ctxPath("api/" + apiCall) + "'>";
        // Get the anti xss token
        var token = $("input[name='__RequestVerificationToken']").val();
        htmlContent += "<input type='hidden' name='__RequestVerificationToken' value='" + token + "'/>";
        //TODO I KNOW HOW WRAP WORKS!
        //header, payload
        for (var prop in content.header) {
            if (content.header.hasOwnProperty(prop)) {
                htmlContent += "<input type='hidden' name='header." + prop + "' value='" + content.header[prop] + "'/>";
            }
        }
        for (var prop in content.payload) {
            if (content.payload.hasOwnProperty(prop)) {
                htmlContent += "<input type='hidden' name='payload." + prop + "' value='" + content.payload[prop] + "'/>";
            }
        }
        if (!useIframe) {
            var w = $window.open();
            $(w.document.body).html(htmlContent);
            $("form", w.document.body).submit();
        } else {
            var w = $("<iframe style='display:none'/>").appendTo('body');
            // Get the contentWindow in a cross browser way
            var windowDocument = w[0].contentWindow || w[0].contentDocument;
            // Write the content in the document;
            windowDocument.document.open();
            windowDocument.document.write(htmlContent);
            windowDocument.document.close();
            // Submit form
            var form = w.contents().find('form');
            if (form != null) {
                form.submit();
            }
        }
    };
})



