﻿module ibank.customAppl {
    export interface ICustomApplDao {
        changeCounter: number;
        insert: (params: ICustomApplRequest) => IResourceLite<ICustomApplResponse>;
        selectCount: (params: ICustomApplCountRequest) => IResourceLite<any>;
    }
    export interface ICustomApplRequest {
        appl: string;
        subappl: string;
        amount?: number;
        debitFlag?: string;
        appl_data?: any;
        account?: string;
        tanNumber?: string;
    }
    export interface ICustomApplCountRequest {
        appl: string;        
    }
    export interface ICustomApplCountResponse {
        totals: number;
        subAppl: Array< { name: string; totals: number;}>;
    }
    export interface ICustomApplResponse {
        id: string;
        transactionDate: string;
        tanCheck: string;
    }
    window.service("customApplDao", ["httpPost"],
        function (httpPost: IHttpPost): ICustomApplDao {
            "use strict";
            var dao = {
                changeCounter: 0,
                insert: function (params: ICustomApplRequest) {
                    var data = httpPost.forObject<ICustomApplResponse>("api/customapplication/insert", params);
                    data.$then(function () {
                        dao.changeCounter++;
                    });
                    return data;
                },
                selectCount: function (params: ICustomApplCountRequest) {
                    var data = httpPost.forObject<ICustomApplCountResponse>("api/customapplication/selectcount", params);
                    return data;
                }
            };
            return dao;
        });
} 