interface IHelpResolver {
    (locator: string) : string;
}
interface IHelpService {
    addSource: (moduleName: string, resolver: IHelpResolver) => void;
    getResolver: (moduleName: string) => IHelpResolver;
    resolve: (moduleName: string, locator:string) => string;
}
window.service("help", [],
    function (): IHelpService {
        var moduleResolvers = {};
        var helpService: IHelpService = {
            addSource: null,
            getResolver: null,
            resolve: null
        };
        helpService.addSource = function (moduleName: string, resolver: IHelpResolver) {
            if (typeof (moduleName) === "string") {
                moduleResolvers[moduleName] = resolver;
            }
            else {

            }
        };
        helpService.getResolver = function (moduleName: string): IHelpResolver {
            if (typeof (moduleName) === "string") {
                return moduleResolvers[moduleName];
            }
            else {
                return null;
            }
        };
        helpService.resolve = function (moduleName: string, locator: string): string {
            var resolver = helpService.getResolver(moduleName);
            if (resolver != null) {
                return resolver(locator);
            }
            return null;
        }

        return helpService;
    }
    );