﻿service("validatorService", ["localize", "moment", "$locale", "iban", "jQuery"], function (localize, moment, $locale, iban, $) {

	var formatString = function() {
		if (arguments.length > 0) {
			if (arguments.length == 1) return arguments[0]; // No arguments to format
			var input = arguments[0];
			var args = arguments;
			return input.replace(/{(\d+)}/g, function (match, number) {
				// Convert string to number
				var argsIndex = 1 + 1 * number;
				return typeof args[argsIndex] != 'undefined'
                    ? args[argsIndex] : match;
			});
		} else {
			return "";
		}
	};
     
	// Returns a new string that right-aligns the characters in value 
	// by padding them on the left with a specified Unicode character, 
	// for a specified total length.
	// Returns: A new string that is equivalent to value, but right-aligned 
	// and padded on the left with as many paddingChar characters as needed to create 
	// a length of totalWidth. However, if totalWidth is less than or equal to the length 
	// the value, the method returns the value. 
	// Params: 
	//   value : The string to pad
	//   totalWidth: The number of characters in the resulting string, equal to the number of original characters plus any additional padding characters.
	//   paddingChar: A padding character.
	var padLeft = function (value, totalWidth, paddingChar) {
		if (value == null) return Array(totalWidth + 1).join(paddingChar);
		value = '' + value; // Cast to string
		if (value.length >= totalWidth) return value;
		return Array(totalWidth + 1 - value.length).join(paddingChar) + value;
	};

	var isInt = function(string) {
		var er = /^\d+$/; // Check if it contains only digits
		return er.test(string);
	};
    

	var getMessage = makeGetMessageWithLocalize(localize);


	var validationFns = {
		length: function (thisObj, value, validationContext, validationParameters) {
			// Nothing to validate against
			if (value == null || validationParameters == null) return true;
			if( typeof(validationParameters.condition) === "function") {
				if( !!validationParameters.condition.call(thisObj) === false ) return true; // condition is false, validator is inactive
			}
			if( validationParameters.trim === true ) value = $.trim(value);
			if (validationParameters.max && value.length > validationParameters.max) {
				var message = getMessage("valid_MaxLength", validationParameters);
				message = formatString(message, validationParameters.max);
				validationContext.setMessage(message);
				return false;
			}
			if (validationParameters.min && value.length < validationParameters.min) {
				var message = getMessage("valid_MinLength", validationParameters);
				message = formatString(message, validationParameters.min);
				validationContext.setMessage(message);
				return false;
			}
			return true;
		},
		/**
		 * Checks a number against the given boundaries.
		 * The `value` argument must be of type number, otherwise an error is reported.
		 * Use an appropriate formatter directive to ensure `value` is number.
		 * Recognized `validationParameters`:
		 * - `max`: The maximum value, may be function in which case it will be called with all
		 *          the arguments of this function.
		 * - `maxni`: As `max`, but non-inclusive, i.e. the value cannot equal `maxni`.
		 * - `min`: The minimum value, may be function in which case it will be called with all
		 *          the arguments of this function.
		 * - `minni`: As `min`, but non-inclusive, i.e. the value cannot equal `minni`.
		 */
		bound: function(thisObj, value, validationContext, validationParameters) {
			var msg, tmp = null, invalid;
			if( typeof(validationParameters.condition) === "function") {
				if( !!validationParameters.condition.call(thisObj) === false ) return true; // condition is false, validator is inactive
			}
			if( value != null && $.trim(value) !== "" ) {
			    value = parseFloat(value);
			    if( isNaN(value) || typeof(value) !== "number" ) {
					msg = getMessage("valid_Number", validationParameters);
					validationContext.setMessage(msg);
					return false;
				}
				if( validationParameters.max != null ) {
					makeTmp(validationParameters.max);
					invalid = applyCheck(typeof(tmp) === "number" && value > tmp, "valid_Max");
					if( invalid ) return false;
				}
				if( validationParameters.maxni != null ) {
					makeTmp(validationParameters.maxni);
					invalid = applyCheck(typeof(tmp) === "number" && value >= tmp, "valid_Maxni");
					if( invalid ) return false;
				}
				if( validationParameters.min != null ) {
					makeTmp(validationParameters.min);
					invalid = applyCheck(typeof(tmp) === "number" && value < tmp, "valid_Min");
					if( invalid ) return false;
				}
				if( validationParameters.minni != null ) {
					makeTmp(validationParameters.minni);
					invalid = applyCheck(typeof(tmp) === "number" && value <= tmp, "valid_Minni");
					if( invalid ) return false;
				}
			}
			return true;

			function makeTmp(param) {
				if( typeof(param) === "function" ) tmp = param(thisObj, value, validationContext, validationParameters);
				else if( typeof(param) === "number" ) tmp = param;
			}

			function applyCheck(invalid, msgKey) {
				if( invalid ) {
					msg = getMessage(msgKey, validationParameters);
					msg = formatString(msg, tmp);
					validationContext.setMessage(msg);
				}
				tmp = null;
				return invalid;
			}
		},
		/** Checks that the date part of value is after now. */
		futureDate: makeValidator("valid_FutureDate", function(value, thisObj, validationContext, validationParameters) {
			var m = moment(value), equalsOk = (validationParameters && !!validationParameters.equalsOk);
			return m == null || m.startOf("day").isAfter() || (equalsOk && m.startOf("day").isSame(moment().startOf("day")));
		}),
		/** Checks that the date part of value is before now. */
		pastDate: makeValidator("valid_PastDate", function(value, thisObj, validationContext, validationParameters) {
			var m = moment(value), equalsOk = (validationParameters && !!validationParameters.equalsOk);
			return m == null || m.endOf("day").isBefore() || (equalsOk && m.startOf("day").isSame(moment().startOf("day")));
		}),
		/**
		 * Checks that the date of this field is after (optionally or equals) the date of another field.
		 * Recognized `validationParameters`:
		 * - `otherField`: (required) Name of the other field with which to compare.
		 * - `equalsOk`: (optional) (boolean - default false) Whether equal dates validate.
		 */
		after: makeValidator("valid_After", function(value, thisObj, validationContext, validationParameters) {
		    if (validationParameters == null || typeof (validationParameters.otherField) !== "string") throw new Error("validationParameters.otherField should be a string");
		    if (value == null || thisObj[validationParameters.otherField] == null) return true;
			var m = moment(value), other = moment(thisObj[validationParameters.otherField]);
			if( !!validationParameters.equalsOk && m.startOf("day").isSame(other.startOf("day")) ) return true;
			return m.startOf("day").isAfter(other);
		}),
		/** Checks that the value is a string consisting of latin characters and spaces only. */
		allLatin: makeValidator("valid_AllLatin", function(value) {
			return (typeof(value) === "string") && /^[a-z ]*$/i.test(value);
		}),
		/** Checks that the value is a string consisting of capital latin characters and spaces only. */
		allLatinCaps: makeValidator("valid_AllLatinCaps", function(value) {
			return (typeof(value) === "string") && /^[A-Z ]*$/.test(value);
		}),
		/** Checks that the value is a string consisting of capital latin characters and spaces only. */
		allLatinCapsAndNumbers: makeValidator("valid_AllLatinCapsAndNumbers", function(value) {
			return (typeof(value) === "string") && /^[A-Z0-9 ]*$/.test(value);
		}),
		capsAndNumbers: makeValidator("valid_CapsAndNumbers", function(value) {
			return (typeof(value) === "string") && /^[A-ZΑ-Ω0-9 ]*$/.test(value);
		}),
		onlyCaps: makeValidator("valid_OnlyCaps", function(value) {
			if( typeof(value) !== "string" ) return false;
			var i;
			for( i=0; i < value.length; i++ ) {
				if( value[i].toUpperCase() !== value[i] ) return false;
			}
			return true;
		}),
		/**
		 * Checks that the field exists.
		 * Calls the function `condition` from validationParameters to check whether the field
		 * is actually required. If that function does not exist, the field is considered to be
		 * required by default. `condition()` is called in the context of `thisObj`.
		 */
		required: function(thisObj, value, validationContext, validationParameters) {
			var ret = true, required = true;
			if( validationParameters != null && typeof(validationParameters.condition) === "function") {
				required = !!validationParameters.condition.call(thisObj);
			}
			if( validationParameters == null || typeof(validationParameters.condition) !== "function" || required ) {
				if( value == null ) ret = false;
				else if( typeof(value) === "string" && $.trim(value) === "" ) ret = false;
			}
			return ret;
		},
		AlphanumericAndSpacesOnly: makeValidator("valid_AlphanumericAndSpacesOnly", function (value) {
		    if (value == null || typeof value !== "string") return false;
		    // Test if comment contains only alphanumeric and spaces
		    // TODO: Support accents
		    return /^(\s|[0-9a-zA-Zα-ωΑ-Ω])+$/g.test(value);
		}),
		ValidTAXID: makeValidator("valid_TAXID", function (value) {
		    if (value == null) { return true; }
		    value = $.trim(value);
		    if (value.length == 0) { return true; }
		    if (value.length < 8 || value.length > 9) { return false; }
		    if (!isInt(value)) { return false;}
		    value = padLeft(value, 9, "0");
		    var sum1 = 0, digitValue = 0, chkDigit = 0, power=2;
		    digitValue = parseInt(value.substr(8, 1),10);
		    for (var i = 7; i >= 0; i--)
		    {
		        sum1+=parseInt(value.substr(i,1),10)*power;
		        power = power * 2;
		    }
		    chkDigit = sum1 % 11;
		    if (chkDigit == 10) { chkDigit = 0;}
		    return chkDigit == digitValue;		    
		}),
		ValidYear:makeValidator("valid_Year", function(value){
		    var text = /^[0-9]+$/;
		    if (value == null) { return true; }
		    value = $.trim(value);
		    if (!text.test(value)) { return false; }
		    if (value.length != 4) { return false; }
		    return true;
        }),
        /** Deferred Section **/
		ValidDefferredTotalPayments: makeValidator("valid_DeferredTotalPayments", function (value, thisObj, validationContext, validationParameters) {
		    var frequency = thisObj[validationParameters.freq];
		    if (value == null) { return true; }
		    if (frequency == null) { return true; }
		    value = $.trim(value);
			frequency = $.trim(frequency);
		    if (!isInt(value)) { return false; }
		    if (!isInt(frequency)) { return false; }
		    var maxTotal = 0;
		    maxTotal = parseInt(value) * parseInt(frequency);
		    if (maxTotal > 60) {
		        var message = getMessage("valid_DeferredTotalPayments", validationParameters);
		        message = formatString(message, 1, 60 / parseInt(frequency||''));
		        validationContext.setMessage(message);
		        return false;
		    }
		    return true;
		}),
		/** Checks if value is a number */
		number: (function() {
			var numberRe = new RegExp(
				"^(?:-|\\+)?" + // an optional sign
				"\\d" +         // a mandatory digit
				"(?:\\d|" +
				escapeRegExp($locale.NUMBER_FORMATS.GROUP_SEP) +
				")*" +          // optionally more digits and grouping separators in any order (we are lenient)
				"(?:" +
				escapeRegExp($locale.NUMBER_FORMATS.DECIMAL_SEP) +
				"\\d+)?$"       // optionally a single decimal separator followed by one or more digits
			);
			
			return makeValidator("valid_Number", function (value) {
				return new numberRe.test(value);
			})
		})(),
		/**
		 * Validates the input against a regular expression, given in `validationParameters.re`.
		 * The empty string is considered valid, as are null values!!!
		 */
		regexp: makeValidator("valid_Regexp", function(value, thisObj, validationContext, validationParameters) {
			if( typeof(validationParameters.re) === "string" ) validationParameters.re = new RegExp(validationParameters.re);
			if( !(validationParameters.re instanceof RegExp) ) throw new Error("validationParameters.re is not a regular expression");
			return (typeof(value) === "string") && (value === "" || validationParameters.re.test(value));
		}),
		TAN: (function() {
			var TAN_RE = /^\d{6,8}$/;
			return makeValidator("valid_TAN", function(value, thisObj, validationContext, validationParameters) {
				return (typeof(value) === "string") && (value === "" || TAN_RE.test(value));
			})
		})(),
		/**
		 * IBAN according to rules here: http://en.wikipedia.org/wiki/International_Bank_Account_Number
		 * ***WARNING*** The modulo algorithm in Wikipedia is wrong for some reason!
		 *               See ISO7064Mod97_10() for the correct implementation.
		 * It accepts arbitrary spaces in the value.
		 */
		iban: makeValidator("valid_Iban", iban.isValid),
		nbgAccount11: makeValidator("valid_NbgAccount11", function(value, thisObj, validationContext, validationParameters) {
			if( value === null || value === "" || typeof(value) === "undefined" ) return true; // accept empty
			if( typeof(value) === "number" ) value = String(value);
			else if( typeof(value) !== "string" ) return false;
			value = $.trim(value);
			// fail fast: it has to be 11 digits
			if( value.length !== 11 ) return false;
			var d = value.match(/\d/g);
			// checkdigit X1
			var sum = parseInt(d[3])*7 + parseInt(d[4])*6 + parseInt(d[5])*5
				+ parseInt(d[6])*4 + parseInt(d[7])*3 + parseInt(d[8])*2;
			var rem = sum % 11;
			var x1 = -1;
			if( rem === 1 || rem === 0 ) x1 = 0;
			else x1 = 11 - rem;
			if( parseInt(d[9]) !== x1 ) return false;
			// checkdigit X2
			sum = parseInt(d[1])*10000 + parseInt(d[3])*1000 + parseInt(d[5])*100 + parseInt(d[7])*10 + parseInt(d[9]);
			sum = sum * 2;
			var sd = digits(sum);
			sum = parseInt(d[0]) + parseInt(d[2]) + parseInt(d[4]) + parseInt(d[6]) + parseInt(d[8]);
			for( var i=0; i < sd.length; i++ ) sum += sd[i];
			rem = sum % 10;
			var x2 = -1;
			if( rem === 0 ) x2 = 0;
			else x2 = 10 - rem;
			return parseInt(d[10]) === x2;

			/** Convert an integer to the array of its digits. */
			function digits(x) {
				var ret = [];
				while( x > 0 ) {
					ret.push(x % 10);
					x = Math.floor(x / 10);
				}
				return ret;
			}
		})
	};

	/** Make a validator function from the actual test and the error message key. */
	function makeValidator(msgKey, test) {
		return function validationHelper(thisObj, value, validationContext, validationParameters) {
			var ret = true, msg;
			if( value != null ) {
				if( validationParameters != null && typeof(validationParameters.condition) === "function") {
					ret = !!validationParameters.condition.call(thisObj);
					if( ret === false ) return true; // condition is false, validator is inactive
				}
				ret = test(value, thisObj, validationContext, validationParameters);
				if( ret === false ) {
					msg = getMessage(msgKey, validationParameters);
					if( validationContext && typeof(validationContext.setMessage) === "function" ) {
						validationContext.setMessage(msg);
					}
				}
			}
			return ret;
		};
	}

	function lookup(name) {
		if (validationFns.hasOwnProperty(name))
			return validationFns[name];
		else
			throw Error("Could not locate validator with name: " + name);
	}

	function register(x) {
		if( x == null ) return;
		var prop;
		for( prop in x ) {
			if( !x.hasOwnProperty(prop) ) continue;
			validationFns[prop] = x[prop];
		}
	}

	function escapeRegExp(str) { return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"); }

	function makeValidatorWithGetMessage(privateGetMessage) {
		privateGetMessage = privateGetMessage || getMessage;
		return function(msgKey, test) {
			return function validationHelper(thisObj, value, validationContext, validationParameters) {
				var ret = true, msg;
				if( value != null ) {
					if( validationParameters != null && typeof(validationParameters.condition) === "function") {
						ret = !!validationParameters.condition.call(thisObj);
						if( ret === false ) return true; // condition is false, validator is inactive
					}
					ret = test(value, thisObj, validationContext, validationParameters);
					if( ret === false ) {
						msg = privateGetMessage(msgKey, validationParameters);
						validationContext.setMessage(msg);
					}
				}
				return ret;
			};
		};
	}

	function makeGetMessageWithLocalize(privateLocalize) {
		privateLocalize = privateLocalize || localize;
		return function(key, validationParameters) {
			var message;

			if( validationParameters != null && validationParameters.msg ) {
				message = validationParameters.msg;
			}
			else {
				if( validationParameters != null && validationParameters.msgkey ) {
					key = validationParameters.msgkey;
				}

				message = privateLocalize(key);
				if (!message) {
					privateLocalize.reportMissingResource(key);
					message = "!!!" + key + "!!!";
				}
			}

			return message;
		};
	}

	return {
		lookup: lookup,
		register: register,
		helpers: {
			makeValidatorWithGetMessage: makeValidatorWithGetMessage,
			makeGetMessageWithLocalize: makeGetMessageWithLocalize,
			isInt: isInt,
			padLeft: padLeft
		},
		getMessage: getMessage
	};
});
