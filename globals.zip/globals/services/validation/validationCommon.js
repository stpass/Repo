﻿service("validationCommon", ["jQuery", "validatorService", "localize"], function ($, validatorService, localize) {
	"use strict";

	var DEFAULT_GROUPS = ["default"];

	function ValidationContextResult(flag, message, params) {
		this.flag = flag;
		this.message = message;
		this.params = params;
	}


	function KeyedMessage(key) {
		this.key = key;
	}
	KeyedMessage.prototype.toString = function() {
		return this.key;
	};


	function ValidationContext() {
		this.results = {};
	}

	ValidationContext.prototype = {
		results: null,
		stopped: false,
		currentValidatorName: null,
		currentMessage: null,
		currentParams: null,
		path: null,

		stopValidation: function(statusOverride) {
			this.stopped = true;
			if( statusOverride === true ) this.results = []; // force valid
			else if( statusOverride === false ) this.addResult(false);
		},

		isStopped: function() {
			return this.stopped;
		},

		setMessage: function(msg, params) {
			this.currentMessage = msg;
			if( typeof(params) !== "undefined" ) this.currentParams = params;
		},

		setMessageParams: function(params) {
			this.currentParams = params;
		},

		addResult: function(result) {
			var key, val;
			val = new ValidationContextResult(
				result,
				this.currentMessage || new KeyedMessage("valid_" + this.currentValidatorName.substring(0, 1).toUpperCase() + this.currentValidatorName.substring(1)),
				this.currentParams
			);
			if( this.path != null && this.path.length > 0 ) {
				key = this.path.join(".");
				if( this.results[key] == null ) this.results[key] = {};
				this.results[key][this.currentValidatorName] = val;
			}
			else {
				this.results[this.currentValidatorName] = val;
			}
		},

		setCurrentValidatorName: function(validatorName) {
			this.currentValidatorName = validatorName;
			this.currentMessage = null;
			this.currentParams = null;
		},

		hasValidationErrors: function() {
			var x;
			if( this.results == null ) return false;
			return hasValidationErrors(this.results);
		},

		pushPath: function(p) {
			if( typeof(p) !== "string" ) throw new Error("param p is required");
			p = $.trim(p);
			if( p === "" ) throw new Error("empty path");
			if( this.path == null ) this.path = [];
			this.path.push(p);
		},

		popPath: function(p) {
			if( this.path == null ) throw new Error("mismatched popPath() - path is null");
			var popped = this.path.pop();
			if( typeof(p) === "string" && p !== popped ) throw new Error("mismatched popped value (" + popped + ") - " + p);
		}
	};
	ValidationContext.prototype.constructor = ValidationContext;

	function hasValidationErrors(obj) {
		var x, tmp;
		for( x in obj ) {
			if( !obj.hasOwnProperty(x) ) continue;
			if( obj[x] instanceof ValidationContextResult ) {
				if( obj[x].flag === false ) return true;
			}
			else {
				tmp = hasValidationErrors(obj[x]);
				if( tmp ) return true;
			}
		}
		return false;
	}


	function extractValidationExpressions(modelExpression) {
		var
			indexDot = modelExpression.lastIndexOf("."),
			indexBracket = modelExpression.lastIndexOf("["), // TODO This does NOT handle nested brackets, hopefully this is a very rare case
			isDot = (indexDot >= indexBracket),
			index = (isDot ? indexDot : indexBracket),
			ret;
		if( index <= 0 ) throw new Error("cannot validate model expression: " + modelExpression); // TODO: Is this semantically correct?
		if( index === modelExpression.length-1 ) throw new Error("prop name not specified: " + modelExpression);
		ret = { ctx: modelExpression.substring(0,index) };
		if( isDot ) {
			ret.prop = "'" + modelExpression.substring(index+1) + "'";
		}
		else {
			ret.prop = modelExpression.substring(index+1, modelExpression.lastIndexOf("]"));
		}
		return ret;
	}

	/**
	 * Normalize the definition of each validator specification as:
	 * `[name:string, validator:function, options:object]`,
	 * where `options` will always contain a `groups:[]` array.
	 */
	function preProcessValidationSpec(validators, i) {
		var v = validators[i];
		// Allow shorthand validator definition, e.g. (note, no nested array):
		//   MyClass.myFieldValidators = [  "futureDate"  ];
		// instead of:
		//   MyClass.myFieldValidators = [ ["futureDate","futureDate"] ];
		if( typeof(v) === "string" ) {
			v = validators[i] = [v, v];
		}
		// Allow shorthand:
		//   MyClass.myFieldValidators = [ ["length", {max: 9}] ];
		// instead of:
		//   MyClass.myFieldValidators = [ ["length", "length", {max: 9}] ];
		if( typeof(v[1]) === "object" && v[2] == null ) {
			v[2] = v[1];
			v[1] = v[0];
		}
		// If a name is defined use the validatorService to pick the 
		// validation function
		if( typeof(v[1]) === "string" ) {
			v[1] = validatorService.lookup(v[1]);
		}
		// ensure there is a `groups` property
		if( v[2] == null ) v[2] = {};
		if( v[2].groups == null ) v[2].groups = DEFAULT_GROUPS;
		if( typeof(v[2].groups) === "string" ) v[2].groups = [v[2].groups];
		return v;
	}

	function executeValidations(validationContext, validators, ctxObject, value, groups) {
	    var i, res, v;
		if( groups == null ) groups = DEFAULT_GROUPS;
	    for (i = 0; i < validators.length; i++) {
			v = preProcessValidationSpec(validators, i);
			if( inGroups(v, groups) ) {
				validationContext.setCurrentValidatorName(v[0]);
				res = v[1](ctxObject, value, validationContext, v[2]);
				if( typeof(res) === "boolean" ) validationContext.addResult(res);
				if( validationContext.isStopped() ) break;
			}
	    }
	}

	function inGroups(validationSpec, groups) {
		var specGroups = validationSpec[2].groups, i;
		for( i=0; i < specGroups.length; i++ ) {
			if( groups.indexOf(specGroups[i]) >= 0 ) return true;
		}
		return false;
	}


	function produceValidationResult(scope, validationExpressions, value, groups) {
		var result = null;
		validationExpressions = transformValidationExpressions(scope, validationExpressions);
		if( validationExpressions.validatorSpecs ) {
			result = new ValidationContext();
			executeValidations(result, validationExpressions.validatorSpecs, validationExpressions.ctxObject, value, groups);
		}
		return result;
	}

	function extractCondition(scope, validationExpressions, name) {
		var result = null, validators, i, v;
		validationExpressions = transformValidationExpressions(scope, validationExpressions);
		if( validationExpressions.validatorSpecs ) {
			validators = validationExpressions.validatorSpecs;
			for( i=0; i < validators.length; i++ ) {
				if( validators[i] === name ) {
					result = true;
					break;
				}
				else if( angular.isArray(validators[i]) && validators[i][0] === name ) {
					v = preProcessValidationSpec(validators, i);
					result = (v[2] != null && typeof(v[2].condition) === "function") ? v[2].condition : true;
					break;
				}
			}
		}
		return result;
	}

	function transformValidationExpressions(scope, validationExpressions) {
		var validatorsName, result;

		result = {
			ctxObject: null,
			propertyName: null,
			validatorSpecs: null
		};

		result.ctxObject = scope.$eval(validationExpressions.ctx);
		if( result.ctxObject != null ) {
			result.propertyName = scope.$eval(validationExpressions.prop);
			validatorsName = result.propertyName + "Validators";
			if( typeof(result.ctxObject.constructor) === "function" && angular.isArray(result.ctxObject.constructor[validatorsName]) ) {
				result.validatorSpecs = result.ctxObject.constructor[validatorsName];
			}
		}

		return result;
	}

	function standardHandleMessage(element, key, message, valid) {
		var messageTarget = element.attr("validation-message-target"), targetSiblings;
		if( $.trim(messageTarget) !== "" ) {
			// append messages after the 1st child of the first parent of element with the given class
			messageTarget = element.parents("."+messageTarget+":eq(0)").find("*:eq(0)");
			if( messageTarget.length === 0 ) messageTarget = element;
		}
		else messageTarget = element;

		targetSiblings = messageTarget.siblings(".validation-msg." + key);

		if( !valid ) {
			var messageText = message != null ? (message instanceof KeyedMessage ? localize(message.key) : ""+message) : "";
			if( targetSiblings.length === 0 ) {
				var
					html = "<span class='help-block validation-msg " + key + "'>" + messageText + "</span>",
					pos = messageTarget.siblings(".validation-msg:last()");
				if( pos.length === 0 ) pos = messageTarget;
				pos.after(html);
			}
			else {
				targetSiblings.html(messageText);
			}
		}
		else {
			targetSiblings.remove();
		}
	}

	function adjustStyles(element, ngModel, deferErrorState) {
		var x, validExcludingRequired = ngModel.$valid;

		if( !validExcludingRequired ) {
			validExcludingRequired = true;
			for( x in ngModel.$error ) {
				if( !ngModel.$error.hasOwnProperty(x) || x === "required" ) continue;
				if( ngModel.$error[x] === true ) {
					validExcludingRequired = false;
					break;
				}
			}
		}

		if( deferErrorState === true ) {
			if( validExcludingRequired ) element.parents(".form-group:eq(0)").removeClass("has-error");
		}
		else element.parents(".form-group:eq(0)").toggleClass("has-error", !validExcludingRequired);
	}


	function checkValidationErrors(error) {
		for( var x in error ) {
			if( x === "required" || !error.hasOwnProperty(x) ) continue;
			if( error[x] !== false ) return true;
		}
		return false;
	}

	function makeStandardSubmitTooltipContent(valid, formCtrl, extraValidFlag) {
		if( !valid ) {
			var ret = [], error = formCtrl.$error;
			if (error.required && error.required.length > 0) ret.push(localize("Παρακαλώ συμπληρώστε όλα τα υποχρεωτικά", "_") + " (*) " + localize("πεδία", "_"));
			if( checkValidationErrors(error) || extraValidFlag === false ) ret.push("Παρακαλώ διορθώστε τα λάθη");
			return ret.join("<br/>");
		}
		else return false;
	}

	/**
	 * Run the validators specified for the given model and get the results as
	 * a <code>ValidationContext</code>.
	 *
	 * @param model  The model object to validate
	 * @param groups Validation groups; default value `default`; may be string, in which case it will be wrapped in an array
	 * @param eager  If <code>true</code> will return on first validation error encountered
	 * @param ...    Any strings following the last argument are property names; only those properties will be validated
	 * @return A <code>ValidationContext</code> or <code>null</code> if the model is <code>null</code>
	 */
	function validate(model, groups, eager) {
		var x, vctx, nparams = 3, props;
		if( model == null ) return null;
		if( typeof(groups) === "boolean" ) {
			eager = groups;
			groups = null;
		}
		if( !$.isArray(groups) ) {
			groups = DEFAULT_GROUPS;
			nparams -= 1;
		}
		if( typeof(eager) !== "boolean" ) {
			eager = false;
			nparams -= 1;
		}
		props = arguments.length > nparams ? $.makeArray(arguments).slice(nparams) : null;
		vctx = new ValidationContext();
		validateProperties(model, vctx, eager, groups, props);
		return vctx;
	}
	
	function validateProperties(model, vctx, eager, groups, props) {
		var x, validators;
		props = sanitize(props);
		for( x in model ) {
			if( props != null && props.indexOf(x) < 0 ) continue;
			validators = model.constructor[x + "Validators"];
			vctx.pushPath(x);
			if( $.isArray(validators) ) {
				executeValidations(vctx, validators, model, model[x], groups);
				if( eager && vctx.hasValidationErrors() ) {
					vctx.popPath(x);
					return;
				}
			}
			if( model[x] != null && typeof(model[x]) === "object" ) {
				if( !(model[x] instanceof Date) ) { // add other trivial cases where we do not want to step into object
					validateProperties(model[x], vctx, eager, groups);
				}
			}
			vctx.popPath(x);
		}

		function sanitize(props) {
			if( props == null ) return props;
			var i, ret = [];
			for( i=0; i < props.length; i++ ) {
				if( props[i] != null ) ret.push(props[i]);
			}
			return ret.length > 0 ? ret : null;
		}
	}

	/** Return a boolean indicating whether the given model object is valid. */
	function isValid(model, groups) {
		var nparams = 2, props, ret;
		if( model == null ) return true;
		if( !$.isArray(groups) ) {
			groups = DEFAULT_GROUPS;
			nparams -= 1;
		}
		props = arguments.length > nparams ? $.makeArray(arguments).slice(nparams) : [];
		ret = validate.apply(null, [model, groups, true].concat(props));
		if( ret == null || !ret.hasValidationErrors() ) return true;
		else return false;
	}

	return {
		DEFAULT_GROUPS: DEFAULT_GROUPS,
		extractValidationExpressions: extractValidationExpressions,
		produceValidationResult: produceValidationResult,
		standardHandleMessage: standardHandleMessage,
		adjustStyles: adjustStyles,
		makeStandardSubmitTooltipContent: makeStandardSubmitTooltipContent,
		extractCondition: extractCondition,
		validate: validate,
		isValid: isValid
	};
});
