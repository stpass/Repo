module ibank.usersVoice {
    export interface IAuditIssue {
        title: string;
        details: string;
        email: string;
    }

    export interface IAuditIssueResult {
    }

    export interface IUsersVoiceDao {
        auditIssue: (params: IAuditIssue) => IResourceLite<IAuditIssueResult>;
    }

    window.service("usersVoiceDao", ["httpPost"],
        function (httpPost: IHttpPost): IUsersVoiceDao {
            "use strict";
            return {
                auditIssue: function (params: IAuditIssue) {
                    var data = httpPost.forObject<IAuditIssueResult>("api/audit/auditIssue", params);
                    return data;
                }
            };
        });
}