﻿/**
 * A generic string preprocessor that replaces `@{key}` instances in the given string
 * with the key from the given resources and optionally notifies the caller about
 * missing keys.
 *
 * Usage:
 *   ["preprocess", function(preprocess) {
 *     var processed = preprocess(str, resources, missingKeyCallback);
 *   }]
 *
 * Arguments:
 * - str: The template string, possibly containing substitution placeholders
 * - resources: An object containing the substitution values
 * - missingKeyCallback: An optional function to be called when a key is not found in `resources`
 *                       with arguments (1) the key and (2) the default value, if any
 *
 * Returns:
 * - The new string with all substitutions executed
 *
 * Substitution placeholder syntax:
 * `@{key}` - Will be replaced by `resources.key`.
 * `@\{key}` - Escaped, will be replaced by the literal string `@{key}`.
 * `@\\{key}` - Escaped, will be replaced by the literal string `@\{key}` etc.
 * `@{key:"default value"} - Will be substitued by `resources.key`. If that does not exist,
 *                           the specified default value will be used.
 * `@{{...}}` - The value will be used unescaped; in all other cases it is passed through `$sanitize`.
 * `@{"default value"}` - The default value is also used as key.
 *
 * The key may consist only of latin characters, numbers and the undersore. It cannot start with
 * number. Whitespace can be placed around the key, the braces and the default value. E.g.
 * `@{   key :  "Default"    }` is valid. The default value must be within single or double quotes.
 * The quote that demarkates the default value can be present inside it in escaped form, e.g.
 * `@{key:"Default with \"quotes\""}`. The backslash needs to be escaped if it appears before a quote:
 * `@{key:"Default ending in backslash \\"}`. Any other backslash-character sequence will appear
 * literally, e.g. `@{key:"Default \2"}` -> `Default \2`.
 */
interface IFnPreprocess{
    ( str: string, resources: any, nonExistingKeyCb: (key:string, defaultValue:string) => void ): string;
}
window.service("preprocess",["$sanitize"],function($sanitize: ng.sanitize.ISanitizeService) {
	"use strict";
    
	var REG_START_STR = "@(\\\\?(\\\\*)){",
		REG_VALID_KEY_START = /[a-zA-Z_]/,
		REG_VALID_KEY_CHAR = /[a-zA-Z_0-9]/;

	function preprocess(str:string, resources:any, nonExistingKeyCb: (key:string, defaultValue:string) => void) {
		var res= [], i=0, j, regResult,
			regStart = new RegExp(REG_START_STR,"g");
	
		while( i < str.length ) {
			regResult = regStart.exec(str);
			if( regResult === null ) j = str.length;
			else j = regResult.index;
			if( j > i ) res.push(str.substring(i,j));
			i = regResult ? regStart.lastIndex : str.length;
			if( j < str.length ) {
				if( typeof(regResult[1]) === "string" && regResult[1].length > 0 ) {
					// the start marker is escaped, remove one slash, push it as string and continue
					res.push(regResult[0].replace(regResult[1],regResult[2]));
				}
				else {
					// the start marker is not escaped, parse expression
					i = parseExpression(str, i, j, res);
				}
			}
		}
		makeSubstitutions(res, resources, nonExistingKeyCb);
		return res.join("");
	}

	function parseExpression(str, exprStartIndex, exprStartIndexWithDemarkator, res) {
		var i=exprStartIndex, j, state=0, c="", key, keyStartIndex, defaultVal, stringDemarkationChar, isUnescaped=false;
		while( c !== null ) {
			c = (i < str.length ? str.charAt(i) : null);
			switch( state ) {
				case 0: // allowed whitespace before key
					if( i === exprStartIndex && c === "{" ) {
						isUnescaped = true;
						i++;
					}
					else if( !isWhitespace(c) ) {
						if( c.match(REG_VALID_KEY_START) ) {
							// process the key
							keyStartIndex = i;
							state = 1;
						}
						else if( c === "'" || c === '"' ) {
							// no key, just default value
							state = 3;
						}
						else throw makeErr("invalid key start character");
					}
					else i++;
					break;
				case 1: // reading key
					if( c.match(REG_VALID_KEY_CHAR) ) {
						i++;
					}
					else {
						key = str.substring(keyStartIndex, i);
						if( isWhitespace(c) ) {
							state = 2;
							i++;
						}
						else {
							state = 5;
						}
					}
					break;
				case 2: // allowed whitespace after key
					if( !isWhitespace(c) ) {
						state = 5;
					}
					else i++;
					break;
				case 3: // allowed whitespace after `:`
					if( !isWhitespace(c) ) {
						if( c === "'" || c === '"' ) {
							stringDemarkationChar = c;
							defaultVal = [];
							state = 6;
							i++;
						}
						else throw makeErr("invalid character following `:`");
					}
					else i++;
					break;
				case 4: // end of expression
					if( isUnescaped ) {
						// must find another `}`
						if( i >= str.length || str.charAt(i) !== "}" ) throw new Error("not properly terminated unescaped expression starting at " + exprStartIndexWithDemarkator);
						i++;
					}
					if( key == null ) {
						if( defaultVal == null ) throw new Error("neither key nore default value is specified in expression starting at " + exprStartIndexWithDemarkator);
						key = defaultVal.join("");
						if( key === "" ) throw new Error("empty default value in expression starting at " + exprStartIndexWithDemarkator);
					}
					res.push({
						key: key,
						defaultVal: (defaultVal != null ? defaultVal.join("") : null),
						isUnescaped: isUnescaped
					});
					return i;
				case 5: // first non-whitespace character after key
						if( c === ":" ) {
							state = 3;
							i++;
						}
						else if( c === "}" ) {
							state = 4;
							i++;
						}
						else throw makeErr("invalid character following key");
					break;
				case 6: // reading default value
					if( c === stringDemarkationChar ) {
						state = 7;
						i++;
					}
					else if( c === "\\" ) {
						i++;
						if( i < str.length ) { // if reached end of string, will exit while() and throw
							c = str.charAt(i);
							if( c === stringDemarkationChar ) {
								defaultVal.push(stringDemarkationChar);
								i++;
							}
							else if( c === "\\" ) {
								defaultVal.push("\\");
								i++;
							}
							else {
								defaultVal.push("\\"+c);
								i++;
							}
						}
					}
					else {
						defaultVal.push(c);
						i++;
					}
					break;
				case 7: // allowed whitespace after default value
					if( !isWhitespace(c) ) {
						if( c !== "}" ) throw makeErr("invalid character following default value");
						state = 4;
						i++;
					}
					else i++;
					break;
				default:
					throw new Error("landed at invalid state: " + state);
			}
		}
		throw new Error("incomplete expression starting at " + exprStartIndexWithDemarkator);

		function makeErr(msg) {
			var start = Math.max(i-20, 0),
				end = Math.min(i+20, str.length),
				ctx = str.substring(start,end).replace(/\n/g,"\\n").replace(/\r/g,"\\r").replace(/\t/g," ");
			return new Error(msg + " at position " + i + " ```" + ctx + "```");
		}
	}

	function isWhitespace(c) {
		return c === " " || c === "\t" || c === "\r" || c === "\n";
	}

	function makeSubstitutions(arr, resources: any, nonExistingKeyCb: (key:string, defaultValue:string) => void) {
		var i, subst;
		for( i=0; i < arr.length; i++ ) {
			if( typeof(arr[i]) === "object" ) {
				subst = resources[arr[i].key];
				if( subst == null ) {
					subst = arr[i].defaultVal;
					if( subst == null ) subst = "!!!" + arr[i].key + "!!!";
					if( nonExistingKeyCb !== null ) nonExistingKeyCb(arr[i].key, arr[i].defaultVal);
				}
				if( arr[i].isUnescaped ) arr[i] = subst;
				else arr[i] = $sanitize(subst);
			}
		}
	}

	return preprocess;
});
