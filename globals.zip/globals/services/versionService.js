﻿service('versionService', ['version'], function (version) {

    'use strict';

    return function () {
        return version;
    };
});
