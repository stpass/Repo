﻿/**
 * A number formatting service, using the java.util.DecimalFormat
 * formatting description. Takes the angular locale into account.
 * The actual formatter object that handles a format string is cached.
 *
 * Pattern string characters:
 *   Symbol Location     Localized? Meaning
 *   ---------------------------------------------------------------------------------
 *        0   Number        Yes     Digit
 *        #   Number        Yes     Digit, zero shows as absent
 *        .   Number        Yes     Decimal separator or monetary decimal separator
 *        -   Number        Yes     Minus sign
 *        ,   Number        Yes     Grouping separator
 *        E   Number        Yes     Exponent separator
 *        ;   Subpattern    Yes     Separates positive and negative subpatterns
 *            Boundary
 *        %   Prefix/Suffix Yes     Multiply by 100 and show as percentage
 *   \u2030   Prefix/Suffix Yes     Multiply by 1000 and show as per mille
 *   \u00A4   Prefix/Suffix No      Currency sign, replaced by currency symbol
 *        '   Prefix/Suffix No      Escape special characters
 *
 * Usage:
 *   ["numberFormat", function(numberFormat) {
 *     var parse = numberFormat.makeParser("#,###.00");
 *     var number = parse("123,456");
 *
 *     var format = numberFormat.makeFormatter("#,###.00");
 *     var formattedString = format(123.456);
 *   }]
 *
 * `parse()` will throw Error on error.
 */
(function(rcfaces) {
	service("numberFormat", ["jQuery", "$locale"], function($, $locale) {
		"use strict";

		var locale, Lctor, dfs, cache = {}, amountFormat, stockAmountFormat, intFormat,
			STOCK_AMOUNT_FRAC_DIGITS = 4, DEFAULT_DECIMAL_SEP = ".";

		// all this is to use apply() on a constructor
		Lctor = function() {};
		Lctor.prototype = rcfaces.F_Locale.prototype;
		locale = new Lctor();
		rcfaces.F_Locale.apply(locale,$locale.id.split("-"));

		dfs = new rcfaces.F_DecimalFormatSymbols(locale);
		dfs._currencySymbol = $locale.NUMBER_FORMATS.CURRENCY_SYM;
		dfs._decimalSeparator = $locale.NUMBER_FORMATS.DECIMAL_SEP;
		dfs._groupingSeparator = $locale.NUMBER_FORMATS.GROUP_SEP;

		amountFormat = (function() {
			var format = "#,", pat = $locale.NUMBER_FORMATS.PATTERNS[1], i;
			for( i=0; i <  pat.gSize-1; i++ ) {
				format += "#";
			}
			format += "0.";
			for( i=0; i < pat.minFrac; i++ ) {
				format += "0";
			}
			for( ; i < pat.maxFrac; i++ ) {
				format += "#";
			}
			return format;
		})();

		stockAmountFormat = (function() {
			var format = "#,", pat = $locale.NUMBER_FORMATS.PATTERNS[1], i;
			for( i=0; i <  pat.gSize-1; i++ ) {
				format += "#";
			}
			format += "0.";
			// XXX  Harcoded 4 decimal digits for stockAmount; may need to parameterize in the future
			for( i=0; i < STOCK_AMOUNT_FRAC_DIGITS; i++ ) {
				format += "0";
			}
			for( ; i < STOCK_AMOUNT_FRAC_DIGITS; i++ ) {
				format += "#";
			}
			return format;
		})();

		intFormat = (function() {
			var format = "#,", pat = $locale.NUMBER_FORMATS.PATTERNS[0], i;
			for( i=0; i <  pat.gSize-1; i++ ) {
				format += "#";
			}
			format += "0";
			return format;
		})();


		function retrieveDecimalFormat(format, postProcess) {
			var ret;
			ret = cache[format];
			if( ret == null ) {
				ret = {
					format: new rcfaces.F_DecimalFormat(format, dfs),
					parser: null,
					formatter: null
				};
				if( typeof(postProcess) === "function" ) postProcess(ret);
				cache[format] = ret;
			}
			return ret;
		}

		function makeParser(format, postProcess) {
			var
				f = retrieveDecimalFormat(format, postProcess),
				ret = f.parser;

			if( ret === null ) {
				ret = function parser(str) {
					if( $.trim(str) === "" ) return null;
					var
						p = new rcfaces.F_ParsePosition(),
						res = f.format.f_parse(str, p);
					if( res !== null ) return 0+res.f_value;
					else throw new Error("parse error at position " + p.f_index);
				};
				f.parser = ret;
			}

			return ret;
		}

		function makeFormatter(format, postProcess) {
			var
				f = retrieveDecimalFormat(format, postProcess),
				ret = f.formatter;

			if( ret === null ) {
				ret = function formatter(num) {
					if( $.trim(num) === "" ) return "";
					var sb = new rcfaces.F_StringBuffer();
					f.format.f_formatDouble(num, sb);
					return sb.toString();
				};
				f.formatter = ret;
			}

			return ret;
		}

		function makeCurrencyParser() {
			throw new Error("CurrencyParser: UNIMPLEMENTED");
		}

		function makeCurrencyFormatter() {
			throw new Error("CurrencyParser: UNIMPLEMENTED");
		}

		function makeAmountParser() {
			return makeParser(amountFormat);
		}

		function makeAmountFormatter() {
			return makeFormatter(amountFormat);
		}

		function makeIntParser() {
			return makeParser(intFormat, integerOnlyPostProcessor);
		}

		function makeIntFormatter() {
			return makeFormatter(intFormat, integerOnlyPostProcessor);
		}

		/** Make the format only parse ints and raise error if a decimal part is present. */
		function integerOnlyPostProcessor(f) {
			f.format.f_setParseIntegerOnly(true);
		}

		function makeStockAmountParser() {
			return makeParser(stockAmountFormat);
		}

		function makeStockAmountFormatter() {
			return makeFormatter(stockAmountFormat);
		}


		/**
		 * Based on Angular's implementation, but does not display digit grouping.
		 */
		function formatNumber(number, pattern, decimalSep, fractionSize) {
			if( number == null || isNaN(number) || !isFinite(number)) return '';
	
			var isNegative = number < 0;
			number = Math.abs(number);
			var numStr = number + '',
			formatedText = '',
			parts = [];
	
			var hasExponent = false;
			if (numStr.indexOf('e') !== -1) {
				var match = numStr.match(/([\d\.]+)e(-?)(\d+)/);
				if (match && match[2] == '-' && match[3] > fractionSize + 1) {
					numStr = '0';
				} else {
					formatedText = numStr;
					hasExponent = true;
				}
			}

			if (!hasExponent) {
				var fractionLen = (numStr.split(DEFAULT_DECIMAL_SEP)[1] || '').length;
		
				// determine fractionSize if it is not specified
				if( typeof(fractionSize) === "undefined" ) {
					fractionSize = Math.min(Math.max(pattern.minFrac, fractionLen), pattern.maxFrac);
				}
		
				var pow = Math.pow(10, fractionSize);
				number = Math.round(number * pow) / pow;
				var fraction = ('' + number).split(DEFAULT_DECIMAL_SEP);
				var whole = fraction[0];
				fraction = fraction[1] || '';
		
				formatedText = whole;
		
				// format fraction part.
				while(fraction.length < fractionSize) {
					fraction += '0';
				}
		
				if (fractionSize && fractionSize !== "0") formatedText += decimalSep + fraction.substr(0, fractionSize);
			}

			parts.push(isNegative ? pattern.negPre : pattern.posPre);
			parts.push(formatedText);
			parts.push(isNegative ? pattern.negSuf : pattern.posSuf);
			return parts.join('');
		}

		function maxNumFromPattern(pat) {
			return Math.pow(10,pat.maxInt) - Math.pow(10,-pat.maxFrac);
		}

		var amountPattern = $.extend({}, $locale.NUMBER_FORMATS.PATTERNS[1], {
			posSuf: $locale.NUMBER_FORMATS.PATTERNS[0].posSuf,
			negSuf: $locale.NUMBER_FORMATS.PATTERNS[0].negSuf,
			posPre: $locale.NUMBER_FORMATS.PATTERNS[0].posPre,
			negPre: $locale.NUMBER_FORMATS.PATTERNS[0].negPre,
			maxInt: 13
		});
		function formatTextFieldAmount(num) {
			return formatNumber(num, amountPattern, $locale.NUMBER_FORMATS.DECIMAL_SEP);
		}

		var stockAmountPattern = $.extend({}, amountPattern, {
			minFrac: STOCK_AMOUNT_FRAC_DIGITS,
			maxFrac: STOCK_AMOUNT_FRAC_DIGITS,
			maxInt: 11
		});
		function formatTextFieldStockAmount(num) {
			return formatNumber(num, stockAmountPattern, $locale.NUMBER_FORMATS.DECIMAL_SEP);
		}

		var intPattern = $.extend({}, $locale.NUMBER_FORMATS.PATTERNS[0], {
			minFrac: 0,
			maxFrac: 0,
			maxInt: 15
		});
		function formatTextFieldInt(num) {
			return formatNumber(num, intPattern, $locale.NUMBER_FORMATS.DECIMAL_SEP);
		}

		function makeTextFieldAmountFormatter() {
			return formatTextFieldAmount;
		}

		function makeTextFieldStockAmountFormatter() {
			return formatTextFieldStockAmount;
		}

		function makeTextFieldIntFormatter() {
			return formatTextFieldInt;
		}


		function wrapAndCacheParserForTextFields(parserFactory, maxFrac, maxNum) {
			if( parserFactory.wrappedParser == null ) {
				parserFactory.wrappedParser = wrapParserForTextFields(parserFactory, maxFrac, maxNum);
			}
			return function() {
				return parserFactory.wrappedParser;
			};
		}

		function wrapParserForTextFields(parserFactory, maxFrac, maxNum) {
			var parser = parserFactory();
			return function(str) {
				var charMap = {".":0, ",":0}, ret;
				str = $.trim(str);
				count(str, charMap);
				if( charMap["."] === 0 && charMap[","] === 0 ) ret = parser(str);
				else if( charMap["."] > 0 && charMap[","] > 0 ) throw new Error("parse error: too many candidate decimal points");
				else {
					str = findAndHandleDecimapSep(str, charMap, maxFrac);
					ret = parser(str);
					if( typeof(maxNum) === "number" && typeof(ret) === "number" && ret > maxNum ) throw new Error("parse error: too many digits");
				}
				return ret;
			};
		}

		function count(str, charMap) {
			var i, res;
			for( i=0; i < str.length; i++ ) {
				if( typeof(charMap[str[i]]) === "number" ) charMap[str[i]]++;
			}
		}

		function findAndHandleDecimapSep(str, charMap, maxFrac) {
			var x;
			for( x in charMap ) {
				if( !charMap.hasOwnProperty(x) ) continue;
				if( charMap[x] > 0 ) {
					str = handleCandidateDecimalSep(str, x, charMap[x], maxFrac);
					break;
				}
			}
			return str;
		}

		function handleCandidateDecimalSep(str, char, count, maxFrac) {
			var ret = str, tmp;
			if( count > 1 ) throw new Error("parse error: too many occurences of candidate decimal separator");
			if( char !== $locale.NUMBER_FORMATS.DECIMAL_SEP ) ret = str.replace(char, $locale.NUMBER_FORMATS.DECIMAL_SEP);
			tmp = ret.substr(ret.indexOf($locale.NUMBER_FORMATS.DECIMAL_SEP)+1);
			if( tmp.length > maxFrac ) {
				if( tmp.match(/^\d+$/) ) throw new Error("parse error: too many decimal digits");
				else throw new Error("parse error");
			}
			return ret;
		}


		return {
//			makeParser: makeParser,
//			makeFormatter: makeFormatter,

			makeTextFieldAmountParser: wrapAndCacheParserForTextFields(makeAmountParser, amountPattern.maxFrac, maxNumFromPattern(amountPattern)),
			makeTextFieldAmountFormatter: makeTextFieldAmountFormatter,
			makeTextFieldStockAmountParser: wrapAndCacheParserForTextFields(makeStockAmountParser, stockAmountPattern.maxFrac, maxNumFromPattern(stockAmountPattern)),
			makeTextFieldStockAmountFormatter: makeTextFieldStockAmountFormatter,
			makeTextFieldIntParser: wrapAndCacheParserForTextFields(makeIntParser, intPattern.maxFrac, maxNumFromPattern(intPattern)),
			makeTextFieldIntFormatter: makeTextFieldIntFormatter,

//			makeCurrencyParser: makeCurrencyParser,
//			makeCurrencyFormatter: makeCurrencyFormatter,
//			makeAmountParser: makeAmountParser,
//			makeAmountFormatter: makeAmountFormatter,
//			makeStockAmountParser: makeStockAmountParser,
//			makeStockAmountFormatter: makeStockAmountFormatter,
//			makeIntParser: makeIntParser,
//			makeIntFormatter: makeIntFormatter
		};
	});
})(window.rcfaces);
