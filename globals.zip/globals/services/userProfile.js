﻿service(
    'userProfile',
    ['angular', 'ctxPath', '$resource', 'resourceUtils', 'jQuery', 'wrapHttpRequest', '$q'],
    function (angular, ctxPath, $resource, ru, $, wrap, $q) {
        'use strict';

        var
		    rc = $resource(ctxPath("api/profile"), {}, {
		        userProfile: $.extend({ url: ctxPath("api/profile/userProfile") }, ru.postPayloadAction)
		    });

        var userProfile = null;
        var userRoleResolver = {};

        return {
            profile: function () {
                if (userProfile == null) {
                    userProfile = rc.userProfile(wrap({}));
                    userProfile.$then(angular.identity, function () {
                        userProfile = null;
                    });
                }
                return userProfile;
            },
            isUserInRole: function (role) {
                if (role == null ) {
                    return true;
                }
                if (userRoleResolver[role] == null) {
                    var userData = this.profile();
                    userRoleResolver[role] = $q.defer();
                    userData.$then(
                        function (response) {
                            var userProfile = response.data;
                            if (userProfile != null && userProfile.roles != null) {
                                var hasRole = _.contains(userProfile.roles, role);
                                userRoleResolver[role].resolve('true');
                            }
                            else {
                                userRoleResolver[role].resolve(false);
                            }
                        },
                        function () {
                            userRoleResolver[role].resolve(false);
                            userRoleResolver = {};
                        }
                    );
                }
                return userRoleResolver[role].promise;
            }
        };
    }
);