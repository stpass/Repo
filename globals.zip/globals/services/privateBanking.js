﻿service(
    'privateBanking',
    ['angular', 'ctxPath', '$resource', 'resourceUtils', 'jQuery', 'wrapHttpRequest', '$q'],
    function (angular, ctxPath, $resource, ru, $, wrap, $q) {
        'use strict';

        var
		    rc = $resource(ctxPath("api/privateBankingAuthentication"), {}, {
		        privateBankingLogOn: $.extend({ url: ctxPath("api/privateBankingAuthentication/privateBankingLogOn") }, ru.postPayloadAction)
		    });

        var privateBankingLogOnResult = null;        

        return {
            privateBankingLogOn: function () {
                if (privateBankingLogOnResult == null) {
                    privateBankingLogOnResult = rc.privateBankingLogOn(wrap({}));
                    privateBankingLogOnResult.$then(angular.identity, function () {
                        privateBankingLogOnResult = null;
                    });
                }
                return privateBankingLogOnResult;            
            }
        };
    }
);