﻿service("routeScope", ["$rootScope", "jQuery", "$location"], function($rootScope, $, $location) {
	"use strict";
	
	var store = null, betweenRoutesSlot = null, betweenRoutesFlashScope = null, currentFlashScope = null, nextFlashScope = null, privateStore = null;

	function tokenizePath(path) {
		var ret = path.split("/");
		$.grep(ret, function(x,index) { return index === 0 || !!x; }); // filter out empty strings, except for the first (the root)
		if( ret.length === 0 || ret[0] !== "" ) ret.unshift(""); // always start with the root element, an empty string
		return ret;
	}

	function newWithInheritance(parent) {
		var ctor = function() {};
		if( parent) ctor.prototype = parent;
		return new ctor();
	}

	/** Get betweenRoutesSlot or the last scope. */
	function getCurrentScope() {
		if( betweenRoutesSlot !== null ) return betweenRoutesSlot;
		else return getLastScope();
	}

	/** Get the last scope in store or null (i.e. doesnt care about the betweenRoutesSlot). */
	function getLastScope() {
		return store !== null ? store[store.length-1].scope : null;
	}

	function pushNewScope(name) {
		var parent = null;
		if( store.length > 0 ) parent = getLastScope();
		store.push({
			path: name,
			scope: newWithInheritance(parent)
		});
	}

	function ensureStore() {
		if( store === null ) {
			var i, pathArray = tokenizePath($location.path());
			store = [];
			for( i = 0; i < pathArray.length; i++ ) {
				pushNewScope(pathArray[i]);
			}
		}
	}

	function put(key, val) {
		ensureStore();
		getCurrentScope()[key] = val;
	}

	function get(key) {
		var ret;
		if( store !== null ) {
			ret = getCurrentScope()[key];
		}
		if( ret == null && currentFlashScope != null ) {
			ret = currentFlashScope[key];
		}
		return ret;
	}

	function remove(key) {
		var ret, scope, i;
		if( store !== null ) {
			scope = getCurrentScope();
			ret = scope[key];
			if( scope.hasOwnProperty(key) ) {
				delete  scope[key];
			}
			else {
				for( i=store.length-1; i >= 0; i-- ) {
					if( store[i].scope.hasOwnProperty(key) ) {
						delete store[i].scope[key];
						break;
					}
				}
			}
		}
		return ret;
	}

	function flash(key, val) {
		if( nextFlashScope == null ) nextFlashScope = {};
		nextFlashScope[key] = val;
	}

	$rootScope.$on("$routeChangeSuccess", function(event, currentRoute, previousRoute) {
		var i, pathArray, lastScope;
		if( store !== null ) {
		    pathArray = tokenizePath(currentRoute.prefixedRoute);
			for( i = 0; i < pathArray.length; i++ ) {
				if( i === store.length ) pushNewScope(pathArray[i]);
				else if( pathArray[i] !== store[i].path ) {
					store.splice(i,store.length-i);
					pushNewScope(pathArray[i]);
				}
			}
			if( i < store.length ) store.splice(i,store.length-i);
		}
		if( betweenRoutesSlot !== null ) {
			lastScope = getLastScope();
			if( lastScope !== null ) {
				for( i in betweenRoutesSlot ) {
					if( betweenRoutesSlot.hasOwnProperty(i) ) {
						lastScope[i] = betweenRoutesSlot[i];
					}
				}
			}
			betweenRoutesSlot = null;
		}
		// private route scope
		privateStore = null;
	    // flash scopes
		betweenRoutesFlashScope = null;
	});

	$rootScope.$on("$routeChangeStart", function(event, nextRoute, currentRoute) {
		var lastScope = getLastScope();
		betweenRoutesSlot = newWithInheritance(lastScope);
	    // flash scopes
		betweenRoutesFlashScope = currentFlashScope;
		currentFlashScope = nextFlashScope;
		nextFlashScope = null;
	});

	$rootScope.$on("$routeChangeError", function(event, currentRoute, previousRoute, rejection) {
	    betweenRoutesSlot = null;
	    nextFlashScope = currentFlashScope;
	    currentFlashScope = betweenRoutesFlashScope;
	    betweenRoutesFlashScope = null;
	});

	function getPrivate(key) {
		var ret;
		if( privateStore !== null ) ret = privateStore[key];
		return ret;
	}

	function putPrivate(key, val) {
		if( privateStore === null ) privateStore = {};
		privateStore[key] = val;
	}

	function removePrivate(key) {
		if( privateStore !== null ) delete privateStore[key];
	}

	return {
		get: get,
		put: put,
		remove: remove,
		flash: flash,
		getPrivate: getPrivate,
		putPrivate: putPrivate,
		removePrivate: removePrivate
	};
});
