﻿/**
 * Returns a function, that, as long as it continues to be invoked, will not
 * be triggered. The function will be called after it stops being called for
 * N milliseconds. If `immediate` is passed, trigger the function on the
 * leading edge, instead of the trailing.
 *
 * See also the lastCall service.
 *
 * Implementation copied from underscore.js, converted to use $timeout.
 */
service("debounce", ["$timeout"], function ($timeout) {
	"use strict";

	function debounce(func, wait, immediate) {
		var timeout, result;
		return function() {
			var context = this, args = arguments;
			var later = function() {
				timeout = null;
				if (!immediate) result = func.apply(context, args);
			};
			var callNow = immediate && !timeout;
			$timeout.cancel(timeout);
			timeout = $timeout(later, wait);
			if (callNow) result = func.apply(context, args);
			return result;
		};
	}
	
	return debounce;
});
