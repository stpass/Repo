﻿service("sidePopupSvc", ["jQuery", "$modal"], function($, $modal) {
	"use strict";

	var ignoreDocumentClicks = false,
	    opened = false

	function setOpened(value) {
	    opened = value;
	}

	function getOpened() {
	    return opened;
	}

	function setIgnoreDocumentClicks(flag) {
		ignoreDocumentClicks = !!flag;
	}

	function getIgnoreDocumentClicks() {
		return ignoreDocumentClicks;
	}

	function openModalFromSidePopup(opts, alwaysFn) {
		var dialog;

		function dResultAlways() {
			if( typeof(alwaysFn) === "function" ) alwaysFn();
			setIgnoreDocumentClicks(false);
			dialog = null;
			$("html").css("overflow-y","");
		}

		$("html").css("overflow-y","hidden"); // Why? Bootstrap's modal displays its own scrollbar, next to the window's scrollbar, which is ugly.
		setIgnoreDocumentClicks(true);
		dialog = $modal.open(opts);
		dialog.result.then(dResultAlways,dResultAlways);
		return dialog;
	}

	return {
		setIgnoreDocumentClicks: setIgnoreDocumentClicks,
		getIgnoreDocumentClicks: getIgnoreDocumentClicks,
		openModalFromSidePopup: openModalFromSidePopup,
		getOpened: getOpened,
		setOpened: setOpened,
	};
});
