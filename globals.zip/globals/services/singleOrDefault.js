﻿service('singleOrDefault', ['_'], function (_) {
    'use strict';

    return function (list, predicate, defaultValue) {
        defaultValue = typeof (defaultValue) == 'undefined' ? null : defaultValue;
        if (list && list.length > 0) {
            var filtered = _.where(list, predicate);
            if (filtered.length > 1) {
                throw Error('predicate filtered more than one results')
            } else if (filtered.length == 1) {
                return filtered[0];
            } else {
                return defaultValue;
            }
        } else {
            return defaultValue || null;
        }
    };
});