﻿/**
 * Wraps a function that returns a promise and may be called multiple times
 * with a function that also returns a promise that will be resolved with the
 * last returned value.
 *
 * The use case is the following (see transfers/expenses):
 * - A field is calculated in the server based on user input;
 *   the calls are properly debounced, so that there isn't a call per keyup.
 * - At some point the service is called with arguments A.
 * - Before A returns the input changes and the service is called again
 *   with input B.
 * - Call B returns and updates the UI.
 * - Call A returns. This result should be discarded.
 *
 * See also the debounce service.
 */
service("lastCall", ["$q"], function ($q) {
	"use strict";

	function lastCall(promiseFn) {
		var lastDeferred = null;
	
		return function() {
			var d = $q.defer();
			if( lastDeferred !== null ) lastDeferred.reject("overriden");
			lastDeferred = d;
			promiseFn.apply(this, arguments).then(
				function() {
					d.resolve.apply(d,arguments);
					lastDeferred = null;
				},
				function() {
					d.reject.apply(d,arguments);
					lastDeferred = null;
				}
			);
			return d.promise;
		};
	}
	
	return lastCall;
});
