﻿service('ParamsBuilder', ['angular', '$window'], function (angular, $window) {
    'use strict';

    var ParamsBuilder = function () {
        this.params = [];
    };

    ParamsBuilder.prototype.addParams = function (name, values) {
        if (values) {
            if (!angular.isArray(values)) {
                values = [values];
            }
            for (var i = 0; i < values.length; i++) {
                this.params.push(name + '=' + $window.encodeURIComponent(values[i]));
            }
        }
        return this;
    };

    ParamsBuilder.prototype.build = function () {
        return this.params.join('&');
    };

    return ParamsBuilder;
});
