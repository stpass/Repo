window.service("help", [], function () {
    var moduleResolvers = {};
    var helpService = {
        addSource: null,
        getResolver: null,
        resolve: null
    };
    helpService.addSource = function (moduleName, resolver) {
        if (typeof (moduleName) === "string") {
            moduleResolvers[moduleName] = resolver;
        } else {
        }
    };
    helpService.getResolver = function (moduleName) {
        if (typeof (moduleName) === "string") {
            return moduleResolvers[moduleName];
        } else {
            return null;
        }
    };
    helpService.resolve = function (moduleName, locator) {
        var resolver = helpService.getResolver(moduleName);
        if (resolver != null) {
            return resolver(locator);
        }
        return null;
    };

    return helpService;
});
//# sourceMappingURL=help.js.map
