﻿service("wrapHttpRequest", ["application","jQuery"], function (application,$) {
    return function(payload) {
        var uuidStr = uuid.v4();
		payload = payload || {};
        payload.userId = window.imb.userID;       
        return {
            header: { ID: uuidStr, Application: application.APPL, Bank: application.BANK, Channel: application.CHANNEL },
            payload: payload
        };
    };
});
