﻿service("uiBlocker", ["$window", "localize", "jQuery"], function ($window, localize, $) {
	"use strict";

	// the actual overlays and event handling is based on jQuery.blockUI
	var blocked = false;
	var pleaseWait = localize("pleaseWait");
	var events = "mousedown mouseup keydown keypress keyup touchstart touchend touchmove";
	var template = "<div class='ui-blocker-marker ui-blocker' style='display:none;'>" +
                   "</div>" +
                   "<div class='ui-blocker-marker ui-blocker-message' style='display:none;'>" +
                        "<p>" + pleaseWait + "</p>" +
                        "<div class='spinner'></div>" +
                   "</div>";

	$(template).appendTo("body");
	var uiBlocker = $('.ui-blocker-marker');

	function handler() {
		return false;
	}

	function block(promise) {
	    if (!blocked) {
	        uiBlocker.show();
		    $($window.document).on(events, handler);
			blocked = true;
			if( typeof(promise) === "object" && promise !== null ) {
				if( typeof(promise.always) === "function" ) promise.always(unblock);
				else if( typeof(promise.then) === "function" ) promise.then(unblock,unblock);
				else if( typeof(promise.$then) === "function" ) promise.$then(unblock,unblock);
			}
		}
	}

	function unblock() {
		if( blocked ) {
		    blocked = false;
		    $(document).off(events, handler);
		    uiBlocker.hide();
		}
	}

	function isBlocked() {
		return blocked;
	}

	return {
		isBlocked: isBlocked,
		block: block,
		unblock: unblock
	};
});
