﻿interface IResourceLite<T> {
    $then<TResult>(successCallback: (response: T) => void, errorCallback?: (exception: any) => void): ng.IPromise<TResult>;
    $resolved: boolean;
    $error: boolean;
    $requestId: string;
    $exception: any;
    $messages: any;
    $promise: any;
}

interface IHttpPost {
    forObject<T>(actionUrl: string, postData: any, unwrapPayloadFn?: (payload: any) => T): IResourceLite<T>;
    forArray<T>(actionUrl: string, postData: any, unwrapPayloadFn?: (payload: any) => T[]): IResourceLite<T[]>;
}

window.service(
    "httpPost",
    ["angular", "$q", "$http", "UrlBuilder", "wrapHttpRequest"],
    function (
        angular: ng.IAngularStatic, 
        $q: ng.IQService, 
        $http: ng.IHttpService, 
        UrlBuilder: any, 
        wrap: (payload: any) => any
    ): IHttpPost {

        function resolve<T>(resource: IResourceLite<T>, response: ng.IHttpPromiseCallbackArg<any>): void {
            resource.$resolved = true;
            if (response.data != null && response.data.messages != null) {
                resource.$messages = response.data.messages;
            }
        }

        function rejector<T>(resource: IResourceLite<T>, response: ng.IHttpPromiseCallbackArg<any>): ng.IPromise<any> {
            resource.$error = true;
            if (response.data != null && response.data.exception != null) {
                resource.$exception = response.data.exception;
            } else {
                resource.$exception = { 'code': 'SYSTEM', 'desc': 'System error', 'sev': 'Error', 'cat': 'System' };
            }
            return $q.reject(resource.$exception);
        }

        function httpPost<T>(isArray: boolean, actionUrl: string, postData: any, unwrapPayloadFn?: (payload: any, response?: ng.IHttpPromiseCallbackArg<any>) => T): IResourceLite<T> {
            var url: string = UrlBuilder.ctxRel(actionUrl).toUrl();
            var wrapped: any = wrap(postData);
            var resource: IResourceLite<T> = <IResourceLite<T>>(isArray ? [] : {});
            var promise: ng.IPromise<T> = $http.post(url, wrapped).then(
                function systemSuccess(response: ng.IHttpPromiseCallbackArg<any>): any {
                    resolve<T>(resource, response);
                    if (response.data != null && response.data.exception == null) {
                        unwrapPayloadFn = unwrapPayloadFn || <(payload: any) => T> angular.identity;
                        var businessEntity: T = unwrapPayloadFn(response.data.payload);
                        if (isArray && angular.isArray(businessEntity)) {
                            Array.prototype.push.apply(resource, businessEntity)
                        } else {
                            angular.extend(resource, businessEntity);
                        }
                        return businessEntity;
                    } else {
                        return rejector<T>(resource, response);
                    }
                },
                function systemError(response: ng.IHttpPromiseCallbackArg<any>): any {
                    resolve(resource, response)
                    return rejector<T>(resource, response);
                }
            );
            resource.$then = promise.then;
            resource.$resolved = false;
            resource.$error = false;
            resource.$requestId = wrapped.header.ID;
            resource.$exception = null;
            resource.$messages = null;
            resource.$promise = promise;
            return resource;
        }

        return {
            forObject: function httpPostForObject<T>(actionUrl: string, postData: any, unwrapPayloadFn?: (payload: any) => T): IResourceLite<T> {
                return httpPost<T>(false, actionUrl, postData, unwrapPayloadFn);
            },
            forArray: function httpPostForArray<T>(actionUrl: string, postData: any, unwrapPayloadFn?: (payload: any) => T[]): IResourceLite<T[]> {
                return httpPost<T[]>(true, actionUrl, postData, unwrapPayloadFn);
            }
        };
    }
);