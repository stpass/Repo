﻿interface IServerResponse<T> {
    resource: IResource<T>;
    payload: T;
    hasMore: boolean;
    messages: any;
    exception: any;
}
interface IPromiceResolver<T> extends Function {
    (successCallback: (response: ng.IHttpPromiseCallbackArg<T>) => T, errorCallback?: (response: ng.IHttpPromiseCallbackArg<T>) => any): ng.IPromise<T>;
    (successCallback: (response: ng.IHttpPromiseCallbackArg<T>) => ng.IPromise<T>, errorCallback?: (response: ng.IHttpPromiseCallbackArg<T>) => any): ng.IPromise<T>;
}
interface IResourceBase {
    $error: any;
    $rc: any;
}
interface IResource<T> extends IResourceBase {
    $then: IPromiceResolver<T>; 
    $resolved : boolean;
    $value : T;
    $messages : any;
    $hasMore : boolean;
    $exception : any;
    $systemMessage : any;
}
interface IDataProcessorFunction<T extends IResourceBase> extends Function {
    (data: string, headersGetter: (headerName: string) => string): T;
}
interface ITransformResponseFactory<T extends IResourceBase> extends Function {
    (data: string, headersGetter: (headerName: string) => string): T;
    //(isArray: boolean): IDataProcessorFunction<T>;
}
interface IResourceAction<T extends IResourceBase> {
    method: string;
    isArray: boolean;
    transformResponse: ITransformResponseFactory<T>;
}
interface IResourceUtils<T extends IResourceBase> {
    transformResponse: ITransformResponseFactory<T>; //(boolean) => IDataProcessorFunction<T>;
    transformArrayResponse: ITransformResponseFactory<T>;
    getPayloadAction: IResourceAction<T>;
    getPayloadAsArrayAction: IResourceAction<T>;
    postPayloadAction: IResourceAction<T>;
    postPayloadAsArrayAction: IResourceAction<T>;
    wrapResource: (resource: IResource<T>) => IResource<T>;
}
//:IResourceUtils<IResourceBase> 
window.service("resourceUtils", ["messageSvc", "$q"], function (messageSvc, $q){
	"use strict";

	var
        transformResponse: ITransformResponseFactory<IResourceBase> = transformResponseFactory<IResourceBase>(false),
        transformArrayResponse: ITransformResponseFactory<IResourceBase> = transformResponseFactory<IResourceBase>(true),

        getPayloadAction: IResourceAction<IResourceBase> = {
            method: "GET",
            isArray: null,
			transformResponse: transformResponse
		},

        getPayloadAsArrayAction: IResourceAction<IResourceBase> = {
			method: "GET",
			isArray: true,
			transformResponse: transformArrayResponse
		},
		
        postPayloadAction: IResourceAction<IResourceBase> = {
            method: "POST",
            isArray: null,
			transformResponse: transformResponse
		},

        postPayloadAsArrayAction: IResourceAction<IResourceBase> = {
			method: "POST",
			isArray: true,
			transformResponse: transformArrayResponse
		};

    function transformResponseFactory<T extends IResourceBase>(isArray: boolean): ITransformResponseFactory<T> {
		return function (data: string, headersGetter: (headerName: string) => string):T {
            var tData: IServerResponse<T> = null;
			try {
				if( data != null && data != "" ) tData = JSON.parse(data);
				else tData = null;
			}
			catch(e) {
                return <T>{ $error: e, $rc: "FAILURE" };
			}
            if (tData != null && typeof (tData.payload) !== "undefined") {
                var ret;

                // handle the case where data.payload is null or non-object,
                // in which case its value will not be processed by $resource
                if (isArray) {
                    if (tData.payload === null) {
                        ret = [];
                        ret.$value = null;
                    }
                    else if (!$.isArray(tData.payload)) throw new Error("expected array, got " + typeof (tData.payload));
                    else ret = tData.payload;
                }
                else {
                    if (tData.payload === null) ret = { $value: null };
                    else if (typeof (tData.payload) !== "object") ret = { $value: tData.payload };
                    else ret = tData.payload;
                }

                if ($.isArray(tData.messages)) ret.$messages = tData.messages;
                if (typeof (tData.hasMore) === "boolean") ret.$hasMore = tData.hasMore;
                if (tData.exception == null) {
                    ret.$rc = "SUCCESS";
                }
                else {
                    ret.$rc = "FAILURE";
                    ret.$exception = tData.exception;
                    ret.$systemMessage = messageSvc.addError(ret.$exception.desc);
                }
                return ret;
            }
            //else return tData;
            else return $.extend(tData, { $error: null, $rc: "FAILURE" } );
		}
	}

	/**
	 * Wrap an object returned by a call to an Angular $resource (i.e. an
	 * object or array having at least the `$resolved` and `$then` properties)
	 * with another object whose `$then` promise gets rejected both when system
	 * errors occur (HTTP status >= 400) and when business errors occur (HTTP
	 * status < 400 but either `$rc` is `FAILURE` or `$exception` is non-null).
	 */
	function wrapResource<TData>(r:IResource<TData>): IResource<TData> {
        //var ret: IResource<T> = $.isArray(r) ? <IResource<T>>[] : <IResource<T>> {};
        var ret: any = $.isArray(r) ? [] : {};
		copyResourceProperties(r, ret);
		ret.$then = r.$then(
			function(response:IServerResponse<TData>) {
				var res = response.resource;
				copyResourceProperties(r, ret);
				// This is the condition signifying true business success
				// TODO May need to be revised (e.g. $exception != null and $rc == 'FAILURE' are identical cases)
				if( res != null && res.$exception == null && res.$rc === "SUCCESS" ) return response;
				else return $q.reject(response);
			},
			function(response) {
				copyResourceProperties(r, ret);
				return $q.reject(response);
			}
		).then;
		return ret;
	}

    function copyResourceProperties<TData>(src: IResource<TData>, dst:IResource<TData>) {
		dst.$resolved = src.$resolved;
		if( src.$error ) dst.$error = src.$error;
		if( src.$rc ) dst.$rc = src.$rc;
		if( src.$value ) dst.$value = src.$value;
		if( src.$messages ) dst.$messages = src.$messages;
		if( src.$hasMore ) dst.$hasMore = src.$hasMore;
		if( src.$exception ) dst.$exception = src.$exception;
		if( src.$systemMessage ) dst.$systemMessage = messageSvc.findMessage(src.$systemMessage);
	}
    //:IResourceUtils<IResourceBase>
    var utility: IResourceUtils<IResourceBase> = {
		transformResponse: transformResponse,
		transformArrayResponse: transformArrayResponse,
		getPayloadAction: getPayloadAction,
		getPayloadAsArrayAction: getPayloadAsArrayAction,
		postPayloadAction: postPayloadAction,
		postPayloadAsArrayAction: postPayloadAsArrayAction,
		wrapResource: wrapResource
    };
    return utility; 
});
