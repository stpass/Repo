﻿value('imb',     window.imb);
value('angular', window.angular);
value('_',       window._);
value('$',       window.jQuery);
value('jQuery',  window.jQuery);
value('moment',  window.moment);
