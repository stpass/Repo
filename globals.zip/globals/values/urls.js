﻿value('ctxUrl', window.imb.contextPath);  // eg: /ibank/
value('baseUrl', window.imb.baseUrl);      // eg: /ibank/Scripts/app
value('modulesUrl', window.imb.modulesUrl);   // eg: /ibank/Scripts/app/modules
value('globalsUrl', window.imb.globalsUrl);   // eg: /ibank/Scripts/app/globals
