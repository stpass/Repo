﻿window.decorator('$controller', ['angular', '$window', '$delegate', 'userProfile', "_"], function (angular, $window, $delegate, userProfile, _) {
    return function (ctor, locals) {
        locals.$scope.back = function () {
            $window.history.back(-1);
        };

        locals.$scope.equals = function (obj1, obj2) {
            return angular.equals(obj1, obj2);
        };

        locals.$scope.modelCopy = function (obj) {
            if (obj.constructor) {
                return new obj.constructor(obj);
            } else {
                return angular.copy(obj);
            }
        };

        locals.$scope.when = function (expr, trueCallback, falseCallback) {
            return this.$watch(expr, function (val) {
                if (val) {
                    trueCallback(val);
                } else if (falseCallback) {
                    falseCallback(val);
                }
            });
        };
        locals.$scope.isDemo = false;

        locals.$scope.isUserInRole = function (role) {
            var profile = userProfile.profile();
            if (profile != null && profile.roles != null) {
                return _.contains(profile.roles, role);
            }
            return false;
        };

        locals.$scope.isCorporateUser = function () {
            var profile = userProfile.profile();
            return profile.userType === 'C';
        };

        locals.$scope.isRetailUser = function () {
            var profile = userProfile.profile();
            return profile.userType === 'P';
        };

        return $delegate(ctor, locals);
    };
});
//# sourceMappingURL=scopeExtensions.js.map
