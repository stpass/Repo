﻿// Decorate the default exception handler in order to log client errors on the server
decorator('$exceptionHandler', ['$delegate', 'imb'], function ($delegate, imb) {
    return function (exception, cause) {
        // Notify default handler in order to facilitate tests
        $delegate(exception, cause);
        // Log errors using the imb reportError
        imb.reportError(exception.message, cause, null);
    };
});