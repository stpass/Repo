﻿animation("fade-enter", function() {
	return {
		setup: function(element) {
			element.hide();
		},
		start: function (element, done, memo) {		    
		    try {
		        element.fadeIn(function () {
		            done();
		        });
		    }
		    catch (ex) { }
		}
	};
});

animation("fade-leave", function() {
	return {
		setup: function(element) {
			element.show();
		},
		start: function (element, done, memo) {		    
			element.fadeOut(function() {
				done();
			});
		}
	};
});
