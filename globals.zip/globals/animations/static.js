﻿animation("static-show", function () {
    return {
        setup: function (element) {
            element.css({display: 'none'});
        },
        start: function (element, done, memo) {
            element.css({display: ''});
            done();
        }
    };
});

animation("static-hide", function () {
    return {
        setup: function (element) {
            element.css({ display: '' });
        },
        start: function (element, done, memo) {
            element.css({ display: 'none' });
            done();
        }
    };
});