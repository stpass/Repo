﻿init('serverTimeInit', ['$q', '$http', 'ctxPath', 'moment'], function ($q, $http, ctxPath, moment) {
    var defer = $q.defer();
    $http.post(
            ctxPath('/api/servertime'),
            {
                header: {
                    id: "RequestID",
                    application: "Web",
                },
                payload: {
                    userID: ""
                }

            }
        ).success(function (resp) {
            defer.resolve(moment(resp.serverTime).toDate());
        }).
        error(function () {
            defer.resolve(null);
        });

    return defer.promise;
});