﻿service("Execution", [], function() {
	"use strict";

	function Execution(json) {
		json = json || {};
		this.type = json.type || 'instant';
		this.executionDate = json.executionDate || null;
		this.name = json.name || null;
		this.period = json.period != null ? json.period : 0;
		this.totPayments = json.totPayments || 1;
	}

	Execution.REQUIRED_COND = {condition: function() { return this != null && this.type === "scheduled"; }};

	Execution.executionDateValidators = [
		["required", Execution.REQUIRED_COND],
		"futureDate"
	];
	Execution.nameValidators = [
		["required", Execution.REQUIRED_COND],
		["regexp", {re: /^[0-9A-ZΑ-Ω ]*$/i, msgkey: "valid_DefferedExecutionName"}]
	];
	Execution.periodValidators = [
		["required", Execution.REQUIRED_COND],
		["bound", {min: 0, max: 6}]
	];
	Execution.totPaymentsValidators = [
		["required", Execution.REQUIRED_COND],
		["bound", {minni: 0}]
	];

	return Execution;
});
