﻿service("ForeignBank", ["jQuery"], function($) {
	"use strict";

	function ForeignBank(json) {
		json = json || {};
		this.name = json.name || null;
		this.code = json.code || null;
		this.address = json.address || null;
		this.city = json.city || null;
		this.country = json.country || null;
	}

	ForeignBank.nameValidators = [
		"required",
		["length", {min: 4}]
	];
	ForeignBank.codeValidators = [
		"required",
		["notGR", function(thisObj, value, validationContext) {
			if( value == null ) return true;
			if($.trim(value).match(ForeignBank.codeValidators.GR_RE) ) return false;
			return true;
		}]
	];
	ForeignBank.codeValidators.GR_RE = /^GR.*$/i;

	return ForeignBank;
});
