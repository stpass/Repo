﻿service("TanInputData", [], function() {
	"use strict";

	function TanInputData(json) {
	    json = json || {};
		this.tanNumber = json.tanNumber || null;
	}

	TanInputData.tanNumberValidators = [
		["required", {groups:"tan"}],
		["TAN", {groups:"tan"}]
	];

	return TanInputData;
});
