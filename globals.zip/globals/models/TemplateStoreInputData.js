﻿service("TemplateStoreInputData", function() {
	"use strict";

	function TemplateStoreInputData(json) {
		this.storeFlag = (json && json.storeFlag) ? true : false;
		this.name = (json && json.name) ? json.name : null;
	}

	TemplateStoreInputData.nameValidators = [
		["required", {condition: function() {
			return this != null && this.storeFlag === true;
		}}]
	];

	return TemplateStoreInputData;
});
