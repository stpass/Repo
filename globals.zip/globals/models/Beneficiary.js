﻿service("Beneficiary", [], function() {
	"use strict";

	function Beneficiary(json) {
		json = json || {};
		this.name = json.name || null;
		this.receiverAddrGR = json.receiverAddrGR || null;
		this.typeDetailed = null;
	}

	Beneficiary.nameValidators = [
		"required",
		"onlyCaps",
		["length", {min: 4}],
		["lengthForDomestic","length", {max: 70, condition: function() {
			return this.typeDetailed === "dom"; // this.typeDetailed will be set by the controller
		}}],
		["allLatinCaps", {condition: function() {
			return this.typeDetailed === "fgn"; // this.typeDetailed will be set by the controller
		}}]
	];
	Beneficiary.receiverAddrGRValidators = ["allLatinCapsAndNumbers"]; // optional for foreign transfer, unsupported for domestic

	return Beneficiary;
});
